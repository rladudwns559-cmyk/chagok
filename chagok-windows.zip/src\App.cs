using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using Microsoft.Win32;

namespace Chagok {
  public class Segment { public double start { get; set; } public double end { get; set; } }
  public class Record {
    public string id { get; set; } public string subject { get; set; } public string note { get; set; }
    public List<Segment> segments { get; set; } public bool manual { get; set; }
  }
  public class Active {
    public string subject { get; set; } public string note { get; set; } public string status { get; set; }
    public List<Segment> segments { get; set; } public double? anchor { get; set; }
    public double startedAt { get; set; } public double lastHeartbeat { get; set; }
  }
  public class StudyData {
    public int version { get; set; } public double goal { get; set; } public List<string> subjects { get; set; }
    public List<Record> records { get; set; } public Dictionary<string,string> notes { get; set; } public Active active { get; set; }
    public static StudyData Fresh() { return new StudyData { version=1, goal=4, subjects=new List<string>{"자유 공부","수학","영어","전공 공부"}, records=new List<Record>(), notes=new Dictionary<string,string>() }; }
  }
  public static class Logic {
    static readonly DateTime Epoch=new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc);
    public static double Now() { return (DateTime.UtcNow-Epoch).TotalMilliseconds; }
    public static double Stamp(DateTime local) { return (local.ToUniversalTime()-Epoch).TotalMilliseconds; }
    public static DateTime Local(double stamp) { return Epoch.AddMilliseconds(stamp).ToLocalTime(); }
    public static string Key(DateTime date) { return date.ToString("yyyy-MM-dd",System.Globalization.CultureInfo.InvariantCulture); }
    public static string Clock(double sec) { long s=(long)Math.Max(0,sec);return string.Format("{0:00}:{1:00}:{2:00}",s/3600,s/60%60,s%60); }
    public static string Duration(double sec) { long s=(long)Math.Max(0,sec);if(s>=3600)return string.Format("{0}시간 {1}분",s/3600,s/60%60);if(s>=60)return string.Format("{0}분",s/60);return s>0?s+"초":"0분"; }
    public static double Total(IEnumerable<Segment> segments) { return segments.Sum(s=>Math.Max(0,s.end-s.start))/1000; }
    public static double Day(IEnumerable<Segment> segments,DateTime day) {
      double start=Stamp(day.Date),end=Stamp(day.Date.AddDays(1));
      return segments.Sum(s=>Math.Max(0,Math.Min(s.end,end)-Math.Max(s.start,start)))/1000;
    }
    public static IEnumerable<Segment> ActiveParts(Active a,double now) {
      if(a==null)return new List<Segment>();
      var parts=new List<Segment>(a.segments);
      if(a.status=="running"&&a.anchor.HasValue)parts.Add(new Segment{start=a.anchor.Value,end=Math.Max(a.anchor.Value,now)});
      return parts;
    }
    public static double DayTotal(StudyData d,DateTime day,double now) { return d.records.Sum(r=>Day(r.segments,day))+Day(ActiveParts(d.active,now),day); }
    public static DateTime Monday(DateTime day) { return day.Date.AddDays(-(((int)day.DayOfWeek+6)%7)); }
    static bool Finite(double x) { return !double.IsNaN(x)&&!double.IsInfinity(x); }
    static bool SegmentsOK(List<Segment> xs) { return xs!=null&&xs.Count<100000&&xs.All(s=>s!=null&&Finite(s.start)&&Finite(s.end)&&s.start>=0&&s.end>=s.start&&s.end<253402300799000d); }
    public static void Validate(StudyData d) {
      if(d==null||d.version!=1||!Finite(d.goal)||d.goal<.25||d.goal>24||d.subjects==null||d.subjects.Count<1||d.subjects.Count>100||d.subjects.Any(s=>string.IsNullOrWhiteSpace(s)||s.Length>30)||d.subjects.Distinct().Count()!=d.subjects.Count||d.records==null||d.records.Count>100000||d.notes==null)throw new InvalidDataException("올바른 차곡 백업 파일이 아니에요.");
      foreach(var r in d.records)if(r==null||string.IsNullOrEmpty(r.id)||string.IsNullOrWhiteSpace(r.subject)||r.subject.Length>30||r.note==null||r.note.Length>200||!SegmentsOK(r.segments))throw new InvalidDataException("공부 기록 형식을 확인해주세요.");
      foreach(var n in d.notes) { DateTime parsed;if(!DateTime.TryParseExact(n.Key,"yyyy-MM-dd",System.Globalization.CultureInfo.InvariantCulture,System.Globalization.DateTimeStyles.None,out parsed)||n.Value==null||n.Value.Length>500)throw new InvalidDataException("날짜별 메모 형식을 확인해주세요."); }
      var a=d.active;
      if(a!=null&&(string.IsNullOrWhiteSpace(a.subject)||a.subject.Length>30||a.note==null||a.note.Length>200||!SegmentsOK(a.segments)||!Finite(a.startedAt)||(a.status!="running"&&a.status!="paused")||(a.status=="running"&&(!a.anchor.HasValue||!Finite(a.anchor.Value)||a.anchor.Value<0))))throw new InvalidDataException("진행 중인 타이머 형식을 확인해주세요.");
    }
    public static bool Recover(StudyData d) {
      var a=d.active;if(a==null||a.status!="running")return false;
      if(a.anchor.HasValue&&a.lastHeartbeat>=a.anchor.Value)a.segments.Add(new Segment{start=a.anchor.Value,end=a.lastHeartbeat});
      a.status="paused";a.anchor=null;return true;
    }
  }
  public class Store {
    public readonly string Folder,FilePath;public string Notice="";public bool ReadOnly;
    readonly JavaScriptSerializer json=new JavaScriptSerializer{MaxJsonLength=30*1024*1024,RecursionLimit=100};
    public Store(string folder) { Folder=folder;FilePath=Path.Combine(folder,"study-data.json"); }
    public string Serialize(StudyData d) { return json.Serialize(d); }
    public StudyData Parse(string text) { var d=json.Deserialize<StudyData>(text);Logic.Validate(d);return d; }
    public StudyData Load() {
      Directory.CreateDirectory(Folder);
      if(!File.Exists(FilePath))return StudyData.Fresh();
      try { return Parse(File.ReadAllText(FilePath,Encoding.UTF8)); }
      catch {
        try {
          var restored=Parse(File.ReadAllText(FilePath+".bak",Encoding.UTF8));
          File.Copy(FilePath,Path.Combine(Folder,"damaged-"+DateTime.Now.ToString("yyyyMMdd-HHmmssfff")+".json"),false);
          File.Copy(FilePath+".bak",FilePath,true);
          Notice="최근 자동 백업에서 기록을 복구했어요.";return restored;
        } catch { ReadOnly=true;Notice="저장 파일을 읽지 못했어요. 기존 파일은 보존했어요. 백업을 불러오거나 기록 폴더를 확인해주세요.";return StudyData.Fresh(); }
      }
    }
    public void Save(StudyData d) {
      if(ReadOnly)throw new IOException("기존 기록 보호를 위해 저장을 멈췄어요. 백업 불러오기로 복구해주세요.");
      Logic.Validate(d);Directory.CreateDirectory(Folder);string temp=FilePath+".tmp";
      using(var f=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None,4096,FileOptions.WriteThrough)) {
        byte[] bytes=new UTF8Encoding(false).GetBytes(Serialize(d));f.Write(bytes,0,bytes.Length);f.Flush(true);
      }
      if(File.Exists(FilePath))File.Replace(temp,FilePath,FilePath+".bak");else File.Move(temp,FilePath);
    }
  }
  // ───────────────────────── 디자인 ─────────────────────────
  // 색상·글꼴·크기 규칙은 모두 Theme에 모여 있습니다. 화면 배율(125%, 150% 등)에 맞춰 S()로 크기를 키웁니다.
  public enum ButtonKind { Primary, Dark, Secondary, Ghost, Nav, Danger }
  public static class Theme {
    public static readonly Color
      Bg=Color.FromArgb(246,244,239), Paper=Color.White, Ink=Color.FromArgb(36,44,40), Sub=Color.FromArgb(84,96,88), Muted=Color.FromArgb(104,114,102),
      Line=Color.FromArgb(232,233,226), LineStrong=Color.FromArgb(210,214,203), Orange=Color.FromArgb(222,102,60), Action=Color.FromArgb(200,82,44), OrangeSoft=Color.FromArgb(252,235,225),
      Green=Color.FromArgb(84,122,66), Soft=Color.FromArgb(242,243,237), Track=Color.FromArgb(236,238,230), Bar=Color.FromArgb(186,204,164), Amber=Color.FromArgb(184,128,30),
      Danger=Color.FromArgb(184,60,48), DangerSoft=Color.FromArgb(251,236,233), Disabled=Color.FromArgb(160,166,158), FieldOff=Color.FromArgb(244,244,240),
      Night=Color.FromArgb(38,48,43), NightText=Color.FromArgb(196,206,198), NightTrack=Color.FromArgb(66,78,71);
    public static float Scale=1f, FontBoost=1f;
    static Theme() { try { using(var g=Graphics.FromHwnd(IntPtr.Zero))Scale=Math.Max(1f,g.DpiX/96f); } catch { Scale=1f; } }
    public static int S(int v) { return (int)Math.Round(v*Scale); }
    public static float SF(float v) { return v*Scale; }
    public static Color Mix(Color a,Color b,float t) { return Color.FromArgb((int)(a.R+(b.R-a.R)*t),(int)(a.G+(b.G-a.G)*t),(int)(a.B+(b.B-a.B)*t)); }
    public static Color Surface(Control c) { while(c!=null){if(c.BackColor.A==255)return c.BackColor;c=c.Parent;}return Bg; }
    public static GraphicsPath Round(RectangleF r,float radius) {
      var p=new GraphicsPath();float d=Math.Min(radius*2,Math.Min(r.Width,r.Height));
      if(d<=1){p.AddRectangle(r);return p;}
      p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.Right-d,r.Y,d,d,270,90);p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);p.AddArc(r.X,r.Bottom-d,d,d,90,90);p.CloseFigure();return p;
    }
    public static void FillRound(Graphics g,Color c,RectangleF r,float radius) { using(var p=Round(r,radius))using(var b=new SolidBrush(c))g.FillPath(b,p); }
    public static void DrawRound(Graphics g,Color c,float width,RectangleF r,float radius) { using(var p=Round(r,radius))using(var pen=new Pen(c,width))g.DrawPath(pen,p); }
    public static Font Font(float size,FontStyle style=FontStyle.Regular) { return new Font("맑은 고딕",size*FontBoost,style,GraphicsUnit.Point); }
    public static Label Label(string text,float size,bool bold=false) { return new Label{Text=text,AutoSize=false,Font=Font(size,bold?FontStyle.Bold:FontStyle.Regular),ForeColor=Ink,BackColor=Color.Transparent,TextAlign=ContentAlignment.MiddleLeft,AutoEllipsis=true,UseMnemonic=false}; }
    public static Label Caption(string text,float size=9) { var l=Label(text,size);l.ForeColor=Muted;return l; }
    public static Btn Button(string text,ButtonKind kind=ButtonKind.Secondary) { return new Btn(text,kind); }
    public static Card Card() { return new Card(); }
    public static TextBox Input() { return new TextBox{Font=Font(10.5f),BorderStyle=BorderStyle.None,MaxLength=200,BackColor=Paper,ForeColor=Ink}; }
    public static Field Frame(Control inner) { return new Field(inner); }
    // 빈 입력칸에 회색 안내 문구 (Windows 기본 기능 EM_SETCUEBANNER)
    [System.Runtime.InteropServices.DllImport("user32.dll",CharSet=System.Runtime.InteropServices.CharSet.Unicode)] static extern IntPtr SendMessage(IntPtr h,int msg,IntPtr w,string l);
    public static void Hint(TextBox box,string text) { EventHandler apply=(s,e)=>SendMessage(box.Handle,0x1501,(IntPtr)1,text);box.HandleCreated+=apply;if(box.IsHandleCreated)apply(box,EventArgs.Empty); }
    public static Picker Select() { return new Picker{Font=Font(10.5f)}; }
    public static void Place(Control parent,Control child,int x,int y,int width,int height) { child.SetBounds(S(x),S(y),S(width),S(height));parent.Controls.Add(child); }
    public static void RenderGrid(DataGridView grid,string empty) {
      grid.Dock=DockStyle.Fill;grid.ReadOnly=true;grid.AllowUserToAddRows=false;grid.AllowUserToDeleteRows=false;grid.AllowUserToResizeRows=false;grid.AllowUserToResizeColumns=false;grid.AutoGenerateColumns=false;grid.RowHeadersVisible=false;grid.SelectionMode=DataGridViewSelectionMode.FullRowSelect;grid.MultiSelect=false;grid.BackgroundColor=Paper;grid.BorderStyle=BorderStyle.None;grid.GridColor=Line;grid.CellBorderStyle=DataGridViewCellBorderStyle.SingleHorizontal;grid.EnableHeadersVisualStyles=false;grid.Font=Font(10);grid.RowTemplate.Height=S(40);
      grid.ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.None;grid.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.DisableResizing;grid.ColumnHeadersHeight=S(34);
      grid.ColumnHeadersDefaultCellStyle=new DataGridViewCellStyle{BackColor=Paper,ForeColor=Muted,Font=Font(9,FontStyle.Bold),SelectionBackColor=Paper,SelectionForeColor=Muted,Padding=new Padding(S(6),0,S(6),0)};
      grid.DefaultCellStyle=new DataGridViewCellStyle{BackColor=Paper,ForeColor=Ink,SelectionBackColor=OrangeSoft,SelectionForeColor=Ink,Padding=new Padding(S(6),0,S(6),0)};
      grid.Columns.Add(new DataGridViewTextBoxColumn{Name="subject",HeaderText="과목",Width=S(110),SortMode=DataGridViewColumnSortMode.NotSortable,DefaultCellStyle=new DataGridViewCellStyle{Font=Font(10,FontStyle.Bold)}});
      grid.Columns.Add(new DataGridViewTextBoxColumn{Name="note",HeaderText="공부한 내용",AutoSizeMode=DataGridViewAutoSizeColumnMode.Fill,MinimumWidth=S(80),SortMode=DataGridViewColumnSortMode.NotSortable});
      grid.Columns.Add(new DataGridViewTextBoxColumn{Name="duration",HeaderText="순공시간",Width=S(110),SortMode=DataGridViewColumnSortMode.NotSortable,DefaultCellStyle=new DataGridViewCellStyle{Font=Font(10,FontStyle.Bold),ForeColor=Action,SelectionForeColor=Action}});
      grid.Columns.Add(new DataGridViewTextBoxColumn{Name="when",HeaderText="시간 / 구분",Width=S(135),SortMode=DataGridViewColumnSortMode.NotSortable,DefaultCellStyle=new DataGridViewCellStyle{ForeColor=Sub,SelectionForeColor=Sub}});
      var emptyFont=Font(9.5f);
      grid.Paint+=(s,e)=>{
        using(var pen=new Pen(LineStrong))e.Graphics.DrawLine(pen,0,grid.ColumnHeadersHeight-1,grid.Width,grid.ColumnHeadersHeight-1);
        if(grid.Rows.Count>0)return;var r=new Rectangle(0,grid.ColumnHeadersHeight,grid.Width,Math.Max(0,grid.Height-grid.ColumnHeadersHeight));
        TextRenderer.DrawText(e.Graphics,empty,emptyFont,r,Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.WordBreak);
      };
      grid.Resize+=(s,e)=>grid.Invalidate();
      // 마우스를 올린 줄을 옅게 칠해 어느 기록을 가리키는지 보여줍니다.
      var hoverBack=Mix(Paper,Soft,.85f);
      grid.CellMouseEnter+=(s,e)=>{if(e.RowIndex>=0&&e.RowIndex<grid.Rows.Count)grid.Rows[e.RowIndex].DefaultCellStyle.BackColor=hoverBack;};
      grid.CellMouseLeave+=(s,e)=>{if(e.RowIndex>=0&&e.RowIndex<grid.Rows.Count)grid.Rows[e.RowIndex].DefaultCellStyle.BackColor=Color.Empty;};
    }
  }
  // ───────────────────────── 움직임 ─────────────────────────
  // 길이(ms): 누름·마우스 올림 120, 탭·막대 200, 화면 전환 260, 타이머 숫자 220, 알림 240.
  // Windows 설정 > 접근성 > 시각 효과 > '애니메이션 효과'를 끄면 모든 움직임이 즉시 끝납니다.
  public static class Motion {
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool SystemParametersInfo(uint action,uint param,ref bool value,uint flags);
    public static readonly bool Enabled=Detect();
    public const int Fast=120,Base=200,Page=260,Digit=220,Enter=240;
    static bool Detect() { try { bool on=true;if(SystemParametersInfo(0x1042,0,ref on,0))return on; } catch { } return true; }
    class Tween { public object Key;public Stopwatch Clock;public int Ms;public Action<float> Step;public Action Done; }
    static readonly List<Tween> running=new List<Tween>();static System.Windows.Forms.Timer timer;
    // key가 같은 움직임은 새 것으로 바뀝니다. step(t)의 t는 0→1.
    public static void Run(object key,int ms,Action<float> step,Action done=null) {
      Stop(key);if(!Enabled||ms<=0){step(1f);if(done!=null)done();return;}
      running.Add(new Tween{Key=key,Clock=Stopwatch.StartNew(),Ms=ms,Step=step,Done=done});step(0f);Ensure();
    }
    // 멈출 때까지 계속 도는 움직임. step에는 시작 후 지난 ms가 들어갑니다.
    public static void Loop(object key,Action<float> step) { Stop(key);if(!Enabled)return;running.Add(new Tween{Key=key,Clock=Stopwatch.StartNew(),Ms=-1,Step=step});Ensure(); }
    public static void Stop(object key) { running.RemoveAll(t=>Equals(t.Key,key)); }
    public static bool Active(object key) { return running.Any(t=>Equals(t.Key,key)); }
    static void Ensure() { if(timer==null){timer=new System.Windows.Forms.Timer{Interval=15};timer.Tick+=(s,e)=>Tick();}if(!timer.Enabled)timer.Start(); }
    static void Tick() {
      foreach(var t in running.ToArray()) {
        if(!running.Contains(t))continue;float ms=(float)t.Clock.Elapsed.TotalMilliseconds;
        try { if(t.Ms<0){t.Step(ms);continue;}float p=Math.Min(1f,ms/t.Ms);t.Step(p);if(p>=1f){running.Remove(t);if(t.Done!=null)t.Done();} }
        catch(ObjectDisposedException) { running.Remove(t); }
      }
      if(running.Count==0)timer.Stop();
    }
    public static float Out(float t) { float u=1-t;return 1-u*u*u; }
    public static float InOut(float t) { return t<.5f?4*t*t*t:1-(float)Math.Pow(-2*t+2,3)/2; }
    public static float Lerp(float a,float b,float t) { return a+(b-a)*t; }
    public static float Clamp(float t) { return t<0?0:t>1?1:t; }
    public static void FadeIn(Form f,int ms) { if(!Enabled)return;f.Opacity=0;f.Shown+=(s,e)=>Run(f,ms,t=>f.Opacity=Math.Min(.99,Out(t)),()=>f.Opacity=1); }
  }
  // 화면 전환: 이전 화면은 빠르게 흐려지며 밀려나고, 새 화면은 탭 방향에서 미끄러져 들어옵니다. 클릭하면 바로 끝납니다.
  public class PageFade:Control {
    Bitmap from,to;float t;int dir;readonly object key=new object();
    public PageFade() { SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint,true);Visible=false;TabStop=false; }
    public void Play(Bitmap a,Bitmap b,int direction,Rectangle bounds) {
      Finish();from=a;to=b;dir=direction;Bounds=bounds;Visible=true;BringToFront();Motion.Run(key,Motion.Page,x=>{t=x;Invalidate();Update();},Finish);
    }
    public void Finish() { Motion.Stop(key);Visible=false;if(from!=null){from.Dispose();from=null;}if(to!=null){to.Dispose();to=null;} }
    protected override void OnMouseDown(MouseEventArgs e) { base.OnMouseDown(e);Finish(); }
    static void Draw(Graphics g,Bitmap b,float x,float alpha) {
      if(alpha<=0.01f)return;if(alpha>=.99f){g.DrawImageUnscaled(b,(int)x,0);return;}
      using(var ia=new System.Drawing.Imaging.ImageAttributes()){ia.SetColorMatrix(new System.Drawing.Imaging.ColorMatrix{Matrix33=alpha});g.DrawImage(b,new Rectangle((int)x,0,b.Width,b.Height),0,0,b.Width,b.Height,GraphicsUnit.Pixel,ia);}
    }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(Theme.Bg);if(from==null||to==null)return;float off=Theme.SF(28),ease=Motion.InOut(t);
      Draw(g,from,-dir*off*ease,Math.Max(0,1-t*1.8f));Draw(g,to,dir*off*(1-ease),Motion.Out(Motion.Clamp((t-.12f)/.88f)));
    }
  }
  // 상단 화면 탭. 진한 알약이 고른 탭으로 미끄러지고, 지나가는 동안 글자색도 함께 바뀝니다. ←→ 키로도 이동.
  public class NavBar:Control {
    readonly List<string> keys=new List<string>(),labels=new List<string>();int selected=-1,hover=-1;float pillX,stretch;readonly object mk=new object();
    public event Action<string> TabClicked;public int TabWidth=Theme.S(116),Gap=Theme.S(4);
    public NavBar() { SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw|ControlStyles.Selectable,true);TabStop=true;Font=Theme.Font(10,FontStyle.Bold);Cursor=Cursors.Hand;AccessibleRole=AccessibleRole.PageTabList;AccessibleName="화면 이동"; }
    public void Add(string key,string label) { keys.Add(key);labels.Add(label);Invalidate(); }
    public void SetLabel(string key,string label) { int i=keys.IndexOf(key);if(i>=0&&labels[i]!=label){labels[i]=label;Invalidate();} }
    Rectangle TabRect(int i) { return new Rectangle(i*(TabWidth+Gap),0,TabWidth,Height); }
    public void SetSelected(string key) {
      int i=keys.IndexOf(key);if(i<0||i==selected)return;float to=TabRect(i).X;AccessibleDescription=labels[i]+" 화면";
      if(selected<0||!IsHandleCreated){selected=i;pillX=to;Invalidate();return;}
      float fx=pillX;selected=i;Motion.Run(mk,Motion.Page,t=>{float e=Motion.InOut(t);pillX=Motion.Lerp(fx,to,e);stretch=(float)Math.Sin(Math.PI*e);Invalidate();},()=>{stretch=0;Invalidate();});
    }
    int Hit(Point p) { for(int i=0;i<keys.Count;i++)if(TabRect(i).Contains(p))return i;return -1; }
    protected override void OnMouseMove(MouseEventArgs e) { base.OnMouseMove(e);int h=Hit(e.Location);if(h!=hover){hover=h;Invalidate();} }
    protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e);hover=-1;Invalidate(); }
    protected override void OnMouseDown(MouseEventArgs e) { base.OnMouseDown(e);int h=Hit(e.Location);if(h>=0&&e.Button==MouseButtons.Left&&TabClicked!=null)TabClicked(keys[h]); }
    protected override bool IsInputKey(Keys k) { var key=k&Keys.KeyCode;return key==Keys.Left||key==Keys.Right||base.IsInputKey(k); }
    protected override void OnKeyDown(KeyEventArgs e) {
      base.OnKeyDown(e);if(selected<0||TabClicked==null)return;int n=-1;
      if(e.KeyCode==Keys.Right)n=(selected+1)%keys.Count;else if(e.KeyCode==Keys.Left)n=(selected+keys.Count-1)%keys.Count;
      if(n>=0){TabClicked(keys[n]);e.Handled=true;}
    }
    protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e);Invalidate(); }
    protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e);Invalidate(); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(Theme.Surface(Parent));g.SmoothingMode=SmoothingMode.AntiAlias;
      if(hover>=0&&hover!=selected)Theme.FillRound(g,Theme.Soft,TabRect(hover),Height/2f);
      float grow=stretch*Theme.SF(16),px=pillX-grow/2,pw=TabWidth+grow;
      if(selected>=0)Theme.FillRound(g,Theme.Ink,new RectangleF(px,0,pw,Height),Height/2f);
      for(int i=0;i<keys.Count;i++) {
        var r=TabRect(i);float cover=selected<0?0:Motion.Clamp((Math.Min(px+pw,r.Right)-Math.Max(px,r.X))/r.Width);
        TextRenderer.DrawText(g,labels[i],Font,r,Theme.Mix(Theme.Sub,Color.White,cover),TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.NoPrefix);
      }
      if(Focused&&ShowFocusCues&&selected>=0)Theme.DrawRound(g,Theme.Orange,Theme.SF(1.8f),RectangleF.Inflate(TabRect(selected),-Theme.SF(1.5f),-Theme.SF(1.5f)),Height/2f-Theme.SF(1.5f));
    }
  }
  // 둥근 모서리 카드. 자식 컨트롤은 카드 배경색을 그대로 물려받습니다.
  public class Card:Panel {
    public Color BorderColor=Theme.Line;public int Radius=14;
    public Card() { SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw,true);BackColor=Theme.Paper;Padding=new Padding(Theme.S(22));Margin=new Padding(0,0,Theme.S(16),Theme.S(16)); }
    protected override void OnPaintBackground(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(Parent!=null?Theme.Surface(Parent):Theme.Bg);g.SmoothingMode=SmoothingMode.AntiAlias;
      var r=new RectangleF(.5f,.5f,Width-1.5f,Height-1.5f);float rad=Theme.SF(Radius);
      Theme.FillRound(g,BackColor,r,rad);if(BorderColor!=Color.Empty)Theme.DrawRound(g,BorderColor,1f,r,rad);
    }
  }
  public class Btn:Button {
    ButtonKind kind;bool selectedTab;float hoverT,downT,kindT=1;Color fromFill=Color.Empty;public int Radius=10;readonly object hk=new object(),dk=new object(),kk=new object();
    // 종류가 바뀌면(공부 시작 ↔ 잠시 쉬기) 색이 부드럽게 넘어갑니다.
    public ButtonKind Kind { get{return kind;} set{if(kind!=value){Color f,h,b,t;Look(kind,Theme.Surface(Parent),out f,out h,out b,out t);fromFill=f;kind=value;Motion.Run(kk,Motion.Base,x=>{kindT=Motion.Out(x);Invalidate();});}} }
    public bool Selected { get{return selectedTab;} set{if(selectedTab!=value){selectedTab=value;AccessibleDescription=value?"현재 화면":null;Invalidate();}} }
    public Btn(string text,ButtonKind k) {
      SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw,true);
      Text=text;kind=k;FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;UseVisualStyleBackColor=false;Cursor=Cursors.Hand;Font=Theme.Font(10,FontStyle.Bold);Height=Theme.S(42);Margin=new Padding(0,0,Theme.S(10),0);UseMnemonic=false;
    }
    void Hover(float to,int ms) { float from=hoverT;Motion.Run(hk,ms,t=>{hoverT=Motion.Lerp(from,to,Motion.Out(t));Invalidate();}); }
    void Press(float to,int ms) { float from=downT;Motion.Run(dk,ms,t=>{downT=Motion.Lerp(from,to,Motion.Out(t));Invalidate();}); }
    protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e);Hover(1,Motion.Fast); }
    protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e);Hover(0,Motion.Fast+60);Press(0,Motion.Fast); }
    protected override void OnMouseDown(MouseEventArgs e) { base.OnMouseDown(e);if(e.Button==MouseButtons.Left)Press(1,70); }
    protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e);Press(0,Motion.Fast+60); }
    protected override void OnEnabledChanged(EventArgs e) { base.OnEnabledChanged(e);Invalidate(); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    // 종류별 기본색·마우스를 올렸을 때 색·테두리·글자색
    void Look(ButtonKind k,Color surface,out Color fill,out Color hot,out Color border,out Color text) {
      border=Color.Empty;text=Theme.Ink;
      switch(k) {
        case ButtonKind.Primary: fill=Theme.Action;hot=Theme.Mix(Theme.Action,Color.Black,.09f);text=Color.White;break;
        case ButtonKind.Dark: fill=Theme.Ink;hot=Theme.Mix(Theme.Ink,Color.White,.11f);text=Color.White;break;
        case ButtonKind.Ghost: fill=surface;hot=Theme.Soft;text=Theme.Sub;break;
        case ButtonKind.Nav: if(selectedTab){fill=Theme.Ink;hot=Theme.Mix(Theme.Ink,Color.White,.1f);text=Color.White;}else{fill=surface;hot=Theme.Soft;text=Theme.Sub;}break;
        case ButtonKind.Danger: fill=Theme.Paper;hot=Theme.DangerSoft;border=Theme.Mix(Theme.Danger,Color.White,.62f);text=Theme.Danger;break;
        default: fill=Theme.Paper;hot=Theme.Soft;border=Theme.LineStrong;break;
      }
    }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;Color surface=Theme.Surface(Parent);g.Clear(surface);g.SmoothingMode=SmoothingMode.AntiAlias;
      Color fill,hot,border,text;Look(kind,surface,out fill,out hot,out border,out text);
      fill=Theme.Mix(fill,hot,Enabled?hoverT:0);fill=Theme.Mix(fill,Theme.Mix(hot,Color.Black,.07f),Enabled?downT:0);if(kindT<1&&fromFill!=Color.Empty)fill=Theme.Mix(fromFill,fill,kindT);
      if(!Enabled){text=Theme.Disabled;if(kind==ButtonKind.Primary||kind==ButtonKind.Dark)fill=Theme.Track;if(border!=Color.Empty)border=Theme.Line;}
      // 누르면 살짝 작아져 손끝에 닿는 느낌을 줍니다.
      float inset=Enabled?downT*Theme.SF(1.5f):0;var r=new RectangleF(.5f+inset,.5f+inset,Width-1.5f-inset*2,Height-1.5f-inset*2);float rad=Radius<0?r.Height/2f:Theme.SF(Radius);
      if(fill!=surface)Theme.FillRound(g,fill,r,rad);if(border!=Color.Empty)Theme.DrawRound(g,border,1f,r,rad);
      TextRenderer.DrawText(g,Text,Font,ClientRectangle,text,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
      if(Focused&&ShowFocusCues) { var f=RectangleF.Inflate(r,-Theme.SF(2.5f),-Theme.SF(2.5f));Theme.DrawRound(g,(kind==ButtonKind.Primary||kind==ButtonKind.Dark||(kind==ButtonKind.Nav&&selectedTab))?Color.FromArgb(230,255,255,255):Theme.Orange,Theme.SF(1.6f),f,Math.Max(2,rad-Theme.SF(2.5f))); }
    }
  }
  // 둥근 입력칸. 안쪽 TextBox/NumericUpDown/ListBox는 테두리 없이 들어가고, 포커스가 오면 테두리가 주황색이 됩니다.
  public class Field:Panel {
    public readonly Control Inner;readonly bool fill;
    public Field(Control inner) {
      SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw,true);
      Inner=inner;var tb=inner as TextBox;fill=(tb!=null&&tb.Multiline)||inner is ListBox;Controls.Add(inner);Cursor=fill&&inner is ListBox?Cursors.Default:Cursors.IBeam;
      inner.GotFocus+=(s,e)=>Invalidate();inner.LostFocus+=(s,e)=>Invalidate();inner.EnabledChanged+=(s,e)=>Sync();Click+=(s,e)=>inner.Focus();Sync();
    }
    void Sync() { Color c=Inner.Enabled?Theme.Paper:Theme.FieldOff;Inner.BackColor=c;BackColor=c;Invalidate(); }
    protected override void OnLayout(LayoutEventArgs e) {
      base.OnLayout(e);int px=Theme.S(fill&&Inner is ListBox?6:11);
      if(fill)Inner.SetBounds(px,Theme.S(7),Math.Max(10,Width-px-Theme.S(5)),Math.Max(10,Height-Theme.S(13)));
      else { int h=Inner.Height;Inner.SetBounds(px,Math.Max(0,(Height-h)/2),Math.Max(10,Width-px-Theme.S(Inner is NumericUpDown?4:9)),h); }
    }
    protected override void OnPaintBackground(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(Parent!=null?Theme.Surface(Parent):Theme.Paper);g.SmoothingMode=SmoothingMode.AntiAlias;bool focus=Inner.ContainsFocus;
      var r=new RectangleF(.5f,.5f,Width-1.5f,Height-1.5f);float rad=Theme.SF(9);Theme.FillRound(g,BackColor,r,rad);
      if(focus)Theme.DrawRound(g,Theme.Orange,Theme.SF(1.6f),RectangleF.Inflate(r,-Theme.SF(.4f),-Theme.SF(.4f)),rad);else Theme.DrawRound(g,Inner.Enabled?Theme.LineStrong:Theme.Line,1f,r,rad);
    }
  }
  public class MenuColors:ProfessionalColorTable {
    public override Color MenuItemSelected { get{return Theme.OrangeSoft;} }
    public override Color MenuItemBorder { get{return Theme.OrangeSoft;} }
    public override Color MenuBorder { get{return Theme.LineStrong;} }
    public override Color ToolStripDropDownBackground { get{return Theme.Paper;} }
    public override Color ImageMarginGradientBegin { get{return Theme.Paper;} }
    public override Color ImageMarginGradientMiddle { get{return Theme.Paper;} }
    public override Color ImageMarginGradientEnd { get{return Theme.Paper;} }
    public override Color CheckBackground { get{return Theme.Paper;} }
    public override Color CheckSelectedBackground { get{return Theme.OrangeSoft;} }
    public override Color CheckPressedBackground { get{return Theme.OrangeSoft;} }
  }
  // 과목 선택 상자. 예전 ComboBox처럼 Items·SelectedItem·SelectedIndex·Text로 쓰고, 목록은 메뉴로 펼쳐집니다.
  // 키보드: ↑↓로 바로 바꾸고, Space·F4·Alt+↓로 목록을 엽니다.
  public class Picker:Control {
    public readonly List<object> Items=new List<object>();int index=-1;bool hover;readonly ContextMenuStrip menu;
    public Picker() {
      SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw|ControlStyles.Selectable,true);
      TabStop=true;Cursor=Cursors.Hand;BackColor=Theme.Paper;AccessibleRole=AccessibleRole.ComboBox;
      menu=new ContextMenuStrip{Renderer=new ToolStripProfessionalRenderer(new MenuColors()){RoundedEdges=false},ShowImageMargin=false,ShowCheckMargin=true};menu.Closed+=(s,e)=>Invalidate();
    }
    public int SelectedIndex { get{return index<Items.Count?index:-1;} set{index=value>=0&&value<Items.Count?value:-1;AccessibleDescription=Text;Invalidate();} }
    public object SelectedItem { get{int i=SelectedIndex;return i>=0?Items[i]:null;} set{SelectedIndex=value==null?-1:Items.IndexOf(value);} }
    public override string Text { get{object o=SelectedItem;return o==null?"":o.ToString();} set{SelectedIndex=Items.FindIndex(o=>o.ToString()==value);} }
    void Open() {
      if(!Enabled||Items.Count==0)return;menu.Items.Clear();
      for(int i=0;i<Items.Count;i++){int k=i;var item=new ToolStripMenuItem(Items[i].ToString().Replace("&","&&")){Checked=i==SelectedIndex,Font=Font,Padding=new Padding(0,Theme.S(5),0,Theme.S(5))};item.Click+=(s,e)=>{SelectedIndex=k;Focus();};menu.Items.Add(item);}
      menu.MinimumSize=new Size(Width,0);Invalidate();menu.Show(this,new Point(0,Height+Theme.S(4)));
    }
    protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e);hover=true;Invalidate(); }
    protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e);hover=false;Invalidate(); }
    protected override void OnMouseDown(MouseEventArgs e) { base.OnMouseDown(e);if(e.Button==MouseButtons.Left){Focus();Open();} }
    protected override bool IsInputKey(Keys k) { var key=k&Keys.KeyCode;return key==Keys.Up||key==Keys.Down||base.IsInputKey(k); }
    protected override void OnKeyDown(KeyEventArgs e) {
      base.OnKeyDown(e);if(!Enabled||Items.Count==0)return;
      if((e.KeyCode==Keys.Down&&e.Alt)||e.KeyCode==Keys.F4||e.KeyCode==Keys.Space){Open();e.Handled=true;}
      else if(e.KeyCode==Keys.Down){SelectedIndex=Math.Min(Items.Count-1,SelectedIndex+1);e.Handled=true;}
      else if(e.KeyCode==Keys.Up){SelectedIndex=Math.Max(0,SelectedIndex-1);e.Handled=true;}
    }
    protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e);Invalidate(); }
    protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e);Invalidate(); }
    protected override void OnEnabledChanged(EventArgs e) { base.OnEnabledChanged(e);Invalidate(); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(Theme.Surface(Parent));g.SmoothingMode=SmoothingMode.AntiAlias;bool open=menu.Visible,focus=(Focused||open)&&Enabled;
      var r=new RectangleF(.5f,.5f,Width-1.5f,Height-1.5f);float rad=Theme.SF(9);
      Theme.FillRound(g,!Enabled?Theme.FieldOff:hover||open?Theme.Mix(Theme.Paper,Theme.Soft,.6f):Theme.Paper,r,rad);
      if(focus)Theme.DrawRound(g,Theme.Orange,Theme.SF(1.6f),RectangleF.Inflate(r,-Theme.SF(.4f),-Theme.SF(.4f)),rad);else Theme.DrawRound(g,Enabled?Theme.LineStrong:Theme.Line,1f,r,rad);
      int arrow=Theme.S(30);
      TextRenderer.DrawText(g,Text,Font,new Rectangle(Theme.S(12),0,Math.Max(0,Width-Theme.S(12)-arrow),Height),Enabled?Theme.Ink:Theme.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
      float cx=Width-arrow/2f-Theme.SF(2),cy=Height/2f,s=Theme.SF(4);
      using(var pen=new Pen(Enabled?Theme.Sub:Theme.Disabled,Theme.SF(1.7f)){StartCap=LineCap.Round,EndCap=LineCap.Round,LineJoin=LineJoin.Round})g.DrawLines(pen,open?new[]{new PointF(cx-s,cy+s/2),new PointF(cx,cy-s/2),new PointF(cx+s,cy+s/2)}:new[]{new PointF(cx-s,cy-s/2),new PointF(cx,cy+s/2),new PointF(cx+s,cy-s/2)});
    }
  }
  // 상태 배지. 점과 글자를 둥근 알약 모양 안에 표시합니다.
  public class Pill:Control {
    Color tone=Theme.Green,fromTone=Theme.Green;float toneT=1,appear=1,pulse;bool pulseOn;public bool AlignLeft,Animate;readonly object tk=new object(),ak=new object(),pk=new object();
    Color Current { get{return Theme.Mix(fromTone,tone,toneT);} }
    public Color Tone { get{return tone;} set{if(tone!=value){fromTone=Current;tone=value;Motion.Run(tk,Motion.Base,t=>{toneT=t;Invalidate();});}} }
    // 집중하는 동안 점이 천천히 숨 쉬듯 빛납니다.
    public bool Pulse { get{return pulseOn;} set{if(pulseOn==value)return;pulseOn=value;if(value)Motion.Loop(pk,ms=>{pulse=(float)((ms%1800)/1800.0);Invalidate();});else{Motion.Stop(pk);pulse=0;Invalidate();}} }
    public Pill() { SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw|ControlStyles.SupportsTransparentBackColor,true);BackColor=Color.Transparent;Font=Theme.Font(9,FontStyle.Bold);TabStop=false;AccessibleRole=AccessibleRole.StaticText; }
    protected override void OnTextChanged(EventArgs e) {
      base.OnTextChanged(e);AccessibleName=Text;
      if(Animate&&!string.IsNullOrEmpty(Text))Motion.Run(ak,Motion.Enter,t=>{appear=Motion.Out(t);Invalidate();});else Invalidate();
    }
    // 오른쪽으로 살짝 빠지며 사라집니다(들어올 때보다 빠르게).
    public void Dismiss() { if(string.IsNullOrEmpty(Text))return;float a0=appear;Motion.Run(ak,150,t=>{appear=a0*(1-t);Invalidate();},()=>{Text="";appear=1;}); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;Color surface=Theme.Surface(Parent);g.Clear(surface);if(string.IsNullOrEmpty(Text)||appear<=0.01f)return;g.SmoothingMode=SmoothingMode.AntiAlias;
      Color tn=Current;float a=appear;int pad=Theme.S(12),dot=Theme.S(7),gap=Theme.S(7),slide=(int)((1-a)*Theme.SF(14));
      var ts=TextRenderer.MeasureText(g,Text,Font,new Size(int.MaxValue,Height),TextFormatFlags.NoPadding|TextFormatFlags.SingleLine|TextFormatFlags.NoPrefix);
      int w=Math.Min(Width-slide,pad*2+dot+gap+ts.Width+Theme.S(2)),x=(AlignLeft?0:Width-w-slide)+(AlignLeft?slide:0);
      Theme.FillRound(g,Theme.Mix(surface,Theme.Mix(surface,tn,.13f),a),new RectangleF(x+.5f,.5f,w-1f,Height-1f),Height/2f);
      float cx=x+pad+dot/2f,cy=Height/2f;
      if(pulseOn){float r=dot/2f+pulse*Theme.SF(5);using(var b=new SolidBrush(Color.FromArgb((int)(110*(1-pulse)*a),tn)))g.FillEllipse(b,cx-r,cy-r,r*2,r*2);}
      using(var b=new SolidBrush(Theme.Mix(surface,tn,a)))g.FillEllipse(b,cx-dot/2f,cy-dot/2f,dot,dot);
      TextRenderer.DrawText(g,Text,Font,new Rectangle(x+pad+dot+gap,0,Math.Max(0,w-pad*2-dot-gap+Theme.S(2)),Height),Theme.Mix(surface,Theme.Mix(tn,Theme.Ink,.35f),a),TextFormatFlags.VerticalCenter|TextFormatFlags.Left|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPadding|TextFormatFlags.NoPrefix);
    }
  }
  public class GoalBar:Control {
    int value;float shown,shine=-1;public Color FillColor=Theme.Orange,TrackColor=Theme.Track;readonly object vk=new object(),sk=new object();
    // 값이 바뀌면 막대가 그 자리까지 부드럽게 차오릅니다.
    public int Value { get{return value;} set{int v=Math.Max(0,Math.Min(100,value));if(v!=this.value){this.value=v;float from=shown;Motion.Run(vk,450,t=>{shown=Motion.Lerp(from,v,Motion.Out(t));Invalidate();});}} }
    // 목표를 달성한 순간: 막대 위로 빛이 한 번 지나갑니다.
    public void Celebrate() { Motion.Run(sk,1100,t=>{shine=t;Invalidate();},()=>{shine=-1;Invalidate();}); }
    public GoalBar() { SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw,true);TabStop=false;AccessibleRole=AccessibleRole.ProgressBar;AccessibleName="하루 목표 달성률"; }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(Theme.Surface(Parent));g.SmoothingMode=SmoothingMode.AntiAlias;var r=new RectangleF(0,0,Width,Height);
      Theme.FillRound(g,TrackColor,r,Height/2f);
      if(shown>0.2f){var fr=new RectangleF(0,0,Math.Max(Height,Width*shown/100f),Height);Theme.FillRound(g,FillColor,fr,Height/2f);
        if(shine>=0)using(var clip=Theme.Round(fr,Height/2f)){var old=g.Clip;g.SetClip(clip,CombineMode.Intersect);float band=Math.Max(Height*6,Width*.18f),x=-band+Motion.InOut(shine)*(fr.Width+band*2);
          using(var b=new LinearGradientBrush(new RectangleF(x,0,band,Height),Color.FromArgb(0,255,255,255),Color.FromArgb(0,255,255,255),0f)){var blend=new ColorBlend{Colors=new[]{Color.FromArgb(0,255,255,255),Color.FromArgb(170,255,240,220),Color.FromArgb(0,255,255,255)},Positions=new[]{0f,.5f,1f}};b.InterpolationColors=blend;g.FillRectangle(b,x,0,band,Height);}
          g.Clip=old;}}
      AccessibleDescription=value+"%";
    }
  }
  public class TimerFace:Control {
    string shown="00:00:00",from;float roll=1;readonly object rk=new object();public bool Running,Idle=true,OnDark;Font cache;float cacheSize;
    // 바뀐 자리의 숫자만 아래에서 위로 굴러 올라옵니다.
    public string TimeText { get{return shown;} set{if(value==null||value==shown)return;from=shown;shown=value;if(from.Length!=shown.Length){from=null;Invalidate();return;}Motion.Run(rk,Motion.Digit,t=>{roll=t;Invalidate();},()=>{from=null;Invalidate();});} }
    public TimerFace() { SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw,true);BackColor=Theme.Paper;AccessibleName="현재 공부 시간";AccessibleRole=AccessibleRole.StaticText;TabStop=false; }
    static Font Make(float px) {
      foreach(var name in new[]{"Segoe UI Light","Segoe UI"}) { try { return new Font(new FontFamily(name),px,FontStyle.Regular,GraphicsUnit.Pixel); } catch(ArgumentException) { } }
      return new Font(FontFamily.GenericSansSerif,px,FontStyle.Regular,GraphicsUnit.Pixel);
    }
    Font Face(float px) { if(cache==null||Math.Abs(cacheSize-px)>.5f){if(cache!=null)cache.Dispose();cache=Make(px);cacheSize=px;}return cache; }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(BackColor);g.TextRenderingHint=System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;var fmt=StringFormat.GenericTypographic;
      float px=Height*1.02f,gap=Theme.SF(4);Font f=Face(px);
      Func<Font,float> dw=ff=>g.MeasureString("0",ff,PointF.Empty,fmt).Width;Func<Font,float> cw=ff=>g.MeasureString(":",ff,PointF.Empty,fmt).Width+gap*2;
      Func<Font,float> widthOf=ff=>shown.Sum(ch=>ch==':'?cw(ff):dw(ff));
      float total=widthOf(f);if(total>Width*.94f){f=Face(px*Width*.94f/total);total=widthOf(f);}
      Color digit=Idle?Theme.Mix(Theme.Ink,Theme.Paper,.42f):Running?Theme.Ink:Theme.Sub,colon=Running?Theme.Orange:Theme.LineStrong;
      if(OnDark){digit=Idle?Theme.Mix(Color.White,BackColor,.5f):Running?Color.White:Theme.NightText;colon=Running?Theme.Orange:Theme.NightTrack;}
      var ff2=f.FontFamily;float ascent=f.Size*ff2.GetCellAscent(f.Style)/ff2.GetEmHeight(f.Style),cap=f.Size*.7f,top=(Height+cap)/2f-ascent;
      float x=(Width-total)/2,d=dw(f),c=cw(f),travel=cap*.75f,ease=Motion.Out(roll);
      for(int i=0;i<shown.Length;i++) {
        char ch=shown[i];
        if(ch==':'){using(var b=new SolidBrush(colon))g.DrawString(":",f,b,x+gap,top-Theme.SF(3),fmt);x+=c;continue;}
        if(from!=null&&roll<1&&i<from.Length&&from[i]!=ch) {
          var old=g.Clip;g.SetClip(new RectangleF(x-2,0,d+4,Height),CombineMode.Intersect);
          using(var b=new SolidBrush(Color.FromArgb((int)(255*(1-ease)),digit)))g.DrawString(from[i].ToString(),f,b,x,top-ease*travel,fmt);
          using(var b=new SolidBrush(Color.FromArgb((int)(255*ease),digit)))g.DrawString(ch.ToString(),f,b,x,top+(1-ease)*travel,fmt);
          g.Clip=old;
        } else using(var b=new SolidBrush(digit))g.DrawString(ch.ToString(),f,b,x,top,fmt);
        x+=d;
      }
    }
  }
  public class WeekChart:Control {
    public double[] Values=new double[7];public DateTime Week;public int TodayIndex;public double Goal;Font small,bold;double[] shownV=new double[7];readonly object ak=new object();
    // 막대가 월요일부터 차례로(40ms 간격) 자라납니다. 몇 초 단위의 작은 변화는 바로 반영.
    public void SetValues(double[] v) {
      double diff=Enumerable.Range(0,7).Max(i=>Math.Abs(v[i]-shownV[i]));Values=v;
      if(diff<120&&!Motion.Active(ak)){shownV=(double[])v.Clone();Invalidate();return;}
      var from=(double[])shownV.Clone();int each=420,total=each+6*40;
      Motion.Run(ak,total,t=>{float ms=t*total;for(int i=0;i<7;i++){float ti=Motion.Out(Motion.Clamp((ms-i*40)/each));shownV[i]=from[i]+(Values[i]-from[i])*ti;}Invalidate();});
    }
    public WeekChart() { SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw,true);BackColor=Theme.Paper;small=Theme.Font(8);bold=Theme.Font(8,FontStyle.Bold);AccessibleName="이번 주 공부 시간 그래프";TabStop=false; }
    static string Short(double sec) { long m=(long)(sec/60);return string.Format("{0}:{1:00}",m/60,m%60); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(BackColor);g.SmoothingMode=SmoothingMode.AntiAlias;string[] labels={"월","화","수","목","금","토","일"};
      double max=Math.Max(3600,Math.Max(Goal,Math.Max(Values.Max(),shownV.Max())));int top=Theme.S(20),bottom=Height-Theme.S(24),chartH=Math.Max(10,bottom-top);float slot=Width/7f,bw=Math.Min(Theme.SF(20),slot*.48f);
      var desc=new StringBuilder();
      for(int i=0;i<7;i++) {
        float cx=slot*i+slot/2f;bool today=i==TodayIndex;
        Theme.FillRound(g,Theme.Track,new RectangleF(cx-bw/2,top,bw,chartH),bw/2);
        if(shownV[i]>0.5){float h=(float)Math.Max(bw,shownV[i]/max*chartH);Theme.FillRound(g,today?Theme.Orange:Theme.Bar,new RectangleF(cx-bw/2,bottom-h,bw,h),bw/2);
          TextRenderer.DrawText(g,Short(shownV[i]),today?bold:small,new Rectangle((int)(slot*i),(int)(bottom-h)-Theme.S(18),(int)slot,Theme.S(16)),today?Theme.Action:Theme.Sub,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.NoPadding);}
        TextRenderer.DrawText(g,labels[i],today?bold:small,new Rectangle((int)(slot*i),bottom+Theme.S(4),(int)slot,Theme.S(20)),today?Theme.Action:Theme.Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);
        desc.Append(labels[i]).Append(' ').Append(Logic.Duration(Values[i])).Append(i<6?", ":"");
      }
      if(Goal>0&&Values.Max()>Goal){float y=(float)(bottom-Goal/max*chartH);using(var pen=new Pen(Theme.Mix(Theme.Orange,Theme.Paper,.35f),Theme.SF(1.2f)){DashStyle=DashStyle.Dash})g.DrawLine(pen,0,y,Width,y);}
      AccessibleDescription=desc.ToString();
    }
  }
  // 달력: 공부한 양만큼 날짜 칸이 진하게 칠해집니다. 화살표 키·PageUp/PageDown·마우스 휠로 움직일 수 있어요.
  public class StudyCalendar:Control {
    DateTime month,sel,max;int hover=-1;bool hoverPrev,hoverNext;public Dictionary<DateTime,double> Amounts=new Dictionary<DateTime,double>();public double Goal=4*3600;
    public event EventHandler DateChanged;readonly Font day,dayBold,head,small;
    static readonly Color[] Heat={Color.Empty,Color.FromArgb(226,236,214),Color.FromArgb(194,215,168),Color.FromArgb(146,182,112),Color.FromArgb(84,122,66)};
    public StudyCalendar() {
      SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw|ControlStyles.Selectable,true);
      TabStop=true;BackColor=Theme.Paper;max=DateTime.Today;sel=max;month=First(sel);day=Theme.Font(9.5f);dayBold=Theme.Font(9.5f,FontStyle.Bold);head=Theme.Font(11,FontStyle.Bold);small=Theme.Font(8);AccessibleName="공부 달력";AccessibleRole=AccessibleRole.Table;Describe();
    }
    static DateTime First(DateTime d) { return new DateTime(d.Year,d.Month,1); }
    void Describe() { AccessibleDescription=sel.ToString("yyyy년 M월 d일 dddd")+" 선택됨"; }
    public DateTime SelectionStart { get{return sel;} }
    public DateTime MaxDate { get{return max;} set{max=value.Date;Invalidate();} }
    public void SetDate(DateTime d) { d=d.Date;if(d>max)d=max;bool changed=d!=sel;sel=d;GoMonth(d);Describe();Invalidate();if(changed&&DateChanged!=null)DateChanged(this,EventArgs.Empty); }
    // 달을 넘기면 날짜 칸이 그 방향으로 미끄러집니다.
    Bitmap slideFrom;float slideT=1;int slideDir;readonly object sk=new object();
    void GoMonth(DateTime m) {
      m=First(m);if(m==month)return;int dir=m>month?1:-1;
      if(Motion.Enabled&&IsHandleCreated&&Visible&&Width>0&&Height>0) {
        var old=new Bitmap(Width,Height);using(var g=Graphics.FromImage(old))PaintAll(g);month=m;
        if(slideFrom!=null)slideFrom.Dispose();slideFrom=old;slideDir=dir;
        Motion.Run(sk,Motion.Enter+40,t=>{slideT=t;Invalidate();},()=>{if(slideFrom!=null){slideFrom.Dispose();slideFrom=null;}Invalidate();});
      } else month=m;
      Invalidate();
    }
    int HeadH { get{return Theme.S(36);} } int WeekH { get{return Theme.S(24);} } int LegendH { get{return Theme.S(26);} }
    DateTime Start { get{return month.AddDays(-(((int)month.DayOfWeek+6)%7));} }
    Rectangle Cell(int i) { int gw=Width,gh=Math.Max(6,Height-HeadH-WeekH-LegendH),cw=gw/7,ch=gh/6,ox=(gw-cw*7)/2;return new Rectangle(ox+i%7*cw,HeadH+WeekH+i/7*ch,cw,ch); }
    Rectangle PrevRect { get{return new Rectangle(Width-Theme.S(66),Theme.S(4),Theme.S(30),Theme.S(28));} }
    Rectangle NextRect { get{return new Rectangle(Width-Theme.S(32),Theme.S(4),Theme.S(30),Theme.S(28));} }
    bool CanNext { get{return First(max)>month;} }
    int Hit(Point p) { for(int i=0;i<42;i++)if(Cell(i).Contains(p))return i;return -1; }
    void Chevron(Graphics g,Rectangle r,bool left,bool enabled,bool hot) {
      if(hot&&enabled)Theme.FillRound(g,Theme.Soft,r,Theme.SF(8));float cx=r.X+r.Width/2f,cy=r.Y+r.Height/2f,s=Theme.SF(4);
      using(var pen=new Pen(enabled?Theme.Sub:Theme.Line,Theme.SF(1.8f)){StartCap=LineCap.Round,EndCap=LineCap.Round,LineJoin=LineJoin.Round})
        g.DrawLines(pen,left?new[]{new PointF(cx+s/2,cy-s),new PointF(cx-s/2,cy),new PointF(cx+s/2,cy+s)}:new[]{new PointF(cx-s/2,cy-s),new PointF(cx+s/2,cy),new PointF(cx-s/2,cy+s)});
    }
    int Level(double v) { if(v<=0)return 0;double goal=Math.Max(900,Goal);return v<goal*.25?1:v<goal*.5?2:v<goal?3:4; }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      if(slideFrom==null||slideT>=1){PaintAll(e.Graphics);return;}
      var g=e.Graphics;using(var now=new Bitmap(Width,Height)){using(var ng=Graphics.FromImage(now))PaintAll(ng);
        g.DrawImageUnscaled(now,0,0);int top=HeadH+WeekH,h=Math.Max(1,Height-top-LegendH);var area=new Rectangle(0,top,Width,h);
        using(var b=new SolidBrush(BackColor))g.FillRectangle(b,area);float ease=Motion.InOut(slideT),off=Width*.28f;
        var old=g.Clip;g.SetClip(area);
        using(var ia=new System.Drawing.Imaging.ImageAttributes()){ia.SetColorMatrix(new System.Drawing.Imaging.ColorMatrix{Matrix33=Math.Max(0,1-slideT*1.7f)});g.DrawImage(slideFrom,new Rectangle((int)(-slideDir*off*ease),top,Width,h),0,top,Width,h,GraphicsUnit.Pixel,ia);}
        using(var ia=new System.Drawing.Imaging.ImageAttributes()){ia.SetColorMatrix(new System.Drawing.Imaging.ColorMatrix{Matrix33=Motion.Out(Motion.Clamp((slideT-.1f)/.9f))});g.DrawImage(now,new Rectangle((int)(slideDir*off*(1-ease)),top,Width,h),0,top,Width,h,GraphicsUnit.Pixel,ia);}
        g.Clip=old;}
    }
    void PaintAll(Graphics g) {
      g.Clear(BackColor);g.SmoothingMode=SmoothingMode.AntiAlias;var flags=TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.NoPadding;
      TextRenderer.DrawText(g,month.ToString("yyyy년 M월"),head,new Rectangle(Theme.S(4),0,Width-Theme.S(80),HeadH),Theme.Ink,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine);
      Chevron(g,PrevRect,true,true,hoverPrev);Chevron(g,NextRect,false,CanNext,hoverNext);
      string[] names={"월","화","수","목","금","토","일"};
      for(int i=0;i<7;i++){var c=Cell(i);TextRenderer.DrawText(g,names[i],small,new Rectangle(c.X,HeadH,c.Width,WeekH),Theme.Muted,flags);}
      DateTime start=Start,today=DateTime.Today;
      for(int i=0;i<42;i++) {
        DateTime d=start.AddDays(i);var c=Cell(i);bool inMonth=d.Month==month.Month,future=d>max,isSel=d==sel;double v;Amounts.TryGetValue(d,out v);int lv=Level(v);
        float size=Math.Max(4,Math.Min(c.Width,c.Height)-Theme.SF(5));var box=new RectangleF(c.X+(c.Width-size)/2f,c.Y+(c.Height-size)/2f,size,size);float rad=Theme.SF(8);
        if(lv>0)Theme.FillRound(g,inMonth?Heat[lv]:Theme.Mix(Heat[lv],Theme.Paper,.55f),box,rad);
        else if(hover==i&&!future)Theme.FillRound(g,Theme.Soft,box,rad);
        if(isSel){Theme.DrawRound(g,Theme.Orange,Theme.SF(2.2f),RectangleF.Inflate(box,-Theme.SF(1),-Theme.SF(1)),rad);if(Focused&&ShowFocusCues)Theme.DrawRound(g,Theme.Mix(Theme.Orange,Theme.Paper,.55f),Theme.SF(1.2f),RectangleF.Inflate(box,Theme.SF(1.5f),Theme.SF(1.5f)),rad+Theme.SF(1.5f));}
        Color text=future?Theme.Mix(Theme.Disabled,Theme.Paper,.35f):!inMonth?Theme.Disabled:lv==4?Color.White:Theme.Ink;if(d==today&&lv<4&&!isSel)text=Theme.Action;
        TextRenderer.DrawText(g,d.Day.ToString(),d==today||isSel?dayBold:day,Rectangle.Round(box),text,flags);
        if(d==today)using(var b=new SolidBrush(lv==4?Color.White:Theme.Orange))g.FillEllipse(b,box.X+box.Width/2-Theme.SF(2),box.Bottom-Theme.SF(7),Theme.SF(4),Theme.SF(4));
      }
      int ly=Height-LegendH+Theme.S(6),sq=Theme.S(11),lx=Width-Theme.S(4)-sq*4-Theme.S(3)*3;
      var more=TextRenderer.MeasureText(g,"많이",small);var less=TextRenderer.MeasureText(g,"적게",small);
      lx-=more.Width+Theme.S(6);TextRenderer.DrawText(g,"적게",small,new Point(lx-less.Width-Theme.S(6),ly+(sq-less.Height)/2),Theme.Muted);
      for(int i=1;i<=4;i++)Theme.FillRound(g,Heat[i],new RectangleF(lx+(i-1)*(sq+Theme.S(3)),ly,sq,sq),Theme.SF(3));
      TextRenderer.DrawText(g,"많이",small,new Point(lx+sq*4+Theme.S(3)*3+Theme.S(6),ly+(sq-more.Height)/2),Theme.Muted);
      TextRenderer.DrawText(g,"목표 대비",small,new Point(Theme.S(4),ly+(sq-less.Height)/2),Theme.Muted);
    }
    protected override void OnMouseMove(MouseEventArgs e) { base.OnMouseMove(e);int h=Hit(e.Location);bool p=PrevRect.Contains(e.Location),n=NextRect.Contains(e.Location);if(h!=hover||p!=hoverPrev||n!=hoverNext){hover=h;hoverPrev=p;hoverNext=n;Invalidate();}Cursor=(p||(n&&CanNext)||(h>=0&&Start.AddDays(h)<=max))?Cursors.Hand:Cursors.Default; }
    protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e);hover=-1;hoverPrev=hoverNext=false;Invalidate(); }
    protected override void OnMouseDown(MouseEventArgs e) {
      base.OnMouseDown(e);Focus();if(e.Button!=MouseButtons.Left)return;
      if(PrevRect.Contains(e.Location)){GoMonth(month.AddMonths(-1));return;}
      if(NextRect.Contains(e.Location)){if(CanNext)GoMonth(month.AddMonths(1));return;}
      int h=Hit(e.Location);if(h>=0){DateTime d=Start.AddDays(h);if(d<=max)SetDate(d);}
    }
    protected override void OnMouseWheel(MouseEventArgs e) { base.OnMouseWheel(e);if(e.Delta>0)GoMonth(month.AddMonths(-1));else if(CanNext)GoMonth(month.AddMonths(1)); }
    protected override bool IsInputKey(Keys k) { var key=k&Keys.KeyCode;return key==Keys.Left||key==Keys.Right||key==Keys.Up||key==Keys.Down||base.IsInputKey(k); }
    protected override void OnKeyDown(KeyEventArgs e) {
      base.OnKeyDown(e);DateTime? n=null;
      switch(e.KeyCode){case Keys.Left:n=sel.AddDays(-1);break;case Keys.Right:n=sel.AddDays(1);break;case Keys.Up:n=sel.AddDays(-7);break;case Keys.Down:n=sel.AddDays(7);break;case Keys.PageUp:n=sel.AddMonths(-1);break;case Keys.PageDown:n=sel.AddMonths(1);break;case Keys.Home:n=max;break;}
      if(n.HasValue){SetDate(n.Value>max?max:n.Value);e.Handled=true;}
    }
    protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e);Invalidate(); }
    protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e);Invalidate(); }
  }
  // 날짜별 과목 합계를 짧은 막대로 보여줍니다.
  public class SubjectBars:Control {
    List<KeyValuePair<string,double>> items=new List<KeyValuePair<string,double>>();readonly Font name,value;
    static readonly Color[] Tones={Theme.Orange,Color.FromArgb(120,156,92),Color.FromArgb(96,138,160),Color.FromArgb(196,150,62),Color.FromArgb(150,120,170)};
    public SubjectBars() { SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw,true);name=Theme.Font(9.5f);value=Theme.Font(9,FontStyle.Bold);TabStop=false;AccessibleName="과목별 공부 시간"; }
    public void SetItems(List<KeyValuePair<string,double>> list) { items=list;AccessibleDescription=string.Join(", ",list.Select(p=>p.Key+" "+Logic.Duration(p.Value)));Invalidate(); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(Theme.Surface(this));g.SmoothingMode=SmoothingMode.AntiAlias;
      if(items.Count==0){TextRenderer.DrawText(g,"이날은 쉬어간 날이에요.",name,new Rectangle(0,0,Width,Theme.S(24)),Theme.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter);return;}
      int rowH=Theme.S(36),rows=Math.Max(1,Height/rowH);bool overflow=items.Count>rows;int show=overflow?rows-1:items.Count;double max=items.Max(p=>p.Value);
      for(int i=0;i<show;i++) {
        int y=i*rowH;var p=items[i];string dur=Logic.Duration(p.Value);int dw=TextRenderer.MeasureText(g,dur,value).Width;
        TextRenderer.DrawText(g,p.Key,name,new Rectangle(0,y,Width-dw-Theme.S(8),Theme.S(20)),Theme.Ink,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(g,dur,value,new Rectangle(Width-dw,y,dw,Theme.S(20)),Theme.Sub,TextFormatFlags.Right|TextFormatFlags.VerticalCenter);
        var track=new RectangleF(0,y+Theme.S(23),Width,Theme.S(6));Theme.FillRound(g,Theme.Track,track,track.Height/2);
        Theme.FillRound(g,Tones[i%Tones.Length],new RectangleF(0,track.Y,(float)Math.Max(track.Height,Width*p.Value/max),track.Height),track.Height/2);
      }
      if(overflow)TextRenderer.DrawText(g,"외 "+(items.Count-show)+"개 과목",name,new Rectangle(0,show*rowH,Width,Theme.S(20)),Theme.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter);
    }
  }
  public class ManualDialog:Form {
    public Record Result;public DateTime Day;DateTimePicker date;Picker subject;NumericUpDown hours,minutes;TextBox note;
    public ManualDialog(List<string> subjects,DateTime selected) {
      Text="공부 기록 추가";AutoScaleMode=AutoScaleMode.None;ClientSize=new Size(Theme.S(420),Theme.S(400));FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;ShowInTaskbar=false;StartPosition=FormStartPosition.CenterParent;BackColor=Theme.Paper;Font=Theme.Font(10);
      Theme.Place(this,Theme.Label("타이머를 깜빡했어도 괜찮아요.",13,true),26,20,370,32);
      Theme.Place(this,Theme.Caption("공부한 날짜와 시간을 적으면 그날 기록에 더해져요."),26,52,370,22);
      Theme.Place(this,Theme.Label("공부한 날짜",9,true),26,90,170,22);Theme.Place(this,Theme.Label("과목",9,true),220,90,170,22);
      date=new DateTimePicker{Format=DateTimePickerFormat.Short,MaxDate=DateTime.Today,Value=selected>DateTime.Today?DateTime.Today:selected,Font=Theme.Font(10.5f)};Theme.Place(this,date,26,115,180,34);
      subject=Theme.Select();subject.Items.AddRange(subjects.Cast<object>().ToArray());subject.SelectedIndex=0;subject.AccessibleName="과목";Theme.Place(this,subject,220,115,174,34);
      Theme.Place(this,Theme.Label("시간",9,true),26,164,170,22);Theme.Place(this,Theme.Label("분",9,true),220,164,170,22);
      hours=new NumericUpDown{Minimum=0,Maximum=24,Font=Theme.Font(11.5f),BorderStyle=BorderStyle.None,AccessibleName="시간"};minutes=new NumericUpDown{Minimum=0,Maximum=59,Value=30,Font=Theme.Font(11.5f),BorderStyle=BorderStyle.None,AccessibleName="분"};
      Theme.Place(this,Theme.Frame(hours),26,189,180,40);Theme.Place(this,Theme.Frame(minutes),220,189,174,40);
      Theme.Place(this,Theme.Label("공부한 내용",9,true),26,242,368,22);note=Theme.Input();note.AccessibleName="공부한 내용";Theme.Place(this,Theme.Frame(note),26,267,368,40);
      var cancel=Theme.Button("취소");cancel.DialogResult=DialogResult.Cancel;Theme.Place(this,cancel,26,330,112,46);
      var save=Theme.Button("기록 저장",ButtonKind.Primary);Theme.Place(this,save,150,330,244,46);save.Click+=(s,e)=> {
        double m=(double)(hours.Value*60+minutes.Value);if(m<1||m>1440){MessageBox.Show(this,"1분부터 24시간 사이로 입력해주세요.","차곡");return;}
        Day=date.Value.Date;double start=Logic.Stamp(Day);Result=new Record{id=Guid.NewGuid().ToString(),subject=subject.Text,note=note.Text.Trim(),manual=true,segments=new List<Segment>{new Segment{start=start,end=start+m*60000}}};DialogResult=DialogResult.OK;Close();
      };CancelButton=cancel;AcceptButton=save;Motion.FadeIn(this,180);
    }
  }
  // ───────────────────────── 추가 기능 데이터 ─────────────────────────
  // 기존 study-data.json(version=1)은 한 글자도 바꾸지 않고, 새 기능 정보만 같은 폴더의 chagok-extras.json에 따로 저장합니다.
  // 이 파일이 없거나 손상돼도 공부 기록에는 영향이 없습니다.
  public class TodoItem { public string id { get; set; } public string text { get; set; } public bool done { get; set; } public string day { get; set; } public string doneDay { get; set; } }
  public class Dday { public string name { get; set; } public string date { get; set; } }
  public class Extras {
    public int version { get; set; } public bool pomodoro { get; set; } public int focusMin { get; set; } public int breakMin { get; set; } public bool sound { get; set; }
    public List<TodoItem> todos { get; set; } public List<Dday> ddays { get; set; }
    public const int MaxDdays=5,MaxTodos=500,MaxTodoText=80,MaxDdayName=20;
    public static Extras Fresh() { return new Extras{version=1,pomodoro=false,focusMin=25,breakMin=5,sound=true,todos=new List<TodoItem>(),ddays=new List<Dday>()}; }
    public static bool ValidDay(string s) { DateTime d;return s!=null&&DateTime.TryParseExact(s,"yyyy-MM-dd",System.Globalization.CultureInfo.InvariantCulture,System.Globalization.DateTimeStyles.None,out d); }
    public static DateTime ParseDay(string s) { return DateTime.ParseExact(s,"yyyy-MM-dd",System.Globalization.CultureInfo.InvariantCulture); }
    // 잘못된 값은 버리거나 허용 범위로 맞춥니다.
    public void Normalize() {
      version=1;if(focusMin<1||focusMin>120)focusMin=25;if(breakMin<1||breakMin>60)breakMin=5;
      todos=(todos??new List<TodoItem>()).Where(t=>t!=null&&!string.IsNullOrWhiteSpace(t.text)&&ValidDay(t.day)).Take(MaxTodos).ToList();
      foreach(var t in todos){ if(string.IsNullOrEmpty(t.id))t.id=Guid.NewGuid().ToString();t.text=t.text.Trim();if(t.text.Length>MaxTodoText)t.text=t.text.Substring(0,MaxTodoText);
        if(!t.done)t.doneDay=null;else if(!ValidDay(t.doneDay))t.doneDay=t.day; }
      ddays=(ddays??new List<Dday>()).Where(x=>x!=null&&!string.IsNullOrWhiteSpace(x.name)&&ValidDay(x.date)).Take(MaxDdays).ToList();
      foreach(var x in ddays){x.name=x.name.Trim();if(x.name.Length>MaxDdayName)x.name=x.name.Substring(0,MaxDdayName);}
    }
    // 오늘 보여줄 할 일: 아직 안 한 일(지난 날 것도 이어서) 먼저, 그다음 오늘 끝낸 일. 같은 묶음 안에서는 적은 순서.
    public List<TodoItem> Visible(DateTime today) { string k=Logic.Key(today);return todos.Where(t=>!t.done||t.doneDay==k).OrderBy(t=>t.done).ThenBy(t=>t.day,StringComparer.Ordinal).ToList(); }
    public TodoItem AddTodo(string text,DateTime today) {
      text=(text??"").Trim();if(text.Length==0)return null;if(text.Length>MaxTodoText)text=text.Substring(0,MaxTodoText);
      // 끝난 지 오래된 일부터 정리해 개수 제한을 넘지 않게 합니다.
      while(todos.Count>=MaxTodos){var old=todos.Where(t=>t.done).OrderBy(t=>t.doneDay,StringComparer.Ordinal).FirstOrDefault();if(old==null)return null;todos.Remove(old);}
      var item=new TodoItem{id=Guid.NewGuid().ToString(),text=text,day=Logic.Key(today)};todos.Add(item);return item;
    }
    public void SetDone(TodoItem t,bool done,DateTime today) { t.done=done;t.doneDay=done?Logic.Key(today):null; }
    // 다가오는 D-day 중 가장 가까운 것(지난 날짜는 제외)
    public Dday Nearest(DateTime today) { string k=Logic.Key(today);return ddays.Where(x=>string.CompareOrdinal(x.date,k)>=0).OrderBy(x=>x.date,StringComparer.Ordinal).FirstOrDefault(); }
    public static int DaysLeft(Dday x,DateTime today) { return (int)Math.Round((ParseDay(x.date)-today.Date).TotalDays); }
    public static string DdayText(Dday x,DateTime today) { int n=DaysLeft(x,today);return x.name+" "+(n==0?"D-Day":n>0?"D-"+n:"D+"+(-n)); }
  }
  public class ExtrasStore {
    public readonly string FilePath;public string Notice="";readonly JavaScriptSerializer json=new JavaScriptSerializer{MaxJsonLength=8*1024*1024,RecursionLimit=20};
    public ExtrasStore(string folder) { FilePath=Path.Combine(folder,"chagok-extras.json"); }
    Extras Parse(string text) { var x=json.Deserialize<Extras>(text);if(x==null||x.version!=1)throw new InvalidDataException("추가 설정 파일 형식이 아니에요.");x.Normalize();return x; }
    public Extras Load() {
      if(File.Exists(FilePath)) {
        try { return Parse(File.ReadAllText(FilePath,Encoding.UTF8)); }
        catch {
          // 손상된 파일은 지우지 않고 옆에 보관한 뒤, 직전 자동 백업에서 되살립니다.
          try { File.Copy(FilePath,FilePath+".damaged-"+DateTime.Now.ToString("yyyyMMdd-HHmmssfff"),false); } catch { }
          try { var restored=Parse(File.ReadAllText(FilePath+".bak",Encoding.UTF8));try { File.Copy(FilePath+".bak",FilePath,true); } catch { }Notice="할 일·D-day 설정을 자동 백업에서 되살렸어요.";return restored; }
          catch { Notice="할 일·D-day 설정 파일을 읽지 못해 기본값으로 시작했어요. 공부 기록은 안전해요.";return Extras.Fresh(); }
        }
      }
      return Extras.Fresh();
    }
    public void Save(Extras x) {
      x.Normalize();Directory.CreateDirectory(Path.GetDirectoryName(FilePath));string temp=FilePath+".tmp";
      using(var f=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None,4096,FileOptions.WriteThrough)){byte[] bytes=new UTF8Encoding(false).GetBytes(json.Serialize(x));f.Write(bytes,0,bytes.Length);f.Flush(true);}
      if(File.Exists(FilePath))File.Replace(temp,FilePath,FilePath+".bak");else File.Move(temp,FilePath);
    }
  }
  // 뽀모도로: 집중 시간이 다 차면 잠시 쉬기로 넘어갑니다(쉬는 시간은 기존 규칙대로 순공에서 빠짐).
  public static class Pomodoro {
    public static bool FocusDone(bool enabled,bool running,double runSeconds,int focusMin) { return enabled&&running&&focusMin>0&&runSeconds>=focusMin*60.0; }
    public static double Remaining(double runSeconds,int focusMin) { return Math.Max(0,focusMin*60.0-runSeconds); }
  }
  // ───────────────────────── 차곡 분석 ─────────────────────────
  // 최근 28일 기록으로 '언제 집중이 잘 되는지', '앉아 있던 시간 중 실제 순공 비율', '흐름이 늘고 있는지'를 계산합니다.
  // 모든 계산은 이 컴퓨터 안에서만 이뤄지고, 저장 파일은 바꾸지 않습니다.
  public class Insight {
    public double[,] Grid=new double[7,24];public double RangeTotal;public int BestHour=-1,BestDay=-1;public double BestWindow;
    public double FocusRatio=-1,AvgRun=-1,MedianRun=-1;public int Streak,BestStreak,ActiveDays;public bool StudiedToday;
    public double Slope=double.NaN,DailyAverage,WeekSoFar,WeekForecast=-1;
    public List<KeyValuePair<string,double>> Week=new List<KeyValuePair<string,double>>();public string CoachSubject="";public bool CoachLeast;public int CoachMinutes=25;
  }
  public static class Analysis {
    public const int Days=28,TrendDays=14;public const double MinDay=60,MaxSittingGap=1800;
    static IEnumerable<Segment> Parts(StudyData d,double now) { foreach(var r in d.records)foreach(var s in r.segments)yield return s;foreach(var s in Logic.ActiveParts(d.active,now))yield return s; }
    // 구간을 정각 경계로 잘라 요일(월=0)×시간 칸에 초 단위로 더합니다.
    public static void AddToGrid(double[,] grid,Segment s,double from,double to) {
      double a=Math.Max(s.start,from),b=Math.Min(s.end,to);int guard=0;
      while(a<b&&guard++<24*(Days+2)) {
        DateTime local=Logic.Local(a);var hourStart=new DateTime(local.Year,local.Month,local.Day,local.Hour,0,0,DateTimeKind.Local);
        double next=Logic.Stamp(hourStart.AddHours(1));if(next<=a)next=a+3600000;double end=Math.Min(b,next);
        grid[((int)local.DayOfWeek+6)%7,local.Hour]+=(end-a)/1000;a=end;
      }
    }
    public static Dictionary<DateTime,double> DayTotals(StudyData d,double now) {
      var days=new Dictionary<DateTime,double>();
      foreach(var part in Parts(d,now)) {
        if(part.end<=part.start)continue;DateTime a=Logic.Local(part.start).Date,b=Logic.Local(part.end).Date;
        for(DateTime day=a;day<=b&&day<=a.AddDays(3660);day=day.AddDays(1)){double v=Logic.Day(new[]{part},day);if(v>0){double sum;days.TryGetValue(day,out sum);days[day]=sum+v;}}
      }
      return days;
    }
    public static string HourName(int h) { h=((h%24)+24)%24;int hh=h%12==0?12:h%12;return (h<12?"오전 ":"오후 ")+hh+"시"; }
    public static string WindowText(int h) {
      int a=((h%24)+24)%24,b=(a+2)%24;bool sameHalf=(a<12)==(b<12)&&b>a;int ha=a%12==0?12:a%12,hb=b%12==0?12:b%12;
      return sameHalf?(a<12?"오전 ":"오후 ")+ha+"–"+hb+"시":HourName(a)+"–"+HourName(b);
    }
    public static readonly string[] DayNames={"월","화","수","목","금","토","일"};
    // 받침이 있으면 '을', 없으면 '를'
    // 남은 시간 표시: 전체 분:초 (예: 120분 → "120:00")
    // 집중 길이 표시: 반올림한 분 (화면 곳곳에서 같은 숫자가 나오도록 한 곳에서 계산)
    public static string Minutes(double seconds) { return Math.Max(1,Math.Round(seconds/60))+"분"; }
    public static string Mmss(double seconds) { long s=(long)Math.Ceiling(Math.Max(0,seconds));return (s/60)+":"+(s%60).ToString("00"); }
    public static string Eul(string word) { if(string.IsNullOrEmpty(word))return "을(를)";char c=word[word.Length-1];if(c<0xAC00||c>0xD7A3)return "을(를)";return (c-0xAC00)%28!=0?"을":"를"; }
    public static Insight Compute(StudyData d,DateTime today,double now) {
      var x=new Insight();today=today.Date;DateTime start=today.AddDays(-(Days-1));double from=Logic.Stamp(start),to=Logic.Stamp(today.AddDays(1));
      foreach(var s in Parts(d,now))if(s.end>from&&s.start<to)AddToGrid(x.Grid,s,from,to);
      var byHour=new double[24];var byDay=new double[7];
      for(int i=0;i<7;i++)for(int j=0;j<24;j++){x.RangeTotal+=x.Grid[i,j];byHour[j]+=x.Grid[i,j];byDay[i]+=x.Grid[i,j];}
      // 골든타임: 같은 시간대 연속 2시간에 쌓인 순공이 가장 많은 구간(최근 28일 합계 1시간 이상일 때만)
      if(x.RangeTotal>=3600) {
        // 합이 같으면 첫 시간에 실제 공부가 더 많은 구간을 고릅니다(공부가 없는 시간에서 시작하지 않도록).
        double best=-1;for(int j=0;j<24;j++){double v=byHour[j]+byHour[(j+1)%24];if(v>best+1e-9||(Math.Abs(v-best)<=1e-9&&x.BestHour>=0&&byHour[j]>byHour[x.BestHour]+1e-9)){best=v;x.BestHour=j;}}x.BestWindow=best;
        // 그 2시간 안에서 가장 많이 집중한 요일
        double bd=-1;for(int i=0;i<7;i++){double v=x.Grid[i,x.BestHour]+(x.BestHour==23?x.Grid[(i+1)%7,0]:x.Grid[i,x.BestHour+1]);if(v>bd+1e-9){bd=v;x.BestDay=i;}}
      }
      var totals=DayTotals(d,now);Func<DateTime,double> T=day=>{double v;return totals.TryGetValue(day,out v)?v:0;};
      x.StudiedToday=T(today)>=MinDay;
      for(int i=0;i<Days;i++)if(T(today.AddDays(-i))>=MinDay)x.ActiveDays++;
      // 연속 공부일: 오늘 아직 안 했으면 어제까지 이어진 날 수(오늘 하면 이어져요)
      DateTime cur=x.StudiedToday?today:today.AddDays(-1);while(T(cur)>=MinDay&&x.Streak<3660){x.Streak++;cur=cur.AddDays(-1);}
      int run=0;DateTime prev=DateTime.MinValue;
      foreach(var k in totals.Where(p=>p.Value>=MinDay).Select(p=>p.Key).OrderBy(k=>k)){run=prev!=DateTime.MinValue&&(k-prev).TotalDays==1?run+1:1;prev=k;if(run>x.BestStreak)x.BestStreak=run;}
      // 순공률: 타이머로 잰 기록에서 앉아 있던 시간(집중 + 30분 미만의 쉬는 틈) 중 실제 집중한 비율.
      // 30분 넘게 쉰 틈(밤새 일시정지 등)은 자리를 떠난 것으로 보고 빼요. 직접 추가한 기록도 빼요.
      double focus=0,span=0;var runs=new List<double>();
      Action<List<Segment>> take=segs=>{
        if(segs==null||segs.Count==0)return;double first=segs.Min(s=>s.start),last=segs.Max(s=>s.end);if(last<from||first>=to)return;
        var ordered=segs.OrderBy(s=>s.start).ToList();double sp=0,prevEnd=double.NaN;
        foreach(var s in ordered){double len=Math.Max(0,s.end-s.start)/1000;sp+=len;if(!double.IsNaN(prevEnd)){double gapSec=(s.start-prevEnd)/1000;if(gapSec>0&&gapSec<MaxSittingGap)sp+=gapSec;}prevEnd=Math.Max(double.IsNaN(prevEnd)?s.end:prevEnd,s.end);if(len>=60)runs.Add(len);}
        if(sp<=0)return;focus+=Logic.Total(segs);span+=sp;
      };
      foreach(var r in d.records)if(!r.manual)take(r.segments);
      if(d.active!=null)take(d.active.segments); // 진행 중인 세션은 이미 끝난 구간만 포함
      if(span>=1800)x.FocusRatio=Math.Min(1,focus/span);
      if(runs.Count>0){runs.Sort();x.AvgRun=runs.Average();x.MedianRun=runs.Count%2==1?runs[runs.Count/2]:(runs[runs.Count/2-1]+runs[runs.Count/2])/2;}
      // 추세: 어제까지 14일의 하루 순공(분)에 직선을 맞춘 기울기. 공부한 날이 4일 이상일 때만.
      var ys=Enumerable.Range(0,TrendDays).Select(i=>T(today.AddDays(-TrendDays+i))/60).ToArray();
      x.DailyAverage=ys.Average();
      if(ys.Count(v=>v*60>=MinDay)>=4){double mx=(TrendDays-1)/2.0,my=ys.Average(),num=0,den=0;for(int i=0;i<TrendDays;i++){num+=(i-mx)*(ys[i]-my);den+=(i-mx)*(i-mx);}x.Slope=num/den;}
      // 이번 주 예상: 월요일~어제 실제 + 오늘(지금까지와 평균 중 큰 값) + 남은 날 × 최근 14일 평균
      DateTime mon=Logic.Monday(today);int todayIndex=(int)(today-mon).TotalDays;
      for(int i=0;i<=todayIndex;i++)x.WeekSoFar+=T(mon.AddDays(i));
      if(x.ActiveDays>=3){double avg=x.DailyAverage*60,past=0;for(int i=0;i<todayIndex;i++)past+=T(mon.AddDays(i));x.WeekForecast=past+Math.Max(T(today),avg)+(6-todayIndex)*avg;}
      // 과목 균형: 최근 7일 과목별 순공
      var week=new Dictionary<string,double>();
      Action<string,IEnumerable<Segment>> addWeek=(subject,segs)=>{double v=0;for(int i=0;i<7;i++)v+=Logic.Day(segs,today.AddDays(-i));if(v>0){double old;week.TryGetValue(subject,out old);week[subject]=old+v;}};
      foreach(var r in d.records)addWeek(r.subject,r.segments);if(d.active!=null)addWeek(d.active.subject,Logic.ActiveParts(d.active,now));
      x.Week=week.OrderByDescending(p=>p.Value).ToList();
      // 코치 추천 과목: 최근 28일에 한 번이라도 공부한 과목 중, 최근 7일에 가장 적게 한 과목
      var recent=new HashSet<string>(d.records.Where(r=>r.segments.Any(s=>s.end>from&&s.start<to)).Select(r=>r.subject));if(d.active!=null)recent.Add(d.active.subject);
      var candidates=d.subjects.Where(recent.Contains).ToList();if(candidates.Count==0)candidates=d.subjects.ToList();
      Func<string,double> W=sub=>{double v;return week.TryGetValue(sub,out v)?v:0;};
      x.CoachSubject=candidates.OrderBy(W).First();
      // "가장 덜 한"이라고 말하려면 최근 공부한 과목들 사이에서 실제로 더 적어야 해요.
      x.CoachLeast=recent.Count>0&&candidates.Count>1&&candidates.Max(W)>W(x.CoachSubject);
      if(x.MedianRun>0)x.CoachMinutes=(int)Math.Max(15,Math.Min(60,Math.Round(x.MedianRun/60/5)*5));
      return x;
    }
    // 코치 한마디: 언제(골든타임) + 무엇을(덜 한 과목) + 얼마나(나의 보통 집중 길이 또는 뽀모도로)
    public static string CoachLine(Insight x,DateTime now,int pomodoroMin) {
      int minutes=pomodoroMin>0?pomodoroMin:x.CoachMinutes;string subject="'"+x.CoachSubject+"'"+Eul(x.CoachSubject);
      string what=(x.CoachLeast?"최근 7일 가장 덜 한 ":"")+subject+" "+minutes+"분 해볼까요?";
      if(x.BestHour<0)return what;
      int h=now.Hour;bool inWindow=h==x.BestHour||h==(x.BestHour+1)%24;
      string when=inWindow?"지금이 골든타임이에요.":h<x.BestHour?"오늘은 "+HourName(x.BestHour)+"부터가 골든타임이에요.":"내일 "+HourName(x.BestHour)+"부터가 골든타임이에요.";
      return when+" "+what;
    }
    public static string TrendText(Insight x) {
      if(double.IsNaN(x.Slope))return "최근 2주 중 공부한 날이 4일 이상이면 흐름을 알려드려요.";
      if(Math.Abs(x.Slope)<1)return "하루 순공이 꾸준하게 유지되고 있어요.";
      return "최근 2주, 하루 순공이 날마다 약 "+Math.Round(Math.Abs(x.Slope))+"분씩 "+(x.Slope>0?"늘고":"줄고")+" 있어요.";
    }
  }
  // 오늘의 할 일 목록. 동그라미를 누르면 완료(초록 체크 + 취소선), 마우스를 올리면 오른쪽 ×로 지울 수 있어요.
  // 키보드: ↑↓ 이동, Space 완료/되돌리기, Delete 지우기.
  public class TodoList:Control {
    List<TodoItem> items=new List<TodoItem>();int hover=-1,focusIdx=0,top=0;string focusId;bool hoverX;DateTime today=DateTime.Today;string popId;float popT=1;readonly object pk=new object();
    readonly Font font,strike,small;public event Action<TodoItem> Toggled,Removed;
    public TodoList() {
      SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw|ControlStyles.Selectable,true);
      TabStop=true;BackColor=Theme.Paper;font=Theme.Font(10);strike=Theme.Font(10,FontStyle.Strikeout);small=Theme.Font(8,FontStyle.Bold);AccessibleName="오늘의 할 일";AccessibleRole=AccessibleRole.List;
    }
    int RowH { get{return Theme.S(38);} }
    int Rows { get{return Math.Max(1,Height/RowH);} }
    public void SetItems(List<TodoItem> list,DateTime day) {
      items=list;today=day.Date;if(focusId!=null){int k=items.FindIndex(t=>t.id==focusId);if(k>=0)focusIdx=k;}focusIdx=Math.Max(0,Math.Min(focusIdx,items.Count-1));if(focusIdx<top)top=focusIdx;if(focusIdx>=top+Rows)top=focusIdx-Rows+1;top=Math.Max(0,Math.Min(top,Math.Max(0,items.Count-Rows)));
      AccessibleDescription=items.Count==0?"할 일이 없어요":string.Join(", ",items.Select(t=>t.text+(t.done?" 완료":"")));Invalidate();
    }
    public void Pop(string id) { popId=id;Motion.Run(pk,260,t=>{popT=t;Invalidate();},()=>{popId=null;Invalidate();}); }
    Rectangle Row(int i) { return new Rectangle(0,(i-top)*RowH,Width,RowH); }
    Rectangle XRect(int i) { var r=Row(i);return new Rectangle(r.Right-Theme.S(34),r.Y+(RowH-Theme.S(26))/2,Theme.S(26),Theme.S(26)); }
    int Hit(Point p) { int i=top+p.Y/RowH;return p.Y>=0&&i>=0&&i<items.Count&&i<top+Rows?i:-1; }
    protected override void OnMouseMove(MouseEventArgs e) { base.OnMouseMove(e);int h=Hit(e.Location);bool x=h>=0&&XRect(h).Contains(e.Location);if(h!=hover||x!=hoverX){hover=h;hoverX=x;Invalidate();}Cursor=h>=0&&(e.X<=Theme.S(44)||x)?Cursors.Hand:Cursors.Default; }
    protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e);hover=-1;hoverX=false;Invalidate(); }
    protected override void OnMouseDown(MouseEventArgs e) {
      base.OnMouseDown(e);Focus();int h=Hit(e.Location);if(h<0||e.Button!=MouseButtons.Left)return;focusIdx=h;focusId=items[h].id;
      // 실수로 완료되지 않도록 동그라미(왼쪽 칸)를 눌렀을 때만 완료/되돌리기
      if(XRect(h).Contains(e.Location)){if(Removed!=null)Removed(items[h]);}else if(e.X<=Theme.S(44)&&Toggled!=null)Toggled(items[h]);
    }
    protected override void OnMouseWheel(MouseEventArgs e) { base.OnMouseWheel(e);int max=Math.Max(0,items.Count-Rows);top=Math.Max(0,Math.Min(max,top+(e.Delta>0?-1:1)));Invalidate(); }
    protected override bool IsInputKey(Keys k) { var key=k&Keys.KeyCode;return key==Keys.Up||key==Keys.Down||base.IsInputKey(k); }
    protected override void OnKeyDown(KeyEventArgs e) {
      base.OnKeyDown(e);if(items.Count==0)return;
      if(e.KeyCode==Keys.Down)focusIdx=Math.Min(items.Count-1,focusIdx+1);else if(e.KeyCode==Keys.Up)focusIdx=Math.Max(0,focusIdx-1);
      else if(e.KeyCode==Keys.Space){focusId=items[focusIdx].id;if(Toggled!=null)Toggled(items[focusIdx]);e.Handled=true;return;}
      else if(e.KeyCode==Keys.Delete){if(Removed!=null)Removed(items[focusIdx]);e.Handled=true;return;}else return;
      focusId=items[focusIdx].id;if(focusIdx<top)top=focusIdx;if(focusIdx>=top+Rows)top=focusIdx-Rows+1;e.Handled=true;Invalidate();
    }
    protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e);Invalidate(); }
    protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e);Invalidate(); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(BackColor);g.SmoothingMode=SmoothingMode.AntiAlias;
      if(items.Count==0){TextRenderer.DrawText(g,"오늘 할 일을 적어 두고 하나씩 지워 보세요.",font,ClientRectangle,Theme.Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.WordBreak);return;}
      for(int i=top;i<items.Count&&i<top+Rows;i++) {
        var t=items[i];var r=Row(i);bool hot=i==hover;
        if(hot)Theme.FillRound(g,Theme.Mix(Theme.Paper,Theme.Soft,.9f),new RectangleF(r.X,r.Y+1,r.Width,r.Height-2),Theme.SF(8));
        if(Focused&&ShowFocusCues&&i==focusIdx)Theme.DrawRound(g,Theme.Orange,Theme.SF(1.4f),new RectangleF(r.X+1,r.Y+2,r.Width-2,r.Height-4),Theme.SF(8));
        float d=Theme.SF(20),pop=t.id==popId?1+(float)Math.Sin(Math.PI*popT)*.18f:1,cd=d*pop,cx=r.X+Theme.SF(10)+d/2,cy=r.Y+RowH/2f;var circle=new RectangleF(cx-cd/2,cy-cd/2,cd,cd);
        if(t.done){using(var b=new SolidBrush(Theme.Green))g.FillEllipse(b,circle);using(var pen=new Pen(Color.White,Theme.SF(2)){StartCap=LineCap.Round,EndCap=LineCap.Round,LineJoin=LineJoin.Round})g.DrawLines(pen,new[]{new PointF(cx-cd*.24f,cy),new PointF(cx-cd*.06f,cy+cd*.2f),new PointF(cx+cd*.26f,cy-cd*.18f)});}
        else using(var pen=new Pen(hot?Theme.Orange:Theme.LineStrong,Theme.SF(1.6f)))g.DrawEllipse(pen,circle);
        int tx=(int)(r.X+Theme.SF(20)+d),right=r.Right-Theme.S(40);string tag=null;
        if(!t.done&&Extras.ValidDay(t.day)){int ago=(int)(today-Extras.ParseDay(t.day)).TotalDays;if(ago==1)tag="어제";else if(ago>1)tag=ago+"일 전";}
        if(tag!=null){var ts=TextRenderer.MeasureText(g,tag,small);var tr=new Rectangle(right-ts.Width-Theme.S(10),(int)cy-Theme.S(10),ts.Width+Theme.S(10),Theme.S(20));Theme.FillRound(g,Theme.Mix(Theme.Paper,Theme.Amber,.15f),tr,Theme.SF(10));TextRenderer.DrawText(g,tag,small,tr,Theme.Mix(Theme.Amber,Theme.Ink,.3f),TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);right=tr.X-Theme.S(6);}
        TextRenderer.DrawText(g,t.text,t.done?strike:font,new Rectangle(tx,r.Y,Math.Max(0,right-tx),RowH),t.done?Theme.Muted:Theme.Ink,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
        if(hot||(Focused&&i==focusIdx)){var xr=XRect(i);if(hot&&hoverX)Theme.FillRound(g,Theme.DangerSoft,xr,xr.Height/2f);float s=Theme.SF(4.5f),xc=xr.X+xr.Width/2f,yc=xr.Y+xr.Height/2f;
          using(var pen=new Pen(hoverX&&hot?Theme.Danger:Theme.Muted,Theme.SF(1.6f)){StartCap=LineCap.Round,EndCap=LineCap.Round}){g.DrawLine(pen,xc-s,yc-s,xc+s,yc+s);g.DrawLine(pen,xc+s,yc-s,xc-s,yc+s);}}
        if(i<items.Count-1&&i<top+Rows-1)using(var pen=new Pen(Theme.Line))g.DrawLine(pen,tx,r.Bottom-1,r.Right,r.Bottom-1);
      }
      if(items.Count>Rows){float frac=(float)Rows/items.Count,h=Math.Max(Theme.SF(18),Height*frac),y=(Height-h)*top/Math.Max(1,items.Count-Rows);Theme.FillRound(g,Theme.LineStrong,new RectangleF(Width-Theme.SF(3),y,Theme.SF(3),h),Theme.SF(1.5f));}
    }
  }
  // 집중 골든타임 지도: 요일×시간 칸이 최근 28일 순공만큼 진해집니다. 주황 테두리가 가장 집중이 잘 되는 2시간.
  public class GoldenGrid:Control {
    public double[,] Grid=new double[7,24];public int BestHour=-1;int hx=-1,hy=-1;readonly Font small,info;
    static readonly Color[] Heat={Color.FromArgb(226,236,214),Color.FromArgb(194,215,168),Color.FromArgb(146,182,112),Color.FromArgb(84,122,66)};
    public GoldenGrid() { SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint|ControlStyles.ResizeRedraw,true);BackColor=Theme.Paper;small=Theme.Font(8);info=Theme.Font(9,FontStyle.Bold);AccessibleName="요일·시간대별 집중 지도";TabStop=false; }
    int Left0 { get{return Theme.S(26);} } int Top0 { get{return Theme.S(26);} } int Bottom0 { get{return Theme.S(22);} }
    RectangleF Cell(int day,int hour) { float cw=(Width-Left0)/24f,ch=(Height-Top0-Bottom0)/7f;return new RectangleF(Left0+hour*cw,Top0+day*ch,cw,ch); }
    protected override void OnMouseMove(MouseEventArgs e) { base.OnMouseMove(e);int nx=-1,ny=-1;for(int i=0;i<7;i++)for(int j=0;j<24;j++)if(Cell(i,j).Contains(e.Location)){ny=i;nx=j;}if(nx!=hx||ny!=hy){hx=nx;hy=ny;Invalidate();} }
    protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e);hx=hy=-1;Invalidate(); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) {
      var g=e.Graphics;g.Clear(BackColor);g.SmoothingMode=SmoothingMode.AntiAlias;double max=0;for(int i=0;i<7;i++)for(int j=0;j<24;j++)max=Math.Max(max,Grid[i,j]);
      string top=hx>=0?Analysis.DayNames[hy]+"요일 "+Analysis.HourName(hx)+" · "+Logic.Duration(Grid[hy,hx])+" (최근 28일 합계)":"진할수록 그 시간에 많이 집중했어요. 칸에 마우스를 올려 보세요.";
      TextRenderer.DrawText(g,top,hx>=0?info:small,new Rectangle(Left0,0,Width-Left0,Top0-Theme.S(4)),hx>=0?Theme.Ink:Theme.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis);
      float gap=Math.Max(1,Theme.SF(2));
      for(int i=0;i<7;i++) {
        var lr=Cell(i,0);TextRenderer.DrawText(g,Analysis.DayNames[i],small,new Rectangle(0,(int)lr.Y,Left0-Theme.S(4),(int)lr.Height),Theme.Muted,TextFormatFlags.Right|TextFormatFlags.VerticalCenter);
        for(int j=0;j<24;j++){var c=Cell(i,j);c.Inflate(-gap/2,-gap/2);double v=Grid[i,j];Color col=v<=0||max<=0?Theme.Track:Heat[Math.Min(3,(int)(v/max*4))];if(i==hy&&j==hx)col=Theme.Mix(col,Theme.Orange,.45f);Theme.FillRound(g,col,c,Theme.SF(3));}
      }
      if(BestHour>=0) {
        foreach(int start in BestHour==23?new[]{23,0}:new[]{BestHour}){int span=BestHour==23?1:2;var a=Cell(0,start);var b=Cell(6,start+span-1);var r=RectangleF.FromLTRB(a.X-gap,a.Y-gap,b.Right+gap,b.Bottom+gap);Theme.DrawRound(g,Theme.Orange,Theme.SF(2.2f),r,Theme.SF(5));}
      }
      foreach(int h in new[]{0,6,12,18}){var c=Cell(6,h);TextRenderer.DrawText(g,h==0?"자정":h==12?"정오":Analysis.HourName(h),small,new Point((int)c.X,(int)(Height-Bottom0+Theme.S(4))),Theme.Muted);}
    }
  }
  // 작게 보기: 다른 창 위에 떠 있는 작은 타이머. 끌어서 옮기고, 두 번 누르면 원래 창으로 돌아가요.
  public class MiniForm:Form {
    public readonly TimerFace Face=new TimerFace{OnDark=true};readonly Label subject;readonly Btn play,expand;public event Action PlayClicked,ExpandClicked;public bool AllowClose;
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool ReleaseCapture();
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr h,int msg,IntPtr w,IntPtr l);
    public MiniForm(Icon icon) {
      FormBorderStyle=FormBorderStyle.None;ShowInTaskbar=false;TopMost=true;StartPosition=FormStartPosition.Manual;AutoScaleMode=AutoScaleMode.None;BackColor=Theme.Night;ClientSize=new Size(Theme.S(300),Theme.S(96));Text="차곡 작은 타이머";if(icon!=null)Icon=icon;KeyPreview=true;
      var area=Screen.PrimaryScreen.WorkingArea;Location=new Point(area.Right-Width-Theme.S(24),area.Bottom-Height-Theme.S(24));
      subject=Theme.Label("",9,true);subject.ForeColor=Theme.NightText;subject.SetBounds(Theme.S(18),Theme.S(10),Theme.S(170),Theme.S(22));Controls.Add(subject);
      Face.BackColor=Theme.Night;Face.SetBounds(Theme.S(12),Theme.S(32),Theme.S(186),Theme.S(54));Controls.Add(Face);
      play=Theme.Button("▶",ButtonKind.Primary);play.Radius=-1;play.Font=Theme.Font(12,FontStyle.Bold);play.SetBounds(Theme.S(204),Theme.S(26),Theme.S(48),Theme.S(48));play.Click+=(s,e)=>{if(PlayClicked!=null)PlayClicked();};Controls.Add(play);
      expand=Theme.Button("⤢",ButtonKind.Dark);expand.Radius=-1;expand.Font=Theme.Font(11,FontStyle.Bold);expand.SetBounds(Theme.S(258),Theme.S(32),Theme.S(34),Theme.S(34));expand.Click+=(s,e)=>{if(ExpandClicked!=null)ExpandClicked();};Controls.Add(expand);
      var tip=new ToolTip();tip.SetToolTip(play,"공부 시작 · 잠시 쉬기");tip.SetToolTip(expand,"원래 창으로");
      foreach(Control c in new Control[]{this,subject,Face}){c.MouseDown+=(s,e)=>{if(e.Button!=MouseButtons.Left)return;if(e.Clicks>=2){if(ExpandClicked!=null)ExpandClicked();return;}ReleaseCapture();SendMessage(Handle,0xA1,(IntPtr)2,IntPtr.Zero);};}
      KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Escape&&ExpandClicked!=null)ExpandClicked();};
      // Alt+F4 등으로 닫으려 하면 창을 없애지 않고 원래 창으로 돌아갑니다(타이머·기록은 원래 창이 관리).
      FormClosing+=(s,e)=>{if(!AllowClose&&e.CloseReason==CloseReason.UserClosing){e.Cancel=true;if(ExpandClicked!=null)ExpandClicked();}};
      Resize+=(s,e)=>UpdateRegion();UpdateRegion();
    }
    void UpdateRegion() { using(var p=Theme.Round(new RectangleF(0,0,Width,Height),Theme.SF(18)))Region=new Region(p); }
    protected override void OnPaint(PaintEventArgs e) { base.OnPaint(e);using(var p=Theme.Round(new RectangleF(.5f,.5f,Width-1.5f,Height-1.5f),Theme.SF(18)))using(var pen=new Pen(Theme.NightTrack))e.Graphics.DrawPath(pen,p); }
    public void Sync(string time,bool running,bool active,string subjectText) {
      Face.TimeText=time;Face.Running=running;Face.Idle=!active;Face.Invalidate();play.Text=running?"Ⅱ":"▶";subject.Text=subjectText;
    }
  }
  public class MainForm:Form {
    readonly Store store;StudyData data;readonly Stopwatch watch=new Stopwatch();readonly System.Windows.Forms.Timer pulse=new System.Windows.Forms.Timer();readonly System.Windows.Forms.Timer noteDelay=new System.Windows.Forms.Timer();
    TableLayoutPanel shell,content;Panel todayPage,historyPage,settingsPage;Btn startButton,finishButton;Picker subjectBox;TextBox sessionNote,dayNote,newSubject;CheckBox pin;
    Label todayTotal,goalLabel,weekTotal,streak,historyTotal,historyDate,saveStatus,dateLabel;Pill status,notice;GoalBar progress;TimerFace face;WeekChart weekChart;DataGridView todayGrid,historyGrid;StudyCalendar calendar;SubjectBars historySubjects;ListBox subjectList;NumericUpDown goalInput;
    NavBar nav;PageFade fade;Card timerCard;readonly ToolTip tips=new ToolTip{InitialDelay=400};readonly System.Windows.Forms.Timer noticeHide=new System.Windows.Forms.Timer{Interval=7000};double lastPct=-1;bool? wasRunning;
    static readonly string[] PageOrder={"today","history","analysis","settings"};
    // 추가 기능 상태
    ExtrasStore extrasStore;Extras extras;Insight insight;Panel analysisPage,todoPanel;NavBar modeBar,recTabs;TodoList todoList;TextBox todoInput,ddayName;Btn recAdd,miniButton,coachStart;Label help,coachText,coachWhy,statStreak,statStreakSub,statRatio,statRatioSub,statRun,statRunSub,goldenText,trendText,forecastText;
    GoldenGrid golden;SubjectBars balance;Pill ddayPill;MiniForm mini;NotifyIcon tray;ToolStripMenuItem trayToggle;DateTime? breakEnd;int pomoCount;double pomoBase;bool pomoWasRunning,lastSaveOk=true;NumericUpDown focusInput,breakInput;CheckBox soundBox;ListBox ddayList;DateTimePicker ddayDate;
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)] struct FlashInfo { public uint cbSize;public IntPtr hwnd;public uint dwFlags,uCount,dwTimeout; }
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool FlashWindowEx(ref FlashInfo info);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool IsWindowEnabled(IntPtr h);
    // 추가 창(기록 추가, 백업 불러오기, 확인 창)이 열려 있으면 본 창이 잠겨 있어요. 그동안 알림 영역 메뉴로 상태를 바꾸지 않게 합니다.
    bool ModalOpen() { return IsHandleCreated&&!IsWindowEnabled(Handle); }
    bool GuardModal() { if(!ModalOpen())return false;RestoreMain();try{tray.ShowBalloonTip(3000,"차곡","열려 있는 창을 먼저 닫아 주세요.",ToolTipIcon.Info);}catch{}return true; }
    // 이번 뽀모도로 회차에서 집중한 초: 이어서 공부를 누를 때, 모드를 켤 때, 집중 분을 바꿀 때 새로 셉니다.
    double PomoRun() { return Math.Max(0,watch.Elapsed.TotalSeconds-pomoBase); }
    DateTime selected=DateTime.Today,lastToday=DateTime.Today;string currentView="today";bool refreshing;long ticks;
    static int S(int v) { return Theme.S(v); }
    public MainForm(Store s) {
      store=s;data=store.Load();bool recovered=Logic.Recover(data);extrasStore=new ExtrasStore(store.Folder);extras=extrasStore.Load();
      Text="차곡 · 순공 타이머";AutoScaleMode=AutoScaleMode.None;ClientSize=new Size(S(1120),S(800));MinimumSize=new Size(S(1000),S(745));StartPosition=FormStartPosition.CenterScreen;Font=Theme.Font(10);BackColor=Theme.Bg;
      string icon=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"차곡.ico");if(File.Exists(icon))Icon=new Icon(icon);
      Build();RefreshSubjects();RefreshAll();SetupTray();Motion.FadeIn(this,Motion.Enter);noticeHide.Tick+=(sender,args)=>{noticeHide.Stop();notice.Dismiss();};
      FormClosed+=(sender,args)=>{if(tray!=null){tray.Visible=false;tray.Dispose();}if(mini!=null){mini.AllowClose=true;mini.Close();}};
      pulse.Interval=500;pulse.Tick+=(sender,args)=>Tick();pulse.Start();
      noteDelay.Interval=700;noteDelay.Tick+=(sender,args)=>{noteDelay.Stop();Save();};
      FormClosing+=OnClosing;SystemEvents.PowerModeChanged+=OnPower;SystemEvents.SessionEnding+=OnSessionEnding;SystemEvents.SessionSwitch+=OnSessionSwitch;
      if(recovered){Save();SetNotice("지난 집중을 일시정지했어요. 컴퓨터가 꺼져 있던 시간은 더하지 않았어요.");}
      if(!string.IsNullOrEmpty(extrasStore.Notice))SetNotice(extrasStore.Notice);
      if(!string.IsNullOrEmpty(store.Notice))SetNotice(store.Notice);
    }
    Panel Page() { return new Panel{Dock=DockStyle.Fill,BackColor=Theme.Bg,AutoScroll=true,Padding=new Padding(S(26),S(12),S(26),S(12))}; }
    static Label Heading(string text) { var h=Theme.Label(text,20,true);h.Dock=DockStyle.Fill;h.Margin=new Padding(S(2),0,0,S(8));return h; }
    void Build() {
      shell=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Margin=Padding.Empty,Padding=Padding.Empty};shell.RowStyles.Add(new RowStyle(SizeType.Absolute,S(64)));shell.RowStyles.Add(new RowStyle(SizeType.Percent,100));shell.RowStyles.Add(new RowStyle(SizeType.Absolute,S(30)));Controls.Add(shell);
      var header=new Panel{Dock=DockStyle.Fill,BackColor=Theme.Paper,Margin=Padding.Empty};shell.Controls.Add(header,0,0);
      header.Paint+=(s,e)=>{using(var pen=new Pen(Theme.Line))e.Graphics.DrawLine(pen,0,header.Height-1,header.Width,header.Height-1);};
      var brand=Theme.Label("차곡.",20,true);brand.ForeColor=Theme.Orange;brand.AutoEllipsis=false;int brandW=TextRenderer.MeasureText("차곡.",brand.Font).Width+S(2);brand.SetBounds(S(26),0,brandW,S(62));header.Controls.Add(brand);
      nav=new NavBar{TabWidth=S(106)};nav.SetBounds(brand.Right+S(30),S(13),nav.TabWidth*4+nav.Gap*3,S(38));nav.Add("today","집중 타이머");nav.Add("history","공부 기록");nav.Add("analysis","차곡 분석");nav.Add("settings","나의 설정");nav.TabClicked+=k=>ShowPage(k);header.Controls.Add(nav);tips.SetToolTip(nav,"Ctrl+1 · 2 · 3 · 4 · ←→");
      dateLabel=Theme.Label("",9.5f);dateLabel.ForeColor=Theme.Sub;dateLabel.TextAlign=ContentAlignment.MiddleRight;header.Controls.Add(dateLabel);
      // 가장 가까운 시험 D-day를 날짜 옆에 보여줍니다.
      ddayPill=new Pill{Tone=Theme.Orange,Font=Theme.Font(9,FontStyle.Bold)};header.Controls.Add(ddayPill);ddayPill.Cursor=Cursors.Hand;ddayPill.Click+=(s,e)=>ShowPage("settings");tips.SetToolTip(ddayPill,"나의 설정에서 바꿀 수 있어요");
      header.Layout+=(s,e)=>{int dw=Math.Min(S(236),Math.Max(S(150),TextRenderer.MeasureText(dateLabel.Text+"  ",dateLabel.Font).Width));dateLabel.SetBounds(header.Width-S(26)-dw,0,dw,header.Height-1);int px=Math.Max(nav.Right+S(12),dateLabel.Left-S(196));ddayPill.SetBounds(px,(header.Height-S(30))/2,Math.Max(0,dateLabel.Left-S(10)-px),S(30));};
      content=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=1,Margin=Padding.Empty};content.RowStyles.Add(new RowStyle(SizeType.Percent,100));shell.Controls.Add(content,0,1);
      todayPage=BuildToday();historyPage=BuildHistory();analysisPage=BuildAnalysis();settingsPage=BuildSettings();content.Controls.Add(todayPage,0,0);content.Controls.Add(historyPage,0,0);content.Controls.Add(analysisPage,0,0);content.Controls.Add(settingsPage,0,0);ShowPage("today");
      saveStatus=Theme.Caption("이 컴퓨터에 자동 저장 · 로그인 없이 사용",8.5f);saveStatus.Dock=DockStyle.Fill;saveStatus.Margin=Padding.Empty;saveStatus.Padding=new Padding(S(28),0,0,S(2));shell.Controls.Add(saveStatus,0,2);
      // 알림은 각 화면 제목 줄 오른쪽에 떠 있어서, 알림이 생겨도 화면 배치가 밀리지 않습니다.
      fade=new PageFade();Controls.Add(fade);
      notice=new Pill{Tone=Theme.Green,Font=Theme.Font(9),Animate=true};Controls.Add(notice);notice.BringToFront();tips.SetToolTip(notice,"클릭하면 닫혀요");
      content.Layout+=(s,e)=>{int w=Math.Max(S(200),content.Width-S(52)-S(400));notice.SetBounds(content.Left+content.Width-S(26)-w-S(4),content.Top+S(22),w,S(30));};
      notice.Click+=(s,e)=>{if(!store.ReadOnly){noticeHide.Stop();notice.Dismiss();}};notice.Cursor=Cursors.Hand;
    }
    Panel BuildToday() {
      var page=Page();var layout=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,RowCount=3,Margin=Padding.Empty};layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,66));layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,34));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(54)));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(348)));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(270)));page.Controls.Add(layout);
      var heading=Heading("오늘도, 한 걸음.");layout.Controls.Add(heading,0,0);layout.SetColumnSpan(heading,2);
      var timer=Theme.Card();timer.Dock=DockStyle.Fill;layout.Controls.Add(timer,0,1);timerCard=timer;
      var title=Theme.Label("집중 타이머",12,true);title.AutoEllipsis=false;timer.Controls.Add(title);status=new Pill();timer.Controls.Add(status);
      // 자유 / 뽀모도로 전환. 뽀모도로는 집중 시간이 다 되면 자동으로 쉬고, 쉬는 시간은 순공에서 빠져요.
      modeBar=new NavBar{TabWidth=S(86),Gap=S(2),Font=Theme.Font(9,FontStyle.Bold)};modeBar.Add("free","자유");modeBar.Add("pomo","뽀모도로");modeBar.AccessibleName="타이머 방식";modeBar.TabClicked+=k=>SetMode(k=="pomo");timer.Controls.Add(modeBar);tips.SetToolTip(modeBar,"뽀모도로: 집중 시간이 끝나면 자동으로 쉬어요 (나의 설정에서 분 조절)");
      miniButton=Theme.Button("⧉ 작게",ButtonKind.Ghost);miniButton.Font=Theme.Font(9,FontStyle.Bold);miniButton.Click+=(s,e)=>ShowMini();timer.Controls.Add(miniButton);tips.SetToolTip(miniButton,"다른 창 위에 작은 타이머 띄우기 (Ctrl+M)");
      face=new TimerFace();timer.Controls.Add(face);
      help=Theme.Caption("쉬는 시간은 멈추고, 몰입한 시간만 차곡차곡.");help.TextAlign=ContentAlignment.MiddleCenter;timer.Controls.Add(help);
      var subjectLabel=Theme.Label("공부할 과목",9,true);var noteLabel=Theme.Label("공부한 내용",9,true);timer.Controls.Add(subjectLabel);timer.Controls.Add(noteLabel);
      subjectBox=Theme.Select();subjectBox.AccessibleName="공부할 과목";timer.Controls.Add(subjectBox);
      sessionNote=Theme.Input();sessionNote.AccessibleName="공부한 내용";Theme.Hint(sessionNote,"예: 미적분 3단원 문제풀이");var noteField=Theme.Frame(sessionNote);timer.Controls.Add(noteField);
      startButton=Theme.Button("▶ 공부 시작",ButtonKind.Primary);startButton.Font=Theme.Font(11,FontStyle.Bold);timer.Controls.Add(startButton);startButton.Click+=(s,e)=>Toggle();tips.SetToolTip(startButton,"Ctrl+Enter");
      finishButton=Theme.Button("✓ 기록 완료");finishButton.Font=Theme.Font(11,FontStyle.Bold);timer.Controls.Add(finishButton);finishButton.Click+=(s,e)=>Finish();
      // 크기에 따라 달라지는 배치는 카드 너비가 정해진 뒤 계산합니다.
      timer.Resize+=(s,e)=>{
        int w=timer.ClientSize.Width,m=S(26),inner=w-m*2,tw=TextRenderer.MeasureText(title.Text,title.Font).Width+S(4);title.SetBounds(m,S(20),tw,S(30));
        modeBar.SetBounds(m+tw+S(12),S(21),modeBar.TabWidth*2+modeBar.Gap,S(28));status.SetBounds(w-m-S(170),S(21),S(170),S(28));miniButton.SetBounds(w-m-S(170)-S(84),S(19),S(80),S(32));
        face.SetBounds(m,S(60),inner,S(96));help.SetBounds(m,S(158),inner,S(22));
        int sw=S(176),gap=S(14);subjectLabel.SetBounds(m,S(194),sw,S(22));noteLabel.SetBounds(m+sw+gap,S(194),inner-sw-gap,S(22));
        subjectBox.SetBounds(m,S(219),sw,S(36));noteField.SetBounds(m+sw+gap,S(219),Math.Max(S(80),inner-sw-gap),S(36));
        int half=(inner-gap)/2;startButton.SetBounds(m,S(272),half,S(50));finishButton.SetBounds(m+half+gap,S(272),inner-half-gap,S(50));
      };
      var summary=Theme.Card();summary.Dock=DockStyle.Fill;summary.BackColor=Theme.Night;summary.BorderColor=Theme.Night;summary.Margin=new Padding(0,0,0,S(16));layout.Controls.Add(summary,1,1);
      Func<string,float,bool,Color,Label> lbl=(t,size,bold,color)=>{var l=Theme.Label(t,size,bold);l.ForeColor=color;summary.Controls.Add(l);return l;};
      var todayCaption=lbl("오늘의 순공시간",10,true,Theme.NightText);todayTotal=lbl("0분",26,true,Color.White);goalLabel=lbl("",9,false,Theme.NightText);
      progress=new GoalBar{TrackColor=Theme.NightTrack};summary.Controls.Add(progress);
      var weekCaption=lbl("이번 주의 나",10,true,Theme.NightText);weekTotal=lbl("",18,true,Color.White);streak=lbl("",9,false,Theme.NightText);streak.TextAlign=ContentAlignment.TopLeft;
      summary.Paint+=(s,e)=>{using(var pen=new Pen(Theme.NightTrack))e.Graphics.DrawLine(pen,S(24),S(186),summary.Width-S(24),S(186));};
      summary.Resize+=(s,e)=>{int m=S(24),w=summary.Width-m*2;todayCaption.SetBounds(m,S(22),w,S(26));todayTotal.SetBounds(m-S(3),S(52),w+S(3),S(56));goalLabel.SetBounds(m,S(112),w,S(24));progress.SetBounds(m,S(144),w,S(10));
        weekCaption.SetBounds(m,S(206),w,S(26));weekTotal.SetBounds(m-S(2),S(234),w+S(2),S(42));streak.SetBounds(m,S(282),w,S(40));summary.Invalidate();};
      var records=Theme.Card();records.Dock=DockStyle.Fill;records.Padding=new Padding(S(22),S(16),S(22),S(12));layout.Controls.Add(records,0,2);var recLayout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=2,Margin=Padding.Empty};recLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(38)));recLayout.RowStyles.Add(new RowStyle(SizeType.Percent,100));records.Controls.Add(recLayout);
      // 아래 카드는 "오늘의 공부 기록"과 "할 일"을 탭으로 오가요.
      var recHeader=new Panel{Dock=DockStyle.Fill,Margin=Padding.Empty};recLayout.Controls.Add(recHeader,0,0);
      recTabs=new NavBar{TabWidth=S(118),Gap=S(4),Font=Theme.Font(9.5f,FontStyle.Bold)};recTabs.Add("records","오늘의 공부 기록");recTabs.Add("todo","할 일");recTabs.AccessibleName="오늘 카드 보기";recTabs.SetBounds(0,S(1),recTabs.TabWidth*2+recTabs.Gap,S(30));recTabs.TabClicked+=k=>ShowRecTab(k);recHeader.Controls.Add(recTabs);recTabs.SetSelected("records");
      recAdd=Theme.Button("+ 직접 추가",ButtonKind.Ghost);recAdd.Font=Theme.Font(9,FontStyle.Bold);recHeader.Controls.Add(recAdd);recHeader.Resize+=(s,e)=>recAdd.SetBounds(recHeader.Width-S(108),0,S(108),S(32));recAdd.Click+=(s,e)=>AddManual(DateTime.Today);tips.SetToolTip(recAdd,"Ctrl+N");
      var recHost=new Panel{Dock=DockStyle.Fill,Margin=Padding.Empty};recLayout.Controls.Add(recHost,0,1);
      todayGrid=new DataGridView();Theme.RenderGrid(todayGrid,"아직 오늘의 기록이 없어요. 타이머를 시작해보세요.");todayGrid.Columns["when"].Visible=false;todayGrid.Margin=Padding.Empty;recHost.Controls.Add(todayGrid);
      todoPanel=new Panel{Dock=DockStyle.Fill,Visible=false,Margin=Padding.Empty};recHost.Controls.Add(todoPanel);
      todoInput=Theme.Input();todoInput.MaxLength=Extras.MaxTodoText;todoInput.AccessibleName="새 할 일";Theme.Hint(todoInput,"할 일을 적고 Enter");var todoField=Theme.Frame(todoInput);var todoAdd=Theme.Button("추가");todoAdd.Font=Theme.Font(9.5f,FontStyle.Bold);
      todoList=new TodoList();todoPanel.Controls.Add(todoList);todoPanel.Controls.Add(todoField);todoPanel.Controls.Add(todoAdd);
      todoPanel.Resize+=(s,e)=>{int w=todoPanel.Width,h=todoPanel.Height,bw=S(70);todoField.SetBounds(0,h-S(38),w-bw-S(8),S(38));todoAdd.SetBounds(w-bw,h-S(38),bw,S(38));todoList.SetBounds(0,0,w,Math.Max(S(38),h-S(46)));};
      todoAdd.Click+=(s,e)=>AddTodo();todoInput.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Enter){AddTodo();e.SuppressKeyPress=true;}};
      todoList.Toggled+=t=>{extras.SetDone(t,!t.done,DateTime.Today);if(t.done)todoList.Pop(t.id);SaveExtras();RefreshTodos();if(t.done&&extras.Visible(DateTime.Today).All(x=>x.done))SetNotice("오늘 할 일을 모두 끝냈어요. 차곡차곡 잘 쌓였어요!");};
      todoList.Removed+=t=>{extras.todos.Remove(t);SaveExtras();RefreshTodos();};
      var chartCard=Theme.Card();chartCard.Dock=DockStyle.Fill;chartCard.Margin=new Padding(0,0,0,S(16));layout.Controls.Add(chartCard,1,2);
      var chartTitle=Theme.Label("차곡차곡 쌓인 일주일",11,true);var chartHint=Theme.Caption("시:분 · 하루 목표 기준",8);chartHint.TextAlign=ContentAlignment.MiddleRight;weekChart=new WeekChart();chartCard.Controls.Add(chartTitle);chartCard.Controls.Add(chartHint);chartCard.Controls.Add(weekChart);
      chartCard.Resize+=(s,e)=>{int m=S(22),w=chartCard.Width-m*2;chartTitle.SetBounds(m,S(16),w,S(32));chartHint.SetBounds(m,S(46),w,S(18));weekChart.SetBounds(m,S(68),w,Math.Max(S(40),chartCard.Height-S(68)-S(14)));};
      return page;
    }
    Panel BuildHistory() {
      var page=Page();var heading=Heading("몰입의 발자국.");heading.Dock=DockStyle.Top;heading.Height=S(54);
      var split=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Padding=Padding.Empty,Margin=Padding.Empty};split.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,S(326)));split.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));page.Controls.Add(split);page.Controls.Add(heading);
      var left=Theme.Card();left.Dock=DockStyle.Fill;split.Controls.Add(left,0,0);var leftTitle=Theme.Label("날짜를 골라 돌아보세요",11,true);left.Controls.Add(leftTitle);
      calendar=new StudyCalendar{MaxDate=DateTime.Today};left.Controls.Add(calendar);calendar.DateChanged+=(s,e)=>{if(refreshing)return;FlushNote();selected=calendar.SelectionStart.Date;RefreshHistory();};
      var totalCaption=Theme.Caption("이날의 순공시간",9);left.Controls.Add(totalCaption);historyTotal=Theme.Label("",20,true);left.Controls.Add(historyTotal);historySubjects=new SubjectBars();left.Controls.Add(historySubjects);
      left.Resize+=(s,e)=>{int m=S(20),w=left.Width-m*2;leftTitle.SetBounds(m,S(16),w,S(30));calendar.SetBounds(m-S(4),S(50),w+S(8),S(292));
        totalCaption.SetBounds(m,S(352),w,S(22));historyTotal.SetBounds(m-S(2),S(372),w,S(42));historySubjects.SetBounds(m,S(422),w,Math.Max(S(36),left.Height-S(422)-S(14)));left.Invalidate();};
      left.Paint+=(s,e)=>{using(var pen=new Pen(Theme.Line))e.Graphics.DrawLine(pen,S(20),S(346),left.Width-S(20),S(346));};
      var right=Theme.Card();right.Dock=DockStyle.Fill;right.Margin=new Padding(0,0,0,S(16));right.Padding=new Padding(S(24),S(14),S(24),S(14));split.Controls.Add(right,1,0);var rows=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=6,Margin=Padding.Empty};rows.RowStyles.Add(new RowStyle(SizeType.Absolute,S(48)));rows.RowStyles.Add(new RowStyle(SizeType.Percent,100));rows.RowStyles.Add(new RowStyle(SizeType.Absolute,S(50)));rows.RowStyles.Add(new RowStyle(SizeType.Absolute,S(28)));rows.RowStyles.Add(new RowStyle(SizeType.Absolute,S(82)));rows.RowStyles.Add(new RowStyle(SizeType.Absolute,S(26)));right.Controls.Add(rows);
      historyDate=Theme.Label("",13,true);historyDate.Dock=DockStyle.Fill;historyDate.Margin=Padding.Empty;rows.Controls.Add(historyDate,0,0);
      historyGrid=new DataGridView();Theme.RenderGrid(historyGrid,"이날의 공부 기록이 없어요.");historyGrid.Margin=Padding.Empty;rows.Controls.Add(historyGrid,0,1);
      var actions=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.LeftToRight,Margin=Padding.Empty,Padding=new Padding(0,S(10),0,0)};rows.Controls.Add(actions,0,2);
      var add=Theme.Button("+ 공부 기록 추가");add.Height=S(36);add.Width=S(142);add.Font=Theme.Font(9,FontStyle.Bold);actions.Controls.Add(add);add.Click+=(s,e)=>AddManual(selected);
      var delete=Theme.Button("선택 기록 삭제",ButtonKind.Danger);delete.Height=S(36);delete.Width=S(128);delete.Font=Theme.Font(9,FontStyle.Bold);actions.Controls.Add(delete);delete.Click+=(s,e)=>DeleteSelected();
      var noteLabel=Theme.Label("이날의 한 줄",9.5f,true);noteLabel.Dock=DockStyle.Fill;noteLabel.Margin=Padding.Empty;rows.Controls.Add(noteLabel,0,3);
      dayNote=Theme.Input();dayNote.Multiline=true;dayNote.MaxLength=500;dayNote.ScrollBars=ScrollBars.Vertical;dayNote.AccessibleName="이날의 한 줄";var dayField=Theme.Frame(dayNote);dayField.Dock=DockStyle.Fill;dayField.Margin=Padding.Empty;rows.Controls.Add(dayField,0,4);
      dayNote.TextChanged+=(s,e)=>{if(refreshing)return;data.notes[Logic.Key(selected)]=dayNote.Text;noteDelay.Stop();noteDelay.Start();};var hint=Theme.Caption("입력한 메모는 자동 저장돼요.",8.5f);hint.Dock=DockStyle.Fill;hint.Margin=Padding.Empty;rows.Controls.Add(hint,0,5);
      return page;
    }
    Panel BuildSettings() {
      var page=Page();var stack=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,RowCount=4,Margin=Padding.Empty};stack.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,45));stack.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,55));stack.RowStyles.Add(new RowStyle(SizeType.Absolute,S(54)));stack.RowStyles.Add(new RowStyle(SizeType.Absolute,S(300)));stack.RowStyles.Add(new RowStyle(SizeType.Absolute,S(262)));stack.RowStyles.Add(new RowStyle(SizeType.Absolute,S(240)));page.Controls.Add(stack);var heading=Heading("나에게 맞는 공부.");stack.Controls.Add(heading,0,0);stack.SetColumnSpan(heading,2);
      var goals=Theme.Card();goals.Dock=DockStyle.Fill;stack.Controls.Add(goals,0,1);Theme.Place(goals,Theme.Label("하루 공부 목표",13,true),26,20,280,34);Theme.Place(goals,Theme.Caption("무리하지 않고 꾸준히 할 수 있는 만큼."),26,56,330,24);
      goalInput=new NumericUpDown{Minimum=.25m,Maximum=24,Increment=.25m,DecimalPlaces=2,Font=Theme.Font(13),BorderStyle=BorderStyle.None,AccessibleName="하루 공부 목표 시간"};Theme.Place(goals,Theme.Frame(goalInput),26,100,140,44);Theme.Place(goals,Theme.Label("시간",10.5f),176,100,70,44);
      var goalSave=Theme.Button("목표 저장",ButtonKind.Primary);Theme.Place(goals,goalSave,26,164,160,44);goalSave.Click+=(s,e)=>{data.goal=(double)goalInput.Value;Save();RefreshSummary();SetNotice("새로운 하루 목표를 저장했어요.");};
      pin=new CheckBox{Text="다른 창보다 항상 위에 표시",AutoSize=true,Font=Theme.Font(9.5f),ForeColor=Theme.Sub,BackColor=Color.Transparent,Cursor=Cursors.Hand};Theme.Place(goals,pin,26,236,310,26);pin.CheckedChanged+=(s,e)=>TopMost=pin.Checked;
      var subjects=Theme.Card();subjects.Dock=DockStyle.Fill;subjects.Margin=new Padding(0,0,0,S(16));stack.Controls.Add(subjects,1,1);var subjectTitle=Theme.Label("나의 과목",13,true);subjects.Controls.Add(subjectTitle);
      subjectList=new ListBox{Font=Theme.Font(10),BorderStyle=BorderStyle.None,DrawMode=DrawMode.OwnerDrawFixed,ItemHeight=S(32),IntegralHeight=false,AccessibleName="나의 과목 목록"};var listField=Theme.Frame(subjectList);subjects.Controls.Add(listField);
      subjectList.DrawItem+=(s,e)=>{
        if(e.Index<0)return;bool sel=(e.State&DrawItemState.Selected)!=0;var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;using(var b=new SolidBrush(subjectList.BackColor))g.FillRectangle(b,e.Bounds);
        var r=new RectangleF(e.Bounds.X+1,e.Bounds.Y+1,e.Bounds.Width-3,e.Bounds.Height-2);if(sel)Theme.FillRound(g,Theme.OrangeSoft,r,Theme.SF(7));
        using(var dot=new SolidBrush(sel?Theme.Orange:Theme.Bar))g.FillEllipse(dot,e.Bounds.X+S(10),e.Bounds.Y+(e.Bounds.Height-S(7))/2f,S(7),S(7));
        TextRenderer.DrawText(g,subjectList.Items[e.Index].ToString(),subjectList.Font,new Rectangle(e.Bounds.X+S(26),e.Bounds.Y,e.Bounds.Width-S(30),e.Bounds.Height),Theme.Ink,TextFormatFlags.VerticalCenter|TextFormatFlags.Left|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
      };
      var remove=Theme.Button("삭제",ButtonKind.Danger);subjects.Controls.Add(remove);remove.Click+=(s,e)=>RemoveSubject();
      newSubject=Theme.Input();newSubject.MaxLength=30;newSubject.AccessibleName="새 과목 이름";Theme.Hint(newSubject,"새 과목 이름");var newField=Theme.Frame(newSubject);subjects.Controls.Add(newField);var subjectAdd=Theme.Button("추가");subjects.Controls.Add(subjectAdd);subjectAdd.Click+=(s,e)=>AddSubject();newSubject.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Enter){AddSubject();e.SuppressKeyPress=true;}};
      var newHint=Theme.Caption("새 과목 이름을 적고 Enter",8.5f);subjects.Controls.Add(newHint);
      subjects.Resize+=(s,e)=>{int m=S(24),bw=S(76),gap=S(10),w=Math.Max(S(120),subjects.Width-m*2-bw-gap);subjectTitle.SetBounds(m,S(20),S(280),S(34));listField.SetBounds(m,S(64),w,S(146));remove.SetBounds(m+w+gap,S(64),bw,S(38));
        newField.SetBounds(m,S(214),w,S(40));subjectAdd.SetBounds(m+w+gap,S(214),bw,S(40));newHint.SetBounds(m,S(256),w,S(22));};
      // 뽀모도로 · 알림 (바꾸면 바로 저장)
      var pomo=Theme.Card();pomo.Dock=DockStyle.Fill;stack.Controls.Add(pomo,0,2);Theme.Place(pomo,Theme.Label("뽀모도로 · 알림",13,true),26,20,300,34);Theme.Place(pomo,Theme.Caption("집중 시간이 끝나면 자동으로 쉬고, 쉬는 시간은 순공에서 빠져요."),26,56,420,24);
      focusInput=new NumericUpDown{Minimum=1,Maximum=120,Font=Theme.Font(13),BorderStyle=BorderStyle.None,AccessibleName="뽀모도로 집중 분"};Theme.Place(pomo,Theme.Frame(focusInput),26,96,110,44);Theme.Place(pomo,Theme.Label("분 집중",10.5f),144,96,80,44);
      breakInput=new NumericUpDown{Minimum=1,Maximum=60,Font=Theme.Font(13),BorderStyle=BorderStyle.None,AccessibleName="뽀모도로 휴식 분"};Theme.Place(pomo,Theme.Frame(breakInput),236,96,100,44);Theme.Place(pomo,Theme.Label("분 휴식",10.5f),344,96,80,44);
      soundBox=new CheckBox{Text="끝날 때 알림 소리 · 작업 표시줄 깜빡임",AutoSize=true,Font=Theme.Font(9.5f),ForeColor=Theme.Sub,BackColor=Color.Transparent,Cursor=Cursors.Hand};Theme.Place(pomo,soundBox,26,160,380,26);
      Theme.Place(pomo,Theme.Caption("자유 / 뽀모도로는 집중 타이머 카드 위쪽에서 바꿔요.",8.5f),26,196,420,22);
      EventHandler savePomo=(s,e)=>{if(refreshing)return;if(extras.focusMin!=(int)focusInput.Value)pomoBase=watch.Elapsed.TotalSeconds;extras.focusMin=(int)focusInput.Value;extras.breakMin=(int)breakInput.Value;extras.sound=soundBox.Checked;SaveExtras();RefreshTimer();};
      focusInput.ValueChanged+=savePomo;breakInput.ValueChanged+=savePomo;soundBox.CheckedChanged+=savePomo;
      // 시험 D-day (최대 5개, 가장 가까운 날짜가 위쪽 막대에 보여요)
      var dd=Theme.Card();dd.Dock=DockStyle.Fill;dd.Margin=new Padding(0,0,0,S(16));stack.Controls.Add(dd,1,2);var ddTitle=Theme.Label("시험 D-day",13,true);dd.Controls.Add(ddTitle);
      ddayList=new ListBox{Font=Theme.Font(10),BorderStyle=BorderStyle.None,DrawMode=DrawMode.OwnerDrawFixed,ItemHeight=S(30),IntegralHeight=false,AccessibleName="D-day 목록"};var ddField=Theme.Frame(ddayList);dd.Controls.Add(ddField);
      var ddBold=Theme.Font(10,FontStyle.Bold);
      ddayList.DrawItem+=(s,e)=>{
        if(e.Index<0||e.Index>=extras.ddays.Count)return;var x=extras.ddays[e.Index];bool sel=(e.State&DrawItemState.Selected)!=0;var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;using(var b=new SolidBrush(ddayList.BackColor))g.FillRectangle(b,e.Bounds);
        if(sel)Theme.FillRound(g,Theme.OrangeSoft,new RectangleF(e.Bounds.X+1,e.Bounds.Y+1,e.Bounds.Width-3,e.Bounds.Height-2),Theme.SF(7));int n=Extras.DaysLeft(x,DateTime.Today);string left=n==0?"D-Day":n>0?"D-"+n:"지남";
        var lw=TextRenderer.MeasureText(left,ddayList.Font).Width;TextRenderer.DrawText(g,left,ddBold,new Rectangle(e.Bounds.Right-lw-S(14),e.Bounds.Y,lw+S(8),e.Bounds.Height),n>=0?Theme.Action:Theme.Muted,TextFormatFlags.VerticalCenter|TextFormatFlags.Right);
        TextRenderer.DrawText(g,x.name+"  ·  "+x.date,ddayList.Font,new Rectangle(e.Bounds.X+S(10),e.Bounds.Y,e.Bounds.Width-lw-S(30),e.Bounds.Height),Theme.Ink,TextFormatFlags.VerticalCenter|TextFormatFlags.Left|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPrefix);
      };
      var ddRemove=Theme.Button("삭제",ButtonKind.Danger);dd.Controls.Add(ddRemove);ddRemove.Click+=(s,e)=>RemoveDday();
      ddayName=Theme.Input();ddayName.MaxLength=Extras.MaxDdayName;ddayName.AccessibleName="시험 이름";Theme.Hint(ddayName,"시험 이름 (예: 기말고사)");var ddNameField=Theme.Frame(ddayName);dd.Controls.Add(ddNameField);
      ddayDate=new DateTimePicker{Format=DateTimePickerFormat.Short,Font=Theme.Font(10.5f),MinDate=DateTime.Today,Value=DateTime.Today.AddDays(14),AccessibleName="시험 날짜"};dd.Controls.Add(ddayDate);
      var ddAdd=Theme.Button("추가");dd.Controls.Add(ddAdd);ddAdd.Click+=(s,e)=>AddDday();ddayName.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Enter){AddDday();e.SuppressKeyPress=true;}};
      var ddHint=Theme.Caption("예: 기말고사, 토익 · 가장 가까운 날짜가 위쪽에 보여요",8.5f);dd.Controls.Add(ddHint);
      dd.Resize+=(s,e)=>{int m=S(24),bw=S(76),gap=S(10),w=Math.Max(S(160),dd.Width-m*2-bw-gap);ddTitle.SetBounds(m,S(20),S(280),S(34));ddField.SetBounds(m,S(62),w,S(100));ddRemove.SetBounds(m+w+gap,S(62),bw,S(38));
        int nw=Math.Max(S(80),w-S(150)-S(8));ddNameField.SetBounds(m,S(172),nw,S(38));ddayDate.SetBounds(m+nw+S(8),S(174),S(150),S(34));ddAdd.SetBounds(m+w+gap,S(172),bw,S(38));ddHint.SetBounds(m,S(214),w+bw+gap,S(22));};
      var backup=Theme.Card();backup.Dock=DockStyle.Fill;backup.Margin=new Padding(0,0,0,S(16));stack.Controls.Add(backup,0,3);stack.SetColumnSpan(backup,2);Theme.Place(backup,Theme.Label("내 기록 보관하기",13,true),26,18,600,34);
      Theme.Place(backup,Theme.Label("기록은 전용 파일에 자동 저장돼요. 브라우저 데이터를 지워도 사라지지 않아요.",10),26,58,820,26);Theme.Place(backup,Theme.Caption("이전 Edge 버전의 ‘기록 백업’ JSON 파일도 불러올 수 있어요."),26,86,820,24);
      var export=Theme.Button("↓ 기록 백업");Theme.Place(backup,export,26,128,150,44);export.Click+=(s,e)=>Export();var import=Theme.Button("↑ 백업 불러오기");Theme.Place(backup,import,188,128,168,44);import.Click+=(s,e)=>Import();var folder=Theme.Button("기록 폴더 열기",ButtonKind.Ghost);Theme.Place(backup,folder,368,128,150,44);folder.Click+=(s,e)=>Process.Start(store.Folder);
      var footer=Theme.Caption("앱을 닫거나 컴퓨터가 절전 모드로 들어가면 타이머는 자동으로 일시정지돼요.");Theme.Place(backup,footer,26,186,850,24);
      return page;
    }
    // ── 차곡 분석: 내 기록을 숫자로 돌아보고, 코치가 '지금 무엇을 몇 분' 할지 제안합니다 ──
    Panel BuildAnalysis() {
      var page=Page();var layout=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,RowCount=3,Margin=Padding.Empty};layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,60));layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,40));
      layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(54)));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(206)));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,S(340)));page.Controls.Add(layout);
      var heading=Heading("숫자로 보는 나.");layout.Controls.Add(heading,0,0);layout.SetColumnSpan(heading,2);
      // 코치 카드: 이 화면의 주인공
      var coach=Theme.Card();coach.Dock=DockStyle.Fill;coach.BackColor=Theme.OrangeSoft;coach.BorderColor=Theme.Mix(Theme.OrangeSoft,Theme.Orange,.25f);layout.Controls.Add(coach,0,1);
      var coachTag=Theme.Label("차곡 코치",10,true);coachTag.ForeColor=Theme.Action;coach.Controls.Add(coachTag);
      coachText=Theme.Label("",13.5f,true);coachText.TextAlign=ContentAlignment.TopLeft;coachText.AutoEllipsis=false;coach.Controls.Add(coachText);
      coachWhy=Theme.Caption("",9);coachWhy.ForeColor=Theme.Sub;coach.Controls.Add(coachWhy);
      coachStart=Theme.Button("바로 시작",ButtonKind.Primary);coachStart.Font=Theme.Font(10.5f,FontStyle.Bold);coach.Controls.Add(coachStart);coachStart.Click+=(s,e)=>StartCoach();
      coach.Resize+=(s,e)=>{int m=S(26),w=coach.Width-m*2;coachTag.SetBounds(m,S(20),w,S(24));coachText.SetBounds(m,S(48),w,S(70));coachWhy.SetBounds(m,S(120),w,S(22));coachStart.SetBounds(m,S(146),Math.Min(w,S(230)),S(42));};
      // 숫자 세 개: 연속 공부일 · 순공률 · 보통 집중 길이
      var stats=Theme.Card();stats.Dock=DockStyle.Fill;stats.Margin=new Padding(0,0,0,S(16));layout.Controls.Add(stats,1,1);
      Func<string,Label> cap=t=>{var l=Theme.Caption(t,9);stats.Controls.Add(l);return l;};Func<Label> big=()=>{var l=Theme.Label("",17,true);stats.Controls.Add(l);return l;};Func<Label> sub=()=>{var l=Theme.Caption("",8.5f);stats.Controls.Add(l);return l;};
      var c1=cap("연속 공부일");statStreak=big();statStreakSub=sub();var c2=cap("순공률");statRatio=big();statRatioSub=sub();var c3=cap("한 번 앉으면");statRun=big();statRunSub=sub();
      tips.SetToolTip(statRatio,"타이머로 잰 기록에서, 처음 시작부터 마지막 끝까지 중 실제로 집중한 시간의 비율");
      stats.Paint+=(s,e)=>{using(var pen=new Pen(Theme.Line)){int cw=(stats.Width-S(40))/3;for(int i=1;i<3;i++){int x=S(20)+cw*i;e.Graphics.DrawLine(pen,x,S(30),x,stats.Height-S(30));}}};
      stats.Resize+=(s,e)=>{int cw=(stats.Width-S(40))/3;var cols=new[]{new[]{c1,statStreak,statStreakSub},new[]{c2,statRatio,statRatioSub},new[]{c3,statRun,statRunSub}};
        for(int i=0;i<3;i++){int x=S(20)+cw*i+S(12),w=cw-S(20);cols[i][0].SetBounds(x,S(40),w,S(22));cols[i][1].SetBounds(x-S(2),S(66),w+S(2),S(44));cols[i][2].SetBounds(x,S(112),w,S(40));cols[i][2].TextAlign=ContentAlignment.TopLeft;}stats.Invalidate();};
      // 집중 골든타임 지도
      var gold=Theme.Card();gold.Dock=DockStyle.Fill;layout.Controls.Add(gold,0,2);var goldTitle=Theme.Label("집중 골든타임",11,true);var goldCap=Theme.Caption("최근 28일 · 요일·시간대별 순공",8.5f);goldCap.TextAlign=ContentAlignment.MiddleRight;
      golden=new GoldenGrid();goldenText=Theme.Label("",10,true);goldenText.ForeColor=Theme.Ink;gold.Controls.Add(goldTitle);gold.Controls.Add(goldCap);gold.Controls.Add(golden);gold.Controls.Add(goldenText);
      gold.Resize+=(s,e)=>{int m=S(22),w=gold.Width-m*2;goldTitle.SetBounds(m,S(16),w,S(32));goldCap.SetBounds(m,S(20),w,S(24));golden.SetBounds(m,S(52),w,Math.Max(S(80),gold.Height-S(52)-S(54)));goldenText.SetBounds(m,gold.Height-S(48),w,S(30));};
      // 과목 균형 + 흐름
      var bal=Theme.Card();bal.Dock=DockStyle.Fill;bal.Margin=new Padding(0,0,0,S(16));layout.Controls.Add(bal,1,2);var balTitle=Theme.Label("과목 균형",11,true);var balCap=Theme.Caption("최근 7일",8.5f);balCap.TextAlign=ContentAlignment.MiddleRight;
      balance=new SubjectBars();trendText=Theme.Label("",9.5f,true);trendText.TextAlign=ContentAlignment.TopLeft;trendText.AutoEllipsis=false;forecastText=Theme.Caption("",9);forecastText.TextAlign=ContentAlignment.TopLeft;
      bal.Controls.Add(balTitle);bal.Controls.Add(balCap);bal.Controls.Add(balance);bal.Controls.Add(trendText);bal.Controls.Add(forecastText);
      bal.Paint+=(s,e)=>{using(var pen=new Pen(Theme.Line))e.Graphics.DrawLine(pen,S(22),bal.Height-S(96),bal.Width-S(22),bal.Height-S(96));};
      bal.Resize+=(s,e)=>{int m=S(22),w=bal.Width-m*2;balTitle.SetBounds(m,S(16),w,S(32));balCap.SetBounds(m,S(20),w,S(24));balance.SetBounds(m,S(56),w,Math.Max(S(36),bal.Height-S(56)-S(104)));trendText.SetBounds(m,bal.Height-S(86),w,S(44));forecastText.SetBounds(m,bal.Height-S(42),w,S(26));bal.Invalidate();};
      return page;
    }
    void RefreshAnalysis() {
      if(golden==null)return;var now=DateTime.Now;insight=Analysis.Compute(data,DateTime.Today,CurrentNow());var x=insight;
      int pomo=extras.pomodoro?extras.focusMin:0;coachText.Text=Analysis.CoachLine(x,now,pomo);
      coachWhy.Text=x.BestHour<0?"기록이 쌓일수록 나에게 맞는 시간과 과목을 더 정확히 알려드려요.":"골든타임 "+Analysis.WindowText(x.BestHour)+(x.MedianRun>0?" · 보통 한 번에 "+Analysis.Minutes(x.MedianRun)+" 집중":"")+(pomo>0?" · 뽀모도로 "+pomo+"분":"");
      coachStart.Text=data.active!=null?"타이머로 가기":"'"+x.CoachSubject+"' 바로 시작";
      statStreak.Text=x.Streak+"일";statStreakSub.Text=(x.StudiedToday||x.Streak==0?"":"오늘 하면 "+(x.Streak+1)+"일째 · ")+"최장 "+x.BestStreak+"일";
      statRatio.Text=x.FocusRatio<0?"—":Math.Round(x.FocusRatio*100)+"%";statRatioSub.Text=x.FocusRatio<0?"타이머 기록 30분 이상부터":"앉아 있던 시간 중 실제 집중";
      statRun.Text=x.MedianRun<0?"—":Analysis.Minutes(x.MedianRun);statRunSub.Text=x.MedianRun<0?"쉬지 않고 이어진 집중 길이":"쉬지 않고 집중한 보통 길이";
      golden.Grid=x.Grid;golden.BestHour=x.BestHour;golden.Invalidate();
      goldenText.Text=x.BestHour<0?"최근 28일 순공이 1시간을 넘으면 골든타임을 찾아드려요.":"순공이 가장 많이 쌓인 시간: "+Analysis.WindowText(x.BestHour)+" · 그중에서도 "+Analysis.DayNames[x.BestDay]+"요일";
      balance.SetItems(x.Week.Take(6).ToList());trendText.Text=Analysis.TrendText(x);
      forecastText.Text=x.WeekForecast<0?"공부한 날이 3일 이상이면 이번 주 예상을 보여드려요.":"이 흐름이면 이번 주 약 "+Logic.Duration(x.WeekForecast)+" (지금까지 "+Logic.Duration(x.WeekSoFar)+")";
    }
    // 코치 제안대로 시작: 추천 과목을 고르고 타이머를 켭니다. 이미 진행 중인 집중이 있으면 타이머 화면으로만 가요.
    void StartCoach() {
      if(insight==null)RefreshAnalysis();
      if(data.active!=null){ShowPage("today");SetNotice("진행 중인 집중이 있어요. 마친 뒤에 추천 과목으로 시작해 보세요.");return;}
      if(data.subjects.Contains(insight.CoachSubject))subjectBox.SelectedItem=insight.CoachSubject;
      if(subjectBox.SelectedIndex<0)subjectBox.SelectedIndex=0;ShowPage("today");Toggle();
    }
    void ShowRecTab(string key) {
      recTabs.SetSelected(key);bool todo=key=="todo";todoPanel.Visible=todo;todayGrid.Visible=!todo;recAdd.Visible=!todo;if(todo){RefreshTodos();todoInput.Focus();}
    }
    void RefreshTodos() {
      if(todoList==null)return;var list=extras.Visible(DateTime.Today);todoList.SetItems(list,DateTime.Today);int done=list.Count(t=>t.done);
      recTabs.SetLabel("todo",list.Count==0?"할 일":"할 일 "+done+"/"+list.Count);
    }
    void AddTodo() {
      var item=extras.AddTodo(todoInput.Text,DateTime.Today);if(item==null){if(todoInput.Text.Trim().Length>0)SetNotice("할 일이 너무 많아요. 끝낸 일을 정리해 주세요.");return;}
      todoInput.Clear();SaveExtras();RefreshTodos();
    }
    bool SaveExtras() {
      try { extrasStore.Save(extras);return true; } catch(Exception ex) { SetNotice("할 일·설정을 저장하지 못했어요: "+ex.Message,true);return false; }
    }
    void SetMode(bool pomodoro) {
      if(extras.pomodoro==pomodoro)return;extras.pomodoro=pomodoro;if(!pomodoro)breakEnd=null;else pomoBase=watch.Elapsed.TotalSeconds; /* 켠 순간부터 새로 세요 */SaveExtras();modeBar.SetSelected(pomodoro?"pomo":"free");RefreshTimer();RefreshAnalysis();
      SetNotice(pomodoro?"뽀모도로 모드: "+extras.focusMin+"분 집중하면 자동으로 "+extras.breakMin+"분 쉬어요.":"자유 모드: 원하는 만큼 집중하고 직접 쉬어요.");
    }
    void AddDday() {
      string name=ddayName.Text.Trim();if(name.Length==0){ddayName.Focus();return;}if(extras.ddays.Count>=Extras.MaxDdays){SetNotice("D-day는 "+Extras.MaxDdays+"개까지 둘 수 있어요.");return;}
      extras.ddays.Add(new Dday{name=name,date=Logic.Key(ddayDate.Value.Date)});extras.ddays=extras.ddays.OrderBy(x=>x.date,StringComparer.Ordinal).ToList();ddayName.Clear();SaveExtras();RefreshDdays();SetNotice(name+" D-day를 추가했어요.");
    }
    void RemoveDday() { int i=ddayList.SelectedIndex;if(i<0||i>=extras.ddays.Count)return;extras.ddays.RemoveAt(i);SaveExtras();RefreshDdays(); }
    void RefreshDdays() {
      if(ddayList!=null){ddayList.Items.Clear();foreach(var x in extras.ddays)ddayList.Items.Add(x.name);}
      if(ddayDate!=null&&ddayDate.MinDate!=DateTime.Today){if(ddayDate.Value<DateTime.Today)ddayDate.Value=DateTime.Today;ddayDate.MinDate=DateTime.Today;}
      RefreshDdayPill();
    }
    void RefreshDdayPill() { var near=extras.Nearest(DateTime.Today);string text=near==null?"":Extras.DdayText(near,DateTime.Today);if(ddayPill!=null&&ddayPill.Text!=text)ddayPill.Text=text; }
    void RefreshExtrasSettings() {
      if(focusInput==null)return;refreshing=true;focusInput.Value=Math.Max(focusInput.Minimum,Math.Min(focusInput.Maximum,extras.focusMin));breakInput.Value=Math.Max(breakInput.Minimum,Math.Min(breakInput.Maximum,extras.breakMin));soundBox.Checked=extras.sound;refreshing=false;RefreshDdays();
    }
    // 작게 보기 / 원래 창
    void ShowMini() {
      if(mini==null){mini=new MiniForm(Icon);mini.PlayClicked+=()=>{if(!GuardModal())Toggle();};mini.ExpandClicked+=RestoreMain;}
      mini.Show();RefreshTimer();Hide();
    }
    void RestoreMain() {
      if(mini!=null&&mini.Visible)mini.Hide();Show();if(WindowState==FormWindowState.Minimized)WindowState=FormWindowState.Normal;Activate();
    }
    // 작업 표시줄 알림 영역 아이콘: 두 번 누르면 열리고, 오른쪽 클릭으로 바로 시작·쉬기
    void SetupTray() {
      var menu=new ContextMenuStrip{Renderer=new ToolStripProfessionalRenderer(new MenuColors()){RoundedEdges=false}};
      menu.Items.Add("차곡 열기",null,(s,e)=>RestoreMain());trayToggle=new ToolStripMenuItem("공부 시작",null,(s,e)=>{if(!GuardModal())Toggle();});menu.Items.Add(trayToggle);
      menu.Items.Add("작게 보기",null,(s,e)=>{if(GuardModal())return;RestoreMain();ShowMini();});menu.Items.Add(new ToolStripSeparator());menu.Items.Add("차곡 끝내기",null,(s,e)=>{if(GuardModal())return;RestoreMain();Close();});
      tray=new NotifyIcon{Icon=Icon??SystemIcons.Application,Text="차곡",Visible=true,ContextMenuStrip=menu};tray.DoubleClick+=(s,e)=>RestoreMain();RefreshTimer();
    }
    // 뽀모도로가 끝났을 때 등: 소리 + 알림 + (창을 보고 있지 않으면) 작업 표시줄 깜빡임
    void Alert(string title,string body) {
      if(extras.sound)System.Media.SystemSounds.Asterisk.Play();
      try { if(tray!=null)tray.ShowBalloonTip(5000,title,body,ToolTipIcon.Info); } catch { }
      if(extras.sound&&IsHandleCreated&&Visible&&!ContainsFocus){var info=new FlashInfo{cbSize=(uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(FlashInfo)),hwnd=Handle,dwFlags=3|12,uCount=3,dwTimeout=0};FlashWindowEx(ref info);}
    }
    // 뽀모도로 진행: 집중이 다 차면 잠시 쉬기(기존 Pause 그대로 → 쉬는 시간은 순공에서 빠짐), 휴식이 끝나면 알림만 주고 다시 시작은 직접.
    void PomodoroTick() {
      var a=data.active;if(a==null){breakEnd=null;pomoWasRunning=false;return;}
      if(a.status=="running"){breakEnd=null;if(!pomoWasRunning){pomoBase=0;pomoWasRunning=true;}
        if(Pomodoro.FocusDone(extras.pomodoro,true,PomoRun(),extras.focusMin)){pomoWasRunning=false;
          Pause();pomoCount++;breakEnd=DateTime.Now.AddMinutes(extras.breakMin);RefreshAll();
          // 저장 실패 경고(빨강)는 덮지 않아요.
          if(lastSaveOk)SetNotice("뽀모도로 "+pomoCount+"회 완료! "+extras.breakMin+"분 쉬어요. 쉬는 시간은 순공에 더하지 않아요.");
          Alert("뽀모도로 "+pomoCount+"회 완료","잘했어요! "+extras.breakMin+"분 쉬고 다시 이어서 공부해요.");
        }
      } else { pomoWasRunning=false; }
      if(a.status!="running"&&breakEnd.HasValue&&DateTime.Now>=breakEnd.Value){breakEnd=null;SetNotice("휴식 끝! 준비되면 '이어서 공부'를 눌러요.");Alert("휴식 끝","다시 집중할 시간이에요. '이어서 공부'를 눌러요.");}
    }
    Panel PageOf(string name) { return name=="today"?todayPage:name=="history"?historyPage:name=="analysis"?analysisPage:name=="settings"?settingsPage:null; }
    Bitmap Snap() { var b=new Bitmap(content.Width,content.Height,System.Drawing.Imaging.PixelFormat.Format32bppRgb);content.DrawToBitmap(b,new Rectangle(0,0,b.Width,b.Height));return b; }
    void ShowPage(string name) {
      FlushNote();string prev=currentView;currentView=name;if(todayPage==null)return;
      // 화면 전환: 바뀌기 전과 후를 찍어 두고 겹쳐 보여줍니다. 그동안에도 클릭하면 바로 넘어가요.
      Bitmap before=null;var from=PageOf(prev);
      if(Motion.Enabled&&fade!=null&&prev!=name&&from!=null&&from.Visible&&Visible&&WindowState!=FormWindowState.Minimized&&content.Width>0&&content.Height>0){fade.Finish();try{before=Snap();}catch{before=null;}}
      todayPage.Visible=name=="today";historyPage.Visible=name=="history";analysisPage.Visible=name=="analysis";settingsPage.Visible=name=="settings";
      if(nav!=null)nav.SetSelected(name);
      if(name=="history")RefreshHistory();if(name=="settings"){RefreshSubjects();RefreshExtrasSettings();}if(name=="analysis")RefreshAnalysis();
      if(before!=null){try{fade.Play(before,Snap(),Array.IndexOf(PageOrder,name)>Array.IndexOf(PageOrder,prev)?1:-1,content.Bounds);notice.BringToFront();}catch{before.Dispose();fade.Finish();}}
    }
    // 단축키: Ctrl+1·2·3·4 화면 이동, Ctrl+Enter 공부 시작·잠시 쉬기, Ctrl+N 공부 기록 직접 추가, Ctrl+M 작게 보기
    protected override bool ProcessCmdKey(ref Message msg,Keys keyData) {
      if(keyData==(Keys.Control|Keys.D1)||keyData==(Keys.Control|Keys.NumPad1)){ShowPage("today");return true;}
      if(keyData==(Keys.Control|Keys.D2)||keyData==(Keys.Control|Keys.NumPad2)){ShowPage("history");return true;}
      if(keyData==(Keys.Control|Keys.D3)||keyData==(Keys.Control|Keys.NumPad3)){ShowPage("analysis");return true;}
      if(keyData==(Keys.Control|Keys.D4)||keyData==(Keys.Control|Keys.NumPad4)){ShowPage("settings");return true;}
      if(keyData==(Keys.Control|Keys.M)){ShowMini();return true;}
      if(keyData==(Keys.Control|Keys.Enter)){ShowPage("today");Toggle();return true;}
      if(keyData==(Keys.Control|Keys.N)){AddManual(currentView=="history"?selected:DateTime.Today);return true;}
      return base.ProcessCmdKey(ref msg,keyData);
    }
    double CurrentNow() { return data.active!=null&&data.active.status=="running"&&data.active.anchor.HasValue?data.active.anchor.Value+watch.Elapsed.TotalMilliseconds:Logic.Now(); }
    bool Save() {
      try { store.Save(data);lastSaveOk=true;if(saveStatus!=null){saveStatus.Text="이 컴퓨터에 자동 저장 · "+DateTime.Now.ToString("HH:mm")+" 저장됨";saveStatus.ForeColor=Theme.Muted;}return true; }
      catch(Exception ex) { lastSaveOk=false;if(saveStatus!=null){saveStatus.Text="저장 실패 · 나의 설정에서 기록을 백업해주세요.";saveStatus.ForeColor=Theme.Danger;}SetNotice(ex.Message,true);return false; }
    }
    void SetNotice(string text) { SetNotice(text,false); }
    // 확인용 알림은 7초 뒤 저절로 사라지고, 문제 알림(빨강)은 해결될 때까지 남습니다.
    void SetNotice(string text,bool problem) {
      if(notice==null)return;bool bad=problem||store.ReadOnly;notice.Tone=bad?Theme.Danger:Theme.Green;notice.Text=text;
      noticeHide.Stop();if(!bad&&!string.IsNullOrEmpty(text))noticeHide.Start();
    }
    void FlushNote() { if(noteDelay.Enabled){noteDelay.Stop();Save();} }
    void RefreshSubjects() {
      if(subjectBox==null)return;refreshing=true;string old=subjectBox.Text;subjectBox.Items.Clear();subjectBox.Items.AddRange(data.subjects.Cast<object>().ToArray());subjectBox.SelectedItem=data.active!=null?data.active.subject:old;if(subjectBox.SelectedIndex<0)subjectBox.SelectedIndex=0;
      subjectList.Items.Clear();subjectList.Items.AddRange(data.subjects.Cast<object>().ToArray());goalInput.Value=(decimal)data.goal;if(data.active!=null)sessionNote.Text=data.active.note;refreshing=false;
    }
    void RefreshTimer() {
      var a=data.active;bool running=a!=null&&a.status=="running";face.TimeText=Logic.Clock(Logic.Total(Logic.ActiveParts(a,CurrentNow())));face.Running=running;face.Idle=a==null;face.Invalidate();face.AccessibleDescription=face.TimeText;
      startButton.Text=running?"Ⅱ 잠시 쉬기":a!=null?"▶ 이어서 공부":"▶ 공부 시작";startButton.Kind=running?ButtonKind.Dark:ButtonKind.Primary;finishButton.Enabled=a!=null;subjectBox.Enabled=a==null;sessionNote.Enabled=a==null;
      status.Text=running?"집중하는 중":a!=null?"잠깐 쉬는 중":"시작할 준비 완료";status.Tone=running?Theme.Orange:a!=null?Theme.Amber:Theme.Green;status.Pulse=running;
      // 작업 표시줄에서도 시간이 보이도록 창 제목에 표시합니다.
      string title=running?"● "+face.TimeText+" · 차곡":a!=null?"Ⅱ "+face.TimeText+" · 차곡":"차곡 · 순공 타이머";if(Text!=title)Text=title;
      // 집중하는 동안 타이머 카드 테두리가 주황빛을 띱니다.
      if(timerCard!=null&&wasRunning!=running){Color b0=timerCard.BorderColor,b1=running?Theme.Mix(Theme.Line,Theme.Orange,.6f):Theme.Line;wasRunning=running;Motion.Run(timerCard,Motion.Enter,t=>{timerCard.BorderColor=Theme.Mix(b0,b1,t);timerCard.Invalidate(false);});}
      // 뽀모도로 진행 상황 / 휴식 남은 시간 / 코치 한 줄을 타이머 아래에 보여줍니다.
      if(modeBar!=null)modeBar.SetSelected(extras.pomodoro?"pomo":"free");
      string line;
      if(breakEnd.HasValue&&a!=null&&!running){double left=Math.Max(0,(breakEnd.Value-DateTime.Now).TotalSeconds);line="휴식 중 · "+Analysis.Mmss(left)+" 남았어요 · 준비되면 이어서 공부";status.Text="휴식 "+Analysis.Mmss(left);status.Tone=Theme.Green;}
      else if(extras.pomodoro&&running)line="뽀모도로 · 집중 "+Analysis.Mmss(Pomodoro.Remaining(PomoRun(),extras.focusMin))+" 남음"+(pomoCount>0?" · "+pomoCount+"회 완료":"");
      else if(extras.pomodoro)line="뽀모도로 "+extras.focusMin+"분 집중 · "+extras.breakMin+"분 휴식"+(pomoCount>0?" · "+pomoCount+"회 완료":"");
      else if(insight!=null&&insight.BestHour>=0&&a==null)line="골든타임 "+Analysis.WindowText(insight.BestHour)+" · 추천 과목 "+insight.CoachSubject;
      else line="쉬는 시간은 멈추고, 몰입한 시간만 차곡차곡.";
      if(help!=null&&help.Text!=line)help.Text=line;
      if(trayToggle!=null)trayToggle.Text=running?"잠시 쉬기":a!=null?"이어서 공부":"공부 시작";
      if(tray!=null){string tip=a==null?"차곡 · 순공 타이머":(running?"집중 중 ":"쉬는 중 ")+face.TimeText+" · "+a.subject;if(tip.Length>63)tip=tip.Substring(0,63);if(tray.Text!=tip)tray.Text=tip;}
      if(mini!=null&&mini.Visible)mini.Sync(face.TimeText,running,a!=null,a!=null?a.subject+(breakEnd.HasValue&&!running?" · 휴식":""):"차곡 · "+(subjectBox.Text.Length>0?subjectBox.Text:"준비"));
    }
    void RefreshSummary() {
      double now=CurrentNow(),seconds=Logic.DayTotal(data,DateTime.Today,now);todayTotal.Text=Logic.Duration(seconds);double pct=seconds/(data.goal*3600)*100;progress.Value=(int)Math.Min(100,Math.Max(0,pct));goalLabel.Text="목표 "+Logic.Duration(data.goal*3600)+"  ·  "+((int)pct)+"% 달성";
      // 이번에 켜 둔 동안 목표를 넘긴 순간 한 번만 축하합니다.
      if(lastPct>=0&&lastPct<100&&pct>=100){progress.Celebrate();SetNotice("오늘 목표 "+Logic.Duration(data.goal*3600)+" 달성! 오늘도 차곡차곡 해냈어요.");}lastPct=pct;
      DateTime mon=Logic.Monday(DateTime.Today);var values=Enumerable.Range(0,7).Select(i=>Logic.DayTotal(data,mon.AddDays(i),now)).ToArray();weekTotal.Text=Logic.Duration(values.Sum());streak.Text="이번 주 "+values.Count(v=>v>0)+"일 공부했어요. 나만의 페이스로.";weekChart.Week=mon;weekChart.Goal=data.goal*3600;weekChart.SetValues(values);weekChart.TodayIndex=(int)(DateTime.Today-mon).TotalDays;weekChart.Invalidate();dateLabel.Text=DateTime.Today.ToString("yyyy년 M월 d일 dddd");RefreshDdayPill();
    }
    void FillGrid(DataGridView grid,DateTime day) {
      string selectedId=grid.SelectedRows.Count>0?grid.SelectedRows[0].Tag as string:null;grid.Rows.Clear();
      foreach(var r in data.records.Where(r=>Logic.Day(r.segments,day)>0).OrderByDescending(r=>r.segments.Count>0?r.segments[0].start:0)) {
        var parts=r.segments.Where(s=>Logic.Day(new[]{s},day)>0).ToList();string when=r.manual?"직접 기록":Logic.Local(parts[0].start).ToString("HH:mm")+" – "+Logic.Local(parts[parts.Count-1].end).ToString("HH:mm");
        int i=grid.Rows.Add(r.subject,string.IsNullOrEmpty(r.note)?"나를 위한 집중 시간":r.note,Logic.Duration(Logic.Day(r.segments,day)),when);grid.Rows[i].Tag=r.id;if(r.id==selectedId)grid.Rows[i].Selected=true;
      }
      if(selectedId==null&&grid.Rows.Count>0)grid.ClearSelection();grid.Invalidate();
    }
    void RefreshHistory() {
      if(historyGrid==null)return;refreshing=true;historyDate.Text=selected.ToString("yyyy년 M월 d일 dddd");historyTotal.Text=Logic.Duration(Logic.DayTotal(data,selected,CurrentNow()));
      historySubjects.SetItems(data.records.Where(r=>Logic.Day(r.segments,selected)>0).GroupBy(r=>r.subject).Select(g=>new KeyValuePair<string,double>(g.Key,g.Sum(r=>Logic.Day(r.segments,selected)))).OrderByDescending(p=>p.Value).ToList());
      FillGrid(historyGrid,selected);string memo;dayNote.Text=data.notes.TryGetValue(Logic.Key(selected),out memo)?memo:"";refreshing=false;
    }
    void RefreshAll() {
      RefreshTimer();RefreshSummary();FillGrid(todayGrid,DateTime.Today);RefreshHistory();
      var days=new Dictionary<DateTime,double>();foreach(var r in data.records)foreach(var part in r.segments){DateTime a=Logic.Local(part.start).Date,b=Logic.Local(part.end).Date;for(DateTime d=a;d<=b&&d<=a.AddDays(3660);d=d.AddDays(1)){double v=Logic.Day(new[]{part},d);if(v>0){double sum;days.TryGetValue(d,out sum);days[d]=sum+v;}}}
      calendar.Amounts=days;calendar.Goal=data.goal*3600;calendar.Invalidate();
      RefreshTodos();RefreshAnalysis();
    }
    void Tick() {
      ticks++;RefreshTimer();if(data.active!=null&&data.active.status=="running"){data.active.lastHeartbeat=CurrentNow();if(ticks%10==0)Save();}
      PomodoroTick();if(ticks%120==0&&currentView=="analysis")RefreshAnalysis();
      if(ticks%4==0)RefreshSummary();if(DateTime.Today!=lastToday){FlushNote();lastToday=DateTime.Today;pomoCount=0;calendar.MaxDate=DateTime.Today;RefreshAll();RefreshDdays();}
    }
    void Toggle() {
      if(store.ReadOnly){MessageBox.Show(this,store.Notice,"차곡 · 기록 복구 필요");return;}
      if(data.active!=null&&data.active.status=="running"){Pause();SetNotice("잠시 쉬어가요. 쉬는 시간은 순공시간에 더하지 않아요.");}
      else {
        double now=Logic.Now();if(data.active==null)data.active=new Active{subject=subjectBox.Text,note=sessionNote.Text.Trim(),status="paused",segments=new List<Segment>(),startedAt=now};
        data.active.status="running";data.active.anchor=now;data.active.lastHeartbeat=now;watch.Restart();if(!Save()){data.active.status="paused";data.active.anchor=null;watch.Reset();}else SetNotice("지금 쌓이는 시간은 온전히 나를 위한 시간.");
      }RefreshAll();
    }
    void Pause() {
      if(data.active==null||data.active.status!="running")return;
      data.active.segments=Logic.ActiveParts(data.active,CurrentNow()).Where(s=>s.end>s.start).ToList();data.active.status="paused";data.active.anchor=null;watch.Reset();Save();RefreshTimer();
    }
    void Finish() {
      if(data.active==null)return;Pause();var a=data.active;var record=new Record{id=Guid.NewGuid().ToString(),subject=a.subject,note=a.note,segments=new List<Segment>(a.segments)};
      if(record.segments.Count>0)data.records.Add(record);data.active=null;
      if(!Save()){data.active=a;if(record.segments.Count>0)data.records.Remove(record);RefreshAll();return;}
      sessionNote.Text="";RefreshAll();SetNotice("오늘의 집중을 차곡 쌓았어요.");
    }
    void AddManual(DateTime day) {
      using(var dialog=new ManualDialog(data.subjects,day))if(dialog.ShowDialog(this)==DialogResult.OK){data.records.Add(dialog.Result);if(!Save()){data.records.Remove(dialog.Result);return;}selected=dialog.Day;refreshing=true;calendar.SetDate(selected);refreshing=false;RefreshAll();SetNotice("공부 기록을 저장했어요.");}
    }
    void DeleteSelected() {
      if(historyGrid.SelectedRows.Count==0){SetNotice("삭제할 공부 기록을 먼저 선택해주세요.");return;}string id=historyGrid.SelectedRows[0].Tag as string;
      var r=data.records.FirstOrDefault(x=>x.id==id);if(r==null)return;
      if(MessageBox.Show(this,"선택한 기록을 삭제할까요?\n자정을 넘긴 기록은 다른 날짜의 시간도 함께 삭제돼요.","공부 기록 삭제",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
      data.records.Remove(r);if(!Save())data.records.Add(r);RefreshAll();SetNotice("기록을 삭제했어요. 직전 저장 파일은 자동 백업으로 보관돼요.");
    }
    void AddSubject() {
      string name=newSubject.Text.Trim();if(name.Length==0)return;if(data.subjects.Contains(name)){SetNotice("이미 있는 과목이에요.");return;}if(data.subjects.Count>=100){SetNotice("과목은 100개까지 만들 수 있어요.");return;}data.subjects.Add(name);Save();RefreshSubjects();newSubject.Clear();SetNotice("새 과목을 추가했어요.");
    }
    void RemoveSubject() {
      string name=subjectList.SelectedItem as string;if(name==null)return;if(data.subjects.Count<=1){SetNotice("과목은 하나 이상 남겨주세요.");return;}if(data.active!=null&&data.active.subject==name){SetNotice("현재 과목은 공부 기록을 마친 뒤 삭제할 수 있어요.");return;}data.subjects.Remove(name);Save();RefreshSubjects();SetNotice("과목을 삭제했어요. 이전 공부 기록은 그대로 남아요.");
    }
    StudyData BackupData() { var backup=store.Parse(store.Serialize(data));if(backup.active!=null){backup.active.segments=Logic.ActiveParts(data.active,CurrentNow()).ToList();backup.active.status="paused";backup.active.anchor=null;}return backup; }
    void Export() {
      using(var picker=new SaveFileDialog{Title="공부 기록 백업",Filter="차곡 백업 (*.json)|*.json",FileName="차곡-공부기록-"+Logic.Key(DateTime.Today)+".json",DefaultExt="json"})if(picker.ShowDialog(this)==DialogResult.OK)try{File.WriteAllText(picker.FileName,store.Serialize(BackupData()),new UTF8Encoding(false));SetNotice("백업 파일을 저장했어요.");}catch(Exception ex){MessageBox.Show(this,ex.Message,"백업 저장 실패");}
    }
    void Import() {
      using(var picker=new OpenFileDialog{Title="차곡 백업 불러오기",Filter="차곡 백업 (*.json)|*.json"})if(picker.ShowDialog(this)==DialogResult.OK)try {
        if(new FileInfo(picker.FileName).Length>20*1024*1024)throw new InvalidDataException("20MB 이하의 백업 파일을 선택해주세요.");
        var incoming=store.Parse(File.ReadAllText(picker.FileName,Encoding.UTF8));Logic.Recover(incoming);
        if(MessageBox.Show(this,"백업 파일의 기록으로 현재 기록을 바꿀까요?\n현재 기록은 가져오기 전 백업으로 자동 보관해요.","백업 불러오기",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes)return;
        Directory.CreateDirectory(store.Folder);File.WriteAllText(Path.Combine(store.Folder,"before-import-"+DateTime.Now.ToString("yyyyMMdd-HHmmssfff")+".json"),store.Serialize(BackupData()),new UTF8Encoding(false));
        var previous=data;bool wasReadOnly=store.ReadOnly;data=incoming;store.ReadOnly=false;
        if(!Save()){data=previous;store.ReadOnly=wasReadOnly;return;}watch.Reset();RefreshSubjects();RefreshAll();SetNotice("백업에서 기록을 불러왔어요.");
      }catch(Exception ex){MessageBox.Show(this,ex.Message,"백업 파일 확인");}
    }
    void OnPower(object sender,PowerModeChangedEventArgs e) { if(e.Mode==PowerModes.Suspend&&IsHandleCreated&&!IsDisposed)Invoke((Action)(()=>{Pause();SetNotice("절전 모드로 들어가 타이머를 일시정지했어요.");})); }
    void OnSessionEnding(object sender,SessionEndingEventArgs e) { if(IsHandleCreated&&!IsDisposed)Invoke((Action)(()=>{Pause();FlushNote();Save();})); }
    void OnSessionSwitch(object sender,SessionSwitchEventArgs e) { if(e.Reason==SessionSwitchReason.SessionLock&&IsHandleCreated&&!IsDisposed)BeginInvoke((Action)(()=>{Pause();SetNotice("화면이 잠겨 타이머를 일시정지했어요.");})); }
    void OnClosing(object sender,FormClosingEventArgs e) {
      Pause();FlushNote();bool ok=Save();if(!ok&&e.CloseReason==CloseReason.UserClosing&&MessageBox.Show(this,"기록을 저장하지 못했어요. 창을 유지하고 ‘나의 설정’에서 백업할 수 있어요.\n그래도 닫을까요?","저장 확인",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes){e.Cancel=true;return;}
      pulse.Stop();SystemEvents.PowerModeChanged-=OnPower;SystemEvents.SessionEnding-=OnSessionEnding;SystemEvents.SessionSwitch-=OnSessionSwitch;
    }
  }
  public static class Program {
    [STAThread]public static int Main(string[] args) {
      if(args.Length>=3&&args[0]=="--self-test")return SelfTest(args[1],args[2]);
      bool created;using(var mutex=new Mutex(true,"Local\\ChagokNativeStudyTimer",out created)) {
        if(!created){MessageBox.Show("차곡 타이머가 이미 실행 중이에요. 작업 표시줄에서 찾아주세요.","차곡");return 0;}
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        try { string dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ChagokStudy");Application.Run(new MainForm(new Store(dir)));return 0; }
        catch(Exception ex){MessageBox.Show("차곡을 열지 못했어요.\n"+ex.Message,"차곡",MessageBoxButtons.OK,MessageBoxIcon.Error);return 1;}
      }
    }
    static int SelfTest(string folder,string resultPath) {
      var results=new List<string>();try {
        Action<bool,string> check=(ok,label)=>{if(!ok)throw new Exception(label);results.Add("PASS "+label);};
        var start=Logic.Stamp(new DateTime(2026,11,9,23,50,0));var end=Logic.Stamp(new DateTime(2026,11,10,0,20,0));var parts=new List<Segment>{new Segment{start=start,end=end}};
        check(Logic.Day(parts,new DateTime(2026,11,9))==600,"midnight split, previous day");check(Logic.Day(parts,new DateTime(2026,11,10))==1200,"midnight split, next day");
        var a=new Active{subject="수학",note="",status="running",startedAt=1000,anchor=5000,lastHeartbeat=9000,segments=new List<Segment>{new Segment{start=1000,end=3000}}};
        check(Logic.Total(Logic.ActiveParts(a,10000))==7,"running elapsed");a.status="paused";check(Logic.Total(Logic.ActiveParts(a,100000))==2,"pause excludes rest");a.status="running";
        var d=StudyData.Fresh();d.active=a;Logic.Recover(d);check(d.active.status=="paused"&&Logic.Total(d.active.segments)==6,"unexpected exit excludes downtime after heartbeat");check(Logic.Clock(3661)=="01:01:01","clock formatting");
        var store=new Store(folder);d.records.Add(new Record{id="test",subject="수학",note="검증",segments=parts});d.notes["2026-11-09"]="기록 보존";store.Save(d);var load=store.Load();check(load.records.Count==1&&load.notes["2026-11-09"]=="기록 보존","disk save and restart recovery");
        d.goal=6;store.Save(d);File.WriteAllText(store.FilePath,"broken");var recovered=store.Load();check(recovered.goal==4&&recovered.records.Count==1,"atomic backup recovery after corrupt primary");
        var browser=StudyData.Fresh();browser.active=new Active{subject="영어",note="",status="paused",startedAt=start,segments=parts,anchor=null};check(store.Parse(store.Serialize(browser)).active.segments.Count==1,"legacy browser JSON compatibility");
        bool invalid=false;try{store.Parse("{\"version\":1,\"goal\":0}");}catch{invalid=true;}check(invalid,"invalid backup rejection");
        File.WriteAllLines(resultPath,results,Encoding.UTF8);return 0;
      } catch(Exception ex) {results.Add("FAIL "+ex.ToString());File.WriteAllLines(resultPath,results,Encoding.UTF8);return 1;}
    }
  }
}
