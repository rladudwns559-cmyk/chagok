﻿$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$compilerChoices = @(
  (Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'),
  (Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe')
)
$compilerPath = $compilerChoices | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $compilerPath) { throw 'Windows .NET Framework C# compiler was not found.' }
$buildFolder = Join-Path $projectRoot 'bin'
New-Item -ItemType Directory -Path $buildFolder -Force | Out-Null
$appOutput = Join-Path $buildFolder '차곡.exe'
$compileArgs = @(
  '/nologo', '/target:winexe', '/optimize+', '/codepage:65001', '/langversion:5',
  ('/out:' + $appOutput),
  ('/win32icon:' + (Join-Path $projectRoot '차곡.ico')),
  ('/win32manifest:' + (Join-Path $projectRoot 'src\app.manifest')),
  '/reference:System.dll', '/reference:System.Core.dll',
  '/reference:System.Drawing.dll', '/reference:System.Windows.Forms.dll',
  '/reference:System.Web.Extensions.dll',
  (Join-Path $projectRoot 'src\App.cs')
)
& $compilerPath @compileArgs
if ($LASTEXITCODE -ne 0) { throw ('Build failed with exit code ' + $LASTEXITCODE) }
Copy-Item -LiteralPath (Join-Path $projectRoot '차곡.ico') -Destination (Join-Path $buildFolder '차곡.ico') -Force
Write-Output ('Built: ' + $appOutput)
