using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Chagok;

// 차곡 추가 기능 검증: 추가 데이터 저장/복구, 할 일, D-day, 뽀모도로 판정, 분석(골든타임·순공률·연속일·추세·코치)
static class FeatureTests {
  static int pass, fail; static readonly List<string> log=new List<string>();
  static void Check(bool ok,string name){ if(ok){pass++;log.Add("PASS "+name);} else {fail++;log.Add("FAIL "+name);} }
  static void Near(double a,double b,double tol,string name){ Check(Math.Abs(a-b)<=tol,name+" (got "+a+", want "+b+")"); }
  static Record Rec(string subject,DateTime start,params int[] minutes){ // minutes: 집중,쉼,집중,쉼,... 순서
    var segs=new List<Segment>();double t=Logic.Stamp(start);
    for(int i=0;i<minutes.Length;i++){ if(i%2==0)segs.Add(new Segment{start=t,end=t+minutes[i]*60000.0}); t+=minutes[i]*60000.0; }
    return new Record{id=Guid.NewGuid().ToString(),subject=subject,note="",segments=segs};
  }
  static int Main(string[] args){
    string dir=args[0];Directory.CreateDirectory(dir);
    try { Run(dir); } catch(Exception ex){ fail++; log.Add("CRASH "+ex); }
    log.Add(pass+" passed, "+fail+" failed");File.WriteAllLines(args[1],log,Encoding.UTF8);return fail==0?0:1;
  }
  static void Run(string dir){
    var today=new DateTime(2026,11,11); // 수요일
    // ── Extras 기본값·정리 ──
    var x=Extras.Fresh();Check(x.version==1&&x.focusMin==25&&x.breakMin==5&&x.sound&&!x.pomodoro,"extras defaults");
    x.focusMin=0;x.breakMin=999;x.todos.Add(null);x.todos.Add(new TodoItem{text="  ",day="2026-11-11"});x.todos.Add(new TodoItem{text="ok",day="bad-day"});x.todos.Add(new TodoItem{text=" 수학 3단원 ",day="2026-11-10",done=true});
    x.ddays.Add(new Dday{name="",date="2026-12-01"});x.ddays.Add(new Dday{name="기말",date="2026-13-01"});x.Normalize();
    Check(x.focusMin==25&&x.breakMin==5,"normalize clamps minutes");Check(x.todos.Count==1&&x.todos[0].text=="수학 3단원","normalize drops invalid todos and trims");
    Check(x.todos[0].doneDay=="2026-11-10"&&!string.IsNullOrEmpty(x.todos[0].id),"normalize fills doneDay and id");Check(x.ddays.Count==0,"normalize drops invalid ddays");
    // ── 할 일 보이기 규칙 ──
    var y=Extras.Fresh();var old=y.AddTodo("어제 못한 일",today.AddDays(-1));var a=y.AddTodo("오늘 할 일",today);var b=y.AddTodo("끝낸 일",today);var c=y.AddTodo("어제 끝낸 일",today.AddDays(-1));
    y.SetDone(b,true,today);y.SetDone(c,true,today.AddDays(-1));
    var vis=y.Visible(today);Check(vis.Count==3&&vis[0]==old&&vis[1]==a&&vis[2]==b,"visible: undone (oldest first) then done today; done yesterday hidden");
    y.SetDone(b,false,today);Check(b.doneDay==null&&!b.done,"undo clears doneDay");
    Check(y.AddTodo("   ",today)==null,"blank todo rejected");Check(y.AddTodo(new string('가',120),today).text.Length==Extras.MaxTodoText,"long todo trimmed");
    // ── D-day ──
    var z=Extras.Fresh();z.ddays.Add(new Dday{name="중간",date="2026-11-01"});z.ddays.Add(new Dday{name="토익",date="2026-11-20"});z.ddays.Add(new Dday{name="기말",date="2026-11-14"});
    var near=z.Nearest(today);Check(near!=null&&near.name=="기말","nearest future dday");Check(Extras.DdayText(near,today)=="기말 D-3","dday text D-3");
    Check(Extras.DdayText(new Dday{name="시험",date="2026-11-11"},today)=="시험 D-Day","dday text D-Day");
    z.ddays.RemoveAll(q=>q.name!="중간");Check(z.Nearest(today)==null,"past dday not shown");
    // ── ExtrasStore 저장·복구 ──
    string f1=Path.Combine(dir,"s1");Directory.CreateDirectory(f1);var st=new ExtrasStore(f1);
    Check(st.Load().todos.Count==0&&st.Notice=="","missing file -> defaults, no notice");
    var e1=Extras.Fresh();e1.pomodoro=true;e1.focusMin=50;e1.AddTodo("미적분",today);e1.ddays.Add(new Dday{name="기말",date="2026-12-15"});st.Save(e1);
    var e2=new ExtrasStore(f1).Load();Check(e2.pomodoro&&e2.focusMin==50&&e2.todos.Count==1&&e2.todos[0].text=="미적분"&&e2.ddays[0].date=="2026-12-15","round trip");
    e1.focusMin=40;st.Save(e1); // 이제 .bak 에는 50, 본 파일은 40
    File.WriteAllText(st.FilePath,"{broken");var st3=new ExtrasStore(f1);var e3=st3.Load();
    Check(e3.focusMin==50&&st3.Notice.Contains("백업"),"corrupt file -> restored from .bak");Check(Directory.GetFiles(f1,"chagok-extras.json.damaged-*").Length==1,"corrupt file kept aside");
    File.WriteAllText(st.FilePath+".bak","also broken");File.WriteAllText(st.FilePath,"{\"version\":2}");var st4=new ExtrasStore(f1);var e4=st4.Load();
    Check(e4.focusMin==25&&st4.Notice.Contains("기본값"),"unknown version and bad backup -> defaults with notice");
    Check(!File.Exists(Path.Combine(f1,"study-data.json")),"extras never touches study-data.json");
    // ── 뽀모도로 판정 ──
    Check(!Pomodoro.FocusDone(true,true,1499.9,25),"pomodoro not done before 25min");Check(Pomodoro.FocusDone(true,true,1500,25),"pomodoro done at 25min");
    Check(!Pomodoro.FocusDone(false,true,9999,25),"pomodoro off never pauses");Check(!Pomodoro.FocusDone(true,false,9999,25),"pomodoro ignores paused");
    Near(Pomodoro.Remaining(600,25),900,0,"pomodoro remaining");Near(Pomodoro.Remaining(2000,25),0,0,"pomodoro remaining floor 0");
    // ── 시간대 칸 나누기 ──
    var grid=new double[7,24];var mon=new DateTime(2026,11,9); // 월요일
    Analysis.AddToGrid(grid,new Segment{start=Logic.Stamp(mon.AddHours(13.5)),end=Logic.Stamp(mon.AddHours(15.25))},0,double.MaxValue);
    Near(grid[0,13],1800,0.01,"grid 13시 30분");Near(grid[0,14],3600,0.01,"grid 14시 60분");Near(grid[0,15],900,0.01,"grid 15시 15분");
    grid=new double[7,24];var sun=new DateTime(2026,11,15);
    Analysis.AddToGrid(grid,new Segment{start=Logic.Stamp(sun.AddHours(23.5)),end=Logic.Stamp(sun.AddHours(24.5))},0,double.MaxValue);
    Near(grid[6,23],1800,0.01,"grid sunday 23시 (midnight split)");Near(grid[0,0],1800,0.01,"grid monday 0시 (midnight split)");
    grid=new double[7,24];Analysis.AddToGrid(grid,new Segment{start=Logic.Stamp(mon.AddHours(9)),end=Logic.Stamp(mon.AddHours(11))},Logic.Stamp(mon.AddHours(10)),Logic.Stamp(mon.AddHours(20)));
    Near(grid[0,9],0,0.01,"grid clipped before range");Near(grid[0,10],3600,0.01,"grid inside range");
    // ── 시간 문구·조사 ──
    Check(Analysis.WindowText(14)=="오후 2–4시","window text afternoon");Check(Analysis.WindowText(10)=="오전 10시–오후 12시","window text across noon");Check(Analysis.WindowText(23)=="오후 11시–오전 1시","window text across midnight");
    Check(Analysis.HourName(0)=="오전 12시"&&Analysis.HourName(12)=="오후 12시"&&Analysis.HourName(9)=="오전 9시","hour names");
    Check(Analysis.Eul("영어")=="를"&&Analysis.Eul("수학")=="을"&&Analysis.Eul("전공 공부")=="를"&&Analysis.Eul("Java")=="을(를)","josa 을/를");
    // ── 종합 분석 ──
    var d=StudyData.Fresh();d.subjects=new List<string>{"수학","영어","국어"};
    // 최근 4일 매일 오후 2시에 수학 40분+10분 쉼+40분, 영어는 이틀 전 오후 3시에 20분
    for(int i=1;i<=4;i++)d.records.Add(Rec("수학",today.AddDays(-i).AddHours(14),40,10,40));
    d.records.Add(Rec("영어",today.AddDays(-2).AddHours(15),20));
    var man=Rec("국어",today.AddDays(-40).AddHours(9),60);man.manual=true;d.records.Add(man); // 28일 밖 + 직접 기록
    double now=Logic.Stamp(today.AddHours(11));var ins=Analysis.Compute(d,today,now);
    Near(ins.RangeTotal,4*80*60+20*60,0.5,"range total");Check(ins.BestHour==14,"golden time = 14시 (got "+ins.BestHour+")");
    Near(ins.FocusRatio,(4*80+20)/(4*90.0+20),0.001,"focus ratio excludes manual, counts breaks in span");
    Near(ins.MedianRun,2400,0.01,"median continuous run 40분");Check(ins.Streak==4&&!ins.StudiedToday,"streak counts up to yesterday when today empty");
    Check(ins.BestStreak==4,"best streak");Check(ins.CoachSubject=="영어"&&ins.CoachLeast,"coach picks least-studied recent subject (got "+ins.CoachSubject+")");
    Check(ins.CoachMinutes==40,"coach minutes = median run rounded (got "+ins.CoachMinutes+")");
    Check(ins.Week.Count==2&&ins.Week[0].Key=="수학","subject balance ordering");
    string morning=Analysis.CoachLine(ins,today.AddHours(11),0),golden=Analysis.CoachLine(ins,today.AddHours(15),0),night=Analysis.CoachLine(ins,today.AddHours(21),25);
    Check(morning.StartsWith("오늘은 오후 2시부터가 골든타임")&&morning.Contains("'영어'를 40분"),"coach line before window: "+morning);
    Check(golden.StartsWith("지금이 골든타임"),"coach line inside window: "+golden);Check(night.StartsWith("내일 오후 2시")&&night.Contains("25분"),"coach line after window uses pomodoro minutes: "+night);
    // 오늘 공부하면 연속일 +1
    d.records.Add(Rec("수학",today.AddHours(9),30));ins=Analysis.Compute(d,today,now);Check(ins.Streak==5&&ins.StudiedToday,"streak includes today once studied");
    // 1분 미만은 공부한 날로 치지 않음
    var d2=StudyData.Fresh();d2.records.Add(new Record{id="t",subject="자유 공부",note="",segments=new List<Segment>{new Segment{start=Logic.Stamp(today.AddDays(-1).AddHours(10)),end=Logic.Stamp(today.AddDays(-1).AddHours(10))+30000}}});
    var ins2=Analysis.Compute(d2,today,now);Check(ins2.Streak==0&&ins2.BestHour==-1&&ins2.FocusRatio<0,"tiny data -> no streak, no golden time, no ratio");
    Check(ins2.CoachSubject=="자유 공부"&&!Analysis.CoachLine(ins2,today.AddHours(11),0).Contains("골든"),"coach falls back without golden time");
    // ── 추세 (선형 회귀 기울기) ──
    var d3=StudyData.Fresh();for(int i=1;i<=14;i++)d3.records.Add(Rec("수학",today.AddDays(-15+i).AddHours(20),10*i));
    var ins3=Analysis.Compute(d3,today,now);Near(ins3.Slope,10,0.0001,"trend slope +10분/일");Check(Analysis.TrendText(ins3).Contains("10분씩 늘고"),"trend text rising");
    var d4=StudyData.Fresh();for(int i=1;i<=14;i++)d4.records.Add(Rec("수학",today.AddDays(-15+i).AddHours(20),150-10*i));
    Near(Analysis.Compute(d4,today,now).Slope,-10,0.0001,"trend slope -10분/일");
    var d5=StudyData.Fresh();for(int i=1;i<=3;i++)d5.records.Add(Rec("수학",today.AddDays(-i).AddHours(20),60));Check(double.IsNaN(Analysis.Compute(d5,today,now).Slope),"trend needs 4+ study days");
    // ── 이번 주 예상: 월~어제 실제 + max(오늘, 평균) + 남은 날 × 평균 ──
    var d6=StudyData.Fresh();for(int i=1;i<=14;i++)d6.records.Add(Rec("수학",today.AddDays(-i).AddHours(8),60)); // 매일 60분
    var ins6=Analysis.Compute(d6,today,Logic.Stamp(today.AddHours(7)));Near(ins6.DailyAverage,60,0.0001,"daily average 60분");
    Near(ins6.WeekForecast,(2*60+60+4*60)*60.0,1,"week forecast (월,화 + 오늘 평균 + 목~일)");Near(ins6.WeekSoFar,2*3600,1,"week so far");
    // ── 진행 중인 세션: 실행 중 구간도 지도에 반영, 순공률은 끝난 구간만 ──
    var d7=StudyData.Fresh();double st0=Logic.Stamp(today.AddHours(9));d7.active=new Active{subject="수학",note="",status="running",startedAt=st0,anchor=st0+3600000,lastHeartbeat=st0+3600000,segments=new List<Segment>{new Segment{start=st0,end=st0+1800000}}};
    var ins7=Analysis.Compute(d7,today,st0+5400000);Near(ins7.RangeTotal,1800+1800,0.5,"active running part counted in grid");Near(ins7.FocusRatio,1,0.0001,"active: ratio uses finished segments only");
    // ── DayTotals 와 기존 Logic.DayTotal 일치 ──
    var totals=Analysis.DayTotals(d,now);bool same=true;for(int i=0;i<10;i++){var day=today.AddDays(-i);double v;totals.TryGetValue(day,out v);if(Math.Abs(v-Logic.DayTotal(d,day,now))>0.001)same=false;}Check(same,"DayTotals matches Logic.DayTotal");
    // ── 고친 점 회귀 검사 ──
    Check(Analysis.Mmss(7200)=="120:00"&&Analysis.Mmss(59.2)=="1:00"&&Analysis.Mmss(0)=="0:00"&&Analysis.Mmss(-5)=="0:00","mm:ss shows full minutes (120분 집중도 정확히)");
    var d8=StudyData.Fresh();var monday=Logic.Monday(today.AddDays(-7));
    d8.records.Add(Rec("수학",monday.AddHours(9),100));d8.records.Add(Rec("수학",monday.AddDays(1).AddHours(14),60));d8.records.Add(Rec("수학",monday.AddDays(2).AddHours(14),60));
    var ins8=Analysis.Compute(d8,today,now);Check(ins8.BestHour==14,"golden window 14시 (got "+ins8.BestHour+")");Check(ins8.BestDay==1,"best day chosen inside golden window = 화 (got "+ins8.BestDay+"), not 월 with more total");
    Check(Analysis.TrendText(ins3).Contains("날마다 약 10분씩 늘고"),"trend wording");
    // ── 독립 리뷰 반영 회귀 검사 ──
    // 밤새 일시정지했다가 아침에 이어서 한 경우: 30분 이상 틈은 앉아 있던 시간에서 빠져야 함
    var d9=StudyData.Fresh();d9.records.Add(Rec("수학",today.AddDays(-2).AddHours(22),40,10*60,40)); // 40분 → 10시간 쉼 → 40분
    var ins9=Analysis.Compute(d9,today,now);Near(ins9.FocusRatio,1,0.0001,"overnight pause not counted as sitting time");
    var d10=StudyData.Fresh();d10.records.Add(Rec("수학",today.AddDays(-2).AddHours(9),30,29,30));Near(Analysis.Compute(d10,today,now).FocusRatio,60/89.0,0.0001,"29분 쉼은 앉아 있던 시간에 포함");
    // 백업에서 되살린 뒤 본 파일도 고쳐져서, 다음 실행에 또 손상 처리하지 않음
    string f3=Path.Combine(dir,"s3");Directory.CreateDirectory(f3);var s3=new ExtrasStore(f3);var e5=Extras.Fresh();e5.focusMin=30;s3.Save(e5);e5.focusMin=35;s3.Save(e5);File.WriteAllText(s3.FilePath,"{broken");
    new ExtrasStore(f3).Load();var again=new ExtrasStore(f3);var e6=again.Load();Check(e6.focusMin==30&&again.Notice==""&&Directory.GetFiles(f3,"*.damaged-*").Length==1,"primary repaired after .bak restore");
    // 최근 공부가 없으면 "가장 덜 한" 이라고 말하지 않음
    var d11=StudyData.Fresh();var ins11=Analysis.Compute(d11,today,now);Check(!ins11.CoachLeast&&!Analysis.CoachLine(ins11,today.AddHours(11),0).Contains("가장 덜 한"),"no 'least studied' claim without recent data");
    var d12=StudyData.Fresh();d12.subjects=new List<string>{"수학","영어"};d12.records.Add(Rec("수학",today.AddDays(-20).AddHours(9),30));d12.records.Add(Rec("영어",today.AddDays(-20).AddHours(10),30));
    Check(!Analysis.Compute(d12,today,now).CoachLeast,"no 'least' claim when all recent subjects tie at 0 this week");
    // 밤 11시 창: 요일은 그날 23시 + 다음 날 0시로 계산
    var d13=StudyData.Fresh();var mon2=Logic.Monday(today.AddDays(-7));d13.records.Add(Rec("수학",mon2.AddHours(23),120)); // 월 23시~화 1시
    var ins13=Analysis.Compute(d13,today,now);Check(ins13.BestHour==23&&ins13.BestDay==0,"window 23시 belongs to the day it starts (got hour "+ins13.BestHour+", day "+ins13.BestDay+")");
    // ── 기존 저장 형식 그대로 ──
    var store=new Store(Path.Combine(dir,"s2"));store.Save(d);var json=File.ReadAllText(store.FilePath);
    Check(!json.Contains("todos")&&!json.Contains("pomodoro")&&json.Contains("\"version\":1"),"study-data.json schema unchanged");
  }
}
