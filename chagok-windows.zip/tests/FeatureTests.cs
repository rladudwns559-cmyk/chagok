using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Chagok;

// 차곡 추가 기능 검증: 추가 데이터 저장/복구, 할 일, D-day, 뽀모도로 판정, 분석(골든타임·순공률·연속일·추세·코치)
static class FeatureTests {
  static int pass, fail; static readonly List<string> log=new List<string>();
  static void Check(bool ok,string name){ if(ok){pass++;log.Add("PASS "+name);} else {fail++;log.Add("FAIL "+name);} }
  static void Near(double a,double b,double tol,string name){ Check(Math.Abs(a-b)<=tol,name+" (got "+a+", want "+b+")"); }
  static Record Rec(string subject,DateTime start,params int[] minutes){ // minutes: 집중,쉼,집중,쉼,... 순서
    var segs=new List<Segment>();double t=Logic.Stamp(start);
    for(int i=0;i<minutes.Length;i++){ if(i%2==0)segs.Add(new Segment{start=t,end=t+minutes[i]*60000.0}); t+=minutes[i]*60000.0; }
    return new Record{id=Guid.NewGuid().ToString(),subject=subject,note="",segments=segs};
  }
  static int Main(string[] args){
    string dir=args[0];Directory.CreateDirectory(dir);
    try { Run(dir); } catch(Exception ex){ fail++; log.Add("CRASH "+ex); }
    log.Add(pass+" passed, "+fail+" failed");File.WriteAllLines(args[1],log,Encoding.UTF8);return fail==0?0:1;
  }
  static void Run(string dir){
    var today=new DateTime(2026,11,11); // 수요일
    // ── Extras 기본값·정리 ──
    var x=Extras.Fresh();Check(x.version==1&&x.focusMin==25&&x.breakMin==5&&x.sound&&!x.pomodoro,"extras defaults");
    x.focusMin=0;x.breakMin=999;x.todos.Add(null);x.todos.Add(new TodoItem{text="  ",day="2026-11-11"});x.todos.Add(new TodoItem{text="ok",day="bad-day"});x.todos.Add(new TodoItem{text=" 수학 3단원 ",day="2026-11-10",done=true});
    x.ddays.Add(new Dday{name="",date="2026-12-01"});x.ddays.Add(new Dday{name="기말",date="2026-13-01"});x.Normalize();
    Check(x.focusMin==25&&x.breakMin==5,"normalize clamps minutes");Check(x.todos.Count==1&&x.todos[0].text=="수학 3단원","normalize drops invalid todos and trims");
    Check(x.todos[0].doneDay=="2026-11-10"&&!string.IsNullOrEmpty(x.todos[0].id),"normalize fills doneDay and id");Check(x.ddays.Count==0,"normalize drops invalid ddays");
    // ── 할 일 보이기 규칙 ──
    var y=Extras.Fresh();var old=y.AddTodo("어제 못한 일",today.AddDays(-1));var a=y.AddTodo("오늘 할 일",today);var b=y.AddTodo("끝낸 일",today);var c=y.AddTodo("어제 끝낸 일",today.AddDays(-1));
    y.SetDone(b,true,today);y.SetDone(c,true,today.AddDays(-1));
    var vis=y.Visible(today);Check(vis.Count==3&&vis[0]==old&&vis[1]==a&&vis[2]==b,"visible: undone (oldest first) then done today; done yesterday hidden");
    y.SetDone(b,false,today);Check(b.doneDay==null&&!b.done,"undo clears doneDay");
    Check(y.AddTodo("   ",today)==null,"blank todo rejected");Check(y.AddTodo(new string('가',120),today).text.Length==Extras.MaxTodoText,"long todo trimmed");
    // ── D-day ──
    var z=Extras.Fresh();z.ddays.Add(new Dday{name="중간",date="2026-11-01"});z.ddays.Add(new Dday{name="토익",date="2026-11-20"});z.ddays.Add(new Dday{name="기말",date="2026-11-14"});
    var near=z.Nearest(today);Check(near!=null&&near.name=="기말","nearest future dday");Check(Extras.DdayText(near,today)=="기말 D-3","dday text D-3");
    Check(Extras.DdayText(new Dday{name="시험",date="2026-11-11"},today)=="시험 D-Day","dday text D-Day");
    z.ddays.RemoveAll(q=>q.name!="중간");Check(z.Nearest(today)==null,"past dday not shown");
    // ── ExtrasStore 저장·복구 ──
    string f1=Path.Combine(dir,"s1");Directory.CreateDirectory(f1);var st=new ExtrasStore(f1);
    Check(st.Load().todos.Count==0&&st.Notice=="","missing file -> defaults, no notice");
    var e1=Extras.Fresh();e1.pomodoro=true;e1.focusMin=50;e1.AddTodo("미적분",today);e1.ddays.Add(new Dday{name="기말",date="2026-12-15"});st.Save(e1);
    var e2=new ExtrasStore(f1).Load();Check(e2.pomodoro&&e2.focusMin==50&&e2.todos.Count==1&&e2.todos[0].text=="미적분"&&e2.ddays[0].date=="2026-12-15","round trip");
    e1.focusMin=40;st.Save(e1); // 이제 .bak 에는 50, 본 파일은 40
    File.WriteAllText(st.FilePath,"{broken");var st3=new ExtrasStore(f1);var e3=st3.Load();
    Check(e3.focusMin==50&&st3.Notice.Contains("백업"),"corrupt file -> restored from .bak");Check(Directory.GetFiles(f1,"chagok-extras.json.damaged-*").Length==1,"corrupt file kept aside");
    File.WriteAllText(st.FilePath+".bak","also broken");File.WriteAllText(st.FilePath,"{\"version\":2}");var st4=new ExtrasStore(f1);var e4=st4.Load();
    Check(e4.focusMin==25&&st4.Notice.Contains("기본값"),"unknown version and bad backup -> defaults with notice");
    Check(!File.Exists(Path.Combine(f1,"study-data.json")),"extras never touches study-data.json");
    // ── 뽀모도로 판정 ──
    Check(!Pomodoro.FocusDone(true,true,1499.9,25),"pomodoro not done before 25min");Check(Pomodoro.FocusDone(true,true,1500,25),"pomodoro done at 25min");
    Check(!Pomodoro.FocusDone(false,true,9999,25),"pomodoro off never pauses");Check(!Pomodoro.FocusDone(true,false,9999,25),"pomodoro ignores paused");
    Near(Pomodoro.Remaining(600,25),900,0,"pomodoro remaining");Near(Pomodoro.Remaining(2000,25),0,0,"pomodoro remaining floor 0");
    // ── 시간대 칸 나누기 ──
    var grid=new double[7,24];var mon=new DateTime(2026,11,9); // 월요일
    Analysis.AddToGrid(grid,new Segment{start=Logic.Stamp(mon.AddHours(13.5)),end=Logic.Stamp(mon.AddHours(15.25))},0,double.MaxValue);
    Near(grid[0,13],1800,0.01,"grid 13시 30분");Near(grid[0,14],3600,0.01,"grid 14시 60분");Near(grid[0,15],900,0.01,"grid 15시 15분");
    grid=new double[7,24];var sun=new DateTime(2026,11,15);
    Analysis.AddToGrid(grid,new Segment{start=Logic.Stamp(sun.AddHours(23.5)),end=Logic.Stamp(sun.AddHours(24.5))},0,double.MaxValue);
    Near(grid[6,23],1800,0.01,"grid sunday 23시 (midnight split)");Near(grid[0,0],1800,0.01,"grid monday 0시 (midnight split)");
    grid=new double[7,24];Analysis.AddToGrid(grid,new Segment{start=Logic.Stamp(mon.AddHours(9)),end=Logic.Stamp(mon.AddHours(11))},Logic.Stamp(mon.AddHours(10)),Logic.Stamp(mon.AddHours(20)));
    Near(grid[0,9],0,0.01,"grid clipped before range");Near(grid[0,10],3600,0.01,"grid inside range");
    // ── 시간 문구·조사 ──
    Check(Analysis.WindowText(14)=="오후 2–4시","window text afternoon");Check(Analysis.WindowText(10)=="오전 10시–오후 12시","window text across noon");Check(Analysis.WindowText(23)=="오후 11시–오전 1시","window text across midnight");
    Check(Analysis.HourName(0)=="오전 12시"&&Analysis.HourName(12)=="오후 12시"&&Analysis.HourName(9)=="오전 9시","hour names");
    Check(Analysis.Eul("영어")=="를"&&Analysis.Eul("수학")=="을"&&Analysis.Eul("전공 공부")=="를"&&Analysis.Eul("Java")=="을(를)","josa 을/를");
    // ── 종합 분석 ──
    var d=StudyData.Fresh();d.subjects=new List<string>{"수학","영어","국어"};
    // 최근 4일 매일 오후 2시에 수학 40분+10분 쉼+40분, 영어는 이틀 전 오후 3시에 20분
    for(int i=1;i<=4;i++)d.records.Add(Rec("수학",today.AddDays(-i).AddHours(14),40,10,40));
    d.records.Add(Rec("영어",today.AddDays(-2).AddHours(15),20));
    var man=Rec("국어",today.AddDays(-40).AddHours(9),60);man.manual=true;d.records.Add(man); // 28일 밖 + 직접 기록
    double now=Logic.Stamp(today.AddHours(11));var ins=Analysis.Compute(d,today,now);
    Near(ins.RangeTotal,4*80*60+20*60,0.5,"range total");Check(ins.BestHour==14,"golden time = 14시 (got "+ins.BestHour+")");
    Near(ins.FocusRatio,(4*80+20)/(4*90.0+20),0.001,"focus ratio excludes manual, counts breaks in span");
    Near(ins.MedianRun,2400,0.01,"median continuous run 40분");Check(ins.Streak==4&&!ins.StudiedToday,"streak counts up to yesterday when today empty");
    Check(ins.BestStreak==4,"best streak");Check(ins.CoachSubject=="영어"&&ins.CoachLeast,"coach picks least-studied recent subject (got "+ins.CoachSubject+")");
    Check(ins.CoachMinutes==40,"coach minutes = median run rounded (got "+ins.CoachMinutes+")");
    Check(ins.Week.Count==2&&ins.Week[0].Key=="수학","subject balance ordering");
    string morning=Analysis.CoachLine(ins,today.AddHours(11),0),golden=Analysis.CoachLine(ins,today.AddHours(15),0),night=Analysis.CoachLine(ins,today.AddHours(21),25);
    Check(morning.StartsWith("오늘은 오후 2시부터가 골든타임")&&morning.Contains("'영어'를 40분"),"coach line before window: "+morning);
    Check(golden.StartsWith("지금이 골든타임"),"coach line inside window: "+golden);Check(night.StartsWith("내일 오후 2시")&&night.Contains("25분"),"coach line after window uses pomodoro minutes: "+night);
    // 오늘 공부하면 연속일 +1
    d.records.Add(Rec("수학",today.AddHours(9),30));ins=Analysis.Compute(d,today,now);Check(ins.Streak==5&&ins.StudiedToday,"streak includes today once studied");
    // 1분 미만은 공부한 날로 치지 않음
    var d2=StudyData.Fresh();d2.records.Add(new Record{id="t",subject="자유 공부",note="",segments=new List<Segment>{new Segment{start=Logic.Stamp(today.AddDays(-1).AddHours(10)),end=Logic.Stamp(today.AddDays(-1).AddHours(10))+30000}}});
    var ins2=Analysis.Compute(d2,today,now);Check(ins2.Streak==0&&ins2.BestHour==-1&&ins2.FocusRatio<0,"tiny data -> no streak, no golden time, no ratio");
    Check(ins2.CoachSubject=="자유 공부"&&!Analysis.CoachLine(ins2,today.AddHours(11),0).Contains("골든"),"coach falls back without golden time");
    // ── 추세 (선형 회귀 기울기) ──
    var d3=StudyData.Fresh();for(int i=1;i<=14;i++)d3.records.Add(Rec("수학",today.AddDays(-15+i).AddHours(20),10*i));
    var ins3=Analysis.Compute(d3,today,now);Near(ins3.Slope,10,0.0001,"trend slope +10분/일");Check(Analysis.TrendText(ins3).Contains("10분씩 늘고"),"trend text rising");
    var d4=StudyData.Fresh();for(int i=1;i<=14;i++)d4.records.Add(Rec("수학",today.AddDays(-15+i).AddHours(20),150-10*i));
    Near(Analysis.Compute(d4,today,now).Slope,-10,0.0001,"trend slope -10분/일");
    var d5=StudyData.Fresh();for(int i=1;i<=3;i++)d5.records.Add(Rec("수학",today.AddDays(-i).AddHours(20),60));Check(double.IsNaN(Analysis.Compute(d5,today,now).Slope),"trend needs 4+ study days");
    // ── 이번 주 예상: 월~어제 실제 + max(오늘, 평균) + 남은 날 × 평균 ──
    var d6=StudyData.Fresh();for(int i=1;i<=14;i++)d6.records.Add(Rec("수학",today.AddDays(-i).AddHours(8),60)); // 매일 60분
    var ins6=Analysis.Compute(d6,today,Logic.Stamp(today.AddHours(7)));Near(ins6.DailyAverage,60,0.0001,"daily average 60분");
    Near(ins6.WeekForecast,(2*60+60+4*60)*60.0,1,"week forecast (월,화 + 오늘 평균 + 목~일)");Near(ins6.WeekSoFar,2*3600,1,"week so far");
    // ── 진행 중인 세션: 실행 중 구간도 지도에 반영, 순공률은 끝난 구간만 ──
    var d7=StudyData.Fresh();double st0=Logic.Stamp(today.AddHours(9));d7.active=new Active{subject="수학",note="",status="running",startedAt=st0,anchor=st0+3600000,lastHeartbeat=st0+3600000,segments=new List<Segment>{new Segment{start=st0,end=st0+1800000}}};
    var ins7=Analysis.Compute(d7,today,st0+5400000);Near(ins7.RangeTotal,1800+1800,0.5,"active running part counted in grid");Near(ins7.FocusRatio,1,0.0001,"active: ratio uses finished segments only");
    // ── DayTotals 와 기존 Logic.DayTotal 일치 ──
    var totals=Analysis.DayTotals(d,now);bool same=true;for(int i=0;i<10;i++){var day=today.AddDays(-i);double v;totals.TryGetValue(day,out v);if(Math.Abs(v-Logic.DayTotal(d,day,now))>0.001)same=false;}Check(same,"DayTotals matches Logic.DayTotal");
    // ── 고친 점 회귀 검사 ──
    Check(Analysis.Mmss(7200)=="120:00"&&Analysis.Mmss(59.2)=="1:00"&&Analysis.Mmss(0)=="0:00"&&Analysis.Mmss(-5)=="0:00","mm:ss shows full minutes (120분 집중도 정확히)");
    var d8=StudyData.Fresh();var monday=Logic.Monday(today.AddDays(-7));
    d8.records.Add(Rec("수학",monday.AddHours(9),100));d8.records.Add(Rec("수학",monday.AddDays(1).AddHours(14),60));d8.records.Add(Rec("수학",monday.AddDays(2).AddHours(14),60));
    var ins8=Analysis.Compute(d8,today,now);Check(ins8.BestHour==14,"golden window 14시 (got "+ins8.BestHour+")");Check(ins8.BestDay==1,"best day chosen inside golden window = 화 (got "+ins8.BestDay+"), not 월 with more total");
    Check(Analysis.TrendText(ins3).Contains("날마다 약 10분씩 늘고"),"trend wording");
    // ── 독립 리뷰 반영 회귀 검사 ──
    // 밤새 일시정지했다가 아침에 이어서 한 경우: 30분 이상 틈은 앉아 있던 시간에서 빠져야 함
    var d9=StudyData.Fresh();d9.records.Add(Rec("수학",today.AddDays(-2).AddHours(22),40,10*60,40)); // 40분 → 10시간 쉼 → 40분
    var ins9=Analysis.Compute(d9,today,now);Near(ins9.FocusRatio,1,0.0001,"overnight pause not counted as sitting time");
    var d10=StudyData.Fresh();d10.records.Add(Rec("수학",today.AddDays(-2).AddHours(9),30,29,30));Near(Analysis.Compute(d10,today,now).FocusRatio,60/89.0,0.0001,"29분 쉼은 앉아 있던 시간에 포함");
    // 백업에서 되살린 뒤 본 파일도 고쳐져서, 다음 실행에 또 손상 처리하지 않음
    string f3=Path.Combine(dir,"s3");Directory.CreateDirectory(f3);var s3=new ExtrasStore(f3);var e5=Extras.Fresh();e5.focusMin=30;s3.Save(e5);e5.focusMin=35;s3.Save(e5);File.WriteAllText(s3.FilePath,"{broken");
    new ExtrasStore(f3).Load();var again=new ExtrasStore(f3);var e6=again.Load();Check(e6.focusMin==30&&again.Notice==""&&Directory.GetFiles(f3,"*.damaged-*").Length==1,"primary repaired after .bak restore");
    // 최근 공부가 없으면 "가장 덜 한" 이라고 말하지 않음
    var d11=StudyData.Fresh();var ins11=Analysis.Compute(d11,today,now);Check(!ins11.CoachLeast&&!Analysis.CoachLine(ins11,today.AddHours(11),0).Contains("가장 덜 한"),"no 'least studied' claim without recent data");
    var d12=StudyData.Fresh();d12.subjects=new List<string>{"수학","영어"};d12.records.Add(Rec("수학",today.AddDays(-20).AddHours(9),30));d12.records.Add(Rec("영어",today.AddDays(-20).AddHours(10),30));
    Check(!Analysis.Compute(d12,today,now).CoachLeast,"no 'least' claim when all recent subjects tie at 0 this week");
    // 밤 11시 창: 요일은 그날 23시 + 다음 날 0시로 계산
    var d13=StudyData.Fresh();var mon2=Logic.Monday(today.AddDays(-7));d13.records.Add(Rec("수학",mon2.AddHours(23),120)); // 월 23시~화 1시
    var ins13=Analysis.Compute(d13,today,now);Check(ins13.BestHour==23&&ins13.BestDay==0,"window 23시 belongs to the day it starts (got hour "+ins13.BestHour+", day "+ins13.BestDay+")");
    // ═════ v1.1 새 기능 ═════
    // 추가 데이터 정리: 잘못된 별점·목표·플랜 값
    var n1=Extras.Fresh();n1.ratings["a"]=3;n1.ratings["b"]=0;n1.ratings["c"]=9;n1.ratings[""]=4;n1.subjectGoals["수학"]=5;n1.subjectGoals["영어"]=-1;n1.subjectGoals["국어"]=999;n1.subjectGoals[" "]=3;
    n1.ddays.Add(new Dday{name="기말",date="2026-12-01",targetHours=-5,subject="  수학 ",start="nope"});n1.ddays.Add(new Dday{name="토익",date="2026-12-02",targetHours=99999});n1.Normalize();
    Check(n1.ratings.Count==1&&n1.ratings["a"]==3,"normalize keeps only 1-5 ratings");Check(n1.subjectGoals.Count==1&&n1.subjectGoals["수학"]==5,"normalize keeps only valid weekly goals");
    Check(n1.ddays[0].targetHours==0&&n1.ddays[0].subject=="수학"&&n1.ddays[0].start==null,"normalize plan fields");Check(n1.ddays[1].targetHours==Extras.MaxTargetHours&&n1.ddays[1].subject=="","normalize clamps target, empty subject = all");
    // 예전(v1.0) 추가 설정 파일도 그대로 읽힘
    string f4=Path.Combine(dir,"s4");Directory.CreateDirectory(f4);File.WriteAllText(Path.Combine(f4,"chagok-extras.json"),"{\"version\":1,\"pomodoro\":true,\"focusMin\":30,\"breakMin\":5,\"sound\":true,\"todos\":[],\"ddays\":[{\"name\":\"기말\",\"date\":\"2026-12-01\"}]}");
    var old1=new ExtrasStore(f4).Load();Check(old1.focusMin==30&&old1.ratings!=null&&old1.ratings.Count==0&&old1.subjectGoals!=null&&old1.ddays[0].targetHours==0,"v1.0 extras file loads with empty new fields");
    var e7=Extras.Fresh();e7.ratings["r1"]=5;e7.subjectGoals["수학"]=8;e7.ddays.Add(new Dday{name="기말",date="2026-12-15",targetHours=40,subject="수학",start="2026-11-01"});new ExtrasStore(f4).Save(e7);
    var e8=new ExtrasStore(f4).Load();Check(e8.ratings["r1"]==5&&e8.subjectGoals["수학"]==8&&e8.ddays[0].targetHours==40&&e8.ddays[0].subject=="수학"&&e8.ddays[0].start=="2026-11-01","new fields round trip");
    // 시험 역산 플래너
    var dp=StudyData.Fresh();dp.subjects=new List<string>{"수학","영어"};
    for(int i=1;i<=3;i++)dp.records.Add(Rec("수학",today.AddDays(-i).AddHours(10),120)); // 최근 3일 수학 2시간씩
    dp.records.Add(Rec("영어",today.AddDays(-1).AddHours(15),60));dp.records.Add(Rec("수학",today.AddDays(-10).AddHours(10),300)); // 시작일 전 기록은 빼야 함
    var ex1=new Dday{name="기말",date=Logic.Key(today.AddDays(5)),targetHours=10,subject="수학",start=Logic.Key(today.AddDays(-3))};
    var p1=ExamPlanner.Compute(dp,ex1,today,now);
    Near(p1.Done,6*3600,1,"plan done counts subject since start only");Near(p1.Remaining,4*3600,1,"plan remaining");Check(p1.DaysLeft==5,"plan days left");Near(p1.PerDay,4*3600/5.0,1,"plan per day = remaining / days left");
    Near(p1.Pace,6*3600/7.0,1,"plan pace = last 7 days average");Check(p1.OnTrack&&p1.Line.Contains("충분"),"plan on track: "+p1.Line);
    var p2=ExamPlanner.Compute(dp,new Dday{name="기말",date=Logic.Key(today.AddDays(5)),targetHours=30,subject="수학",start=Logic.Key(today.AddDays(-3))},today,now);
    Check(!p2.OnTrack&&p2.Shortfall>0&&p2.Line.Contains("모자라요"),"plan shortfall: "+p2.Line);Near(p2.Projected,6*3600+(6*3600/7.0)*5,1,"plan projection (today 0 so far)");
    var p3=ExamPlanner.Compute(dp,new Dday{name="퀴즈",date=Logic.Key(today.AddDays(2)),targetHours=5,subject="",start=Logic.Key(today.AddDays(-3))},today,now);
    Check(p3.Finished&&p3.Done>=5*3600&&p3.Line.Contains("채웠어요"),"plan finished, subject blank = all subjects");
    var p4=ExamPlanner.Compute(dp,new Dday{name="중간",date=Logic.Key(today),targetHours=20,subject="수학",start=Logic.Key(today.AddDays(-3))},today,now);Check(p4.Over&&p4.Line.Contains("시험날"),"plan on exam day");
    var p5=ExamPlanner.Compute(dp,new Dday{name="토익",date=Logic.Key(today.AddDays(9))},today,now);Check(!p5.HasTarget&&p5.Title=="토익 D-9","plan without target");
    var p6=ExamPlanner.Compute(StudyData.Fresh(),new Dday{name="기말",date=Logic.Key(today.AddDays(4)),targetHours=8},today,now);Check(p6.NoPace&&Math.Abs(p6.PerDay-7200)<1,"plan with no history: per day only");
    // 별점 반영 골든타임
    var dr=StudyData.Fresh();var rt=new Dictionary<string,int>();
    for(int i=1;i<=3;i++){var morning2=Rec("수학",today.AddDays(-i).AddHours(9),60);morning2.id="m"+i;dr.records.Add(morning2);rt[morning2.id]=5;}
    for(int i=1;i<=3;i++){var evening=Rec("수학",today.AddDays(-i).AddHours(20),110);evening.id="e"+i;dr.records.Add(evening);rt[evening.id]=2;}
    var q0=Analysis.Compute(dr,today,now);Check(q0.BestHour==20&&!q0.QualityBased,"without ratings: golden = most time (20시)");
    var q1=Analysis.Compute(dr,today,now,rt);Check(q1.QualityBased&&q1.BestHour==9&&Math.Abs(q1.BestRating-5)<1e-9,"with 6 ratings: golden = highest rated (9시, ★5)");
    var rt4=rt.Take(4).ToDictionary(k=>k.Key,k=>k.Value);var q2=Analysis.Compute(dr,today,now,rt4);Check(!q2.QualityBased&&q2.RatedSessions==4,"fewer than 5 ratings: stays amount-based");
    // 기록 없는 시간이 골든타임에 끼지 않음: 9시 ★5, 10시 ★3, 8시는 비어 있음 → 8–10시가 아니라 9–11시
    var dq=StudyData.Fresh();var rq=new Dictionary<string,int>();
    for(int i=1;i<=3;i++){var a1=Rec("수학",today.AddDays(-i).AddHours(9),50);a1.id="q9"+i;dq.records.Add(a1);rq[a1.id]=5;var b1=Rec("수학",today.AddDays(-i).AddHours(10),60);b1.id="q10"+i;dq.records.Add(b1);rq[b1.id]=3;}
    var qq=Analysis.Compute(dq,today,now,rq);Check(qq.QualityBased&&qq.BestHour==9,"rated golden never starts at an empty hour (got "+qq.BestHour+")");
    Near(qq.BestRating,(5*150+3*180)/330.0,1e-6,"rated golden average over the shown 2 hours");
    Check(Analysis.Hours(6*3600)=="6시간"&&Analysis.Hours(5400)=="1시간 30분","hours label");
    // ── 2차 리뷰 반영 ──
    // 더 높은 평균의 이웃과 묶음: 8시 5시간 ★2, 9시 40분 ★5, 10시 50분 ★4.9 근처 → 9–11시
    var dz=StudyData.Fresh();var rz=new Dictionary<string,int>();int zc=0;Action<DateTime,int,int> addR=(startAt,mins,stars)=>{var rr=Rec("수학",startAt,mins);rr.id="z"+(zc++);dz.records.Add(rr);rz[rr.id]=stars;};
    for(int i=1;i<=5;i++)addR(today.AddDays(-i).AddHours(8),60,2);addR(today.AddDays(-1).AddHours(9),20,5);addR(today.AddDays(-2).AddHours(9),20,5);addR(today.AddDays(-1).AddHours(10),25,5);addR(today.AddDays(-2).AddHours(10),25,4);
    var qz=Analysis.Compute(dz,today,now,rz);Check(qz.QualityBased&&qz.BestHour==9&&qz.BestSpan==2,"rated golden pairs with the better-rated neighbor (got "+qz.BestHour+", span "+qz.BestSpan+")");Check(qz.BestRating>4.5,"rated golden average reflects the chosen 2 hours (★"+qz.BestRating.ToString("0.00")+")");
    // 이웃 시간에 별점 기록이 없으면 1시간만
    Check(q1.QualityBased&&q1.BestHour==9&&q1.BestSpan==1&&Analysis.WindowText(q1.BestHour,q1.BestSpan)=="오전 9–10시","isolated rated hour shown as a 1-hour window");
    Check(Analysis.CoachLine(q1,today.AddHours(10),0).StartsWith("내일"),"1-hour window: 10시 is outside the golden time");
    // 페이스: 차곡을 쓴 날수로 나눔 / 어제까지 없으면 오늘 공부량
    var dn=StudyData.Fresh();dn.records.Add(Rec("수학",today.AddDays(-2).AddHours(10),180));dn.records.Add(Rec("수학",today.AddDays(-1).AddHours(10),180));
    var pn=ExamPlanner.Compute(dn,new Dday{name="기말",date=Logic.Key(today.AddDays(10)),targetHours=20,start=Logic.Key(today.AddDays(-2))},today,now);
    Near(pn.Pace,3*3600,1,"new user pace = 3h/day over 2 used days (not /7)");Check(pn.OnTrack,"new user studying 3h/day toward 20h is on track: "+pn.Line);
    var dt0=StudyData.Fresh();dt0.records.Add(Rec("수학",today.AddHours(8),90));
    var pt=ExamPlanner.Compute(dt0,new Dday{name="퀴즈",date=Logic.Key(today.AddDays(3)),targetHours=6,start=Logic.Key(today)},today,now);Check(!pt.NoPace&&Math.Abs(pt.Pace-5400)<1,"first day: pace = today's study, not 'no record'");
    // 자동 실행 명령에서 경로 꺼내기
    Check(Startup.TargetOf("\"C:\\a b\\차곡.exe\" --startup")=="C:\\a b\\차곡.exe"&&Startup.TargetOf("C:\\x\\차곡.exe --startup")=="C:\\x\\차곡.exe","startup target path parsing");
    Check(Analysis.WindowText(9,1)=="오전 9–10시"&&Analysis.WindowText(11,1)=="오전 11시–오후 12시","1-hour window text");
    // 이번 주(월~오늘) 과목별
    var dw=StudyData.Fresh();var mon3=Logic.Monday(today);dw.records.Add(Rec("수학",mon3.AddHours(9),60));dw.records.Add(Rec("수학",mon3.AddDays(-1).AddHours(9),60));
    var w1=Analysis.Compute(dw,today,now);Near(w1.ThisWeek["수학"],3600,1,"this week counts from Monday only");
    // 백업 한 파일로
    var bs=new Store(Path.Combine(dir,"s5"));string studyJson=bs.Serialize(d);var bx=Extras.Fresh();bx.ratings["x"]=4;string extrasJson=new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(bx);
    string combined=BackupFile.Combine(studyJson,extrasJson);string sj,ej;BackupFile.Split(combined,out sj,out ej);
    var back=bs.Parse(sj);Check(back.records.Count==d.records.Count&&back.records.Zip(d.records,(a2,b2)=>a2.id==b2.id&&a2.segments.Count==b2.segments.Count&&Math.Abs(a2.segments[0].start-b2.segments[0].start)<0.01).All(ok=>ok),"backup split keeps study records exactly");
    Check(ej!=null&&new ExtrasStore(dir).Parse(ej).ratings["x"]==4,"backup split restores extras");
    string sj2,ej2;BackupFile.Split(studyJson,out sj2,out ej2);Check(sj2==studyJson&&ej2==null,"old backup (no extras) passes through unchanged");
    bool oldAppReads;try{oldAppReads=bs.Parse(combined).records.Count==d.records.Count;}catch{oldAppReads=false;}Check(oldAppReads,"combined backup still readable by v1.0 importer (unknown field ignored)");
    // 자동 실행 명령
    Check(Startup.CommandFor(@"C:\앱\차곡.exe")=="\"C:\\앱\\차곡.exe\" --startup"&&Startup.LaunchedAtStartup(new[]{"x.exe","--startup"})&&!Startup.LaunchedAtStartup(new[]{"x.exe"}),"startup command and flag");
    // 주간 리포트 이미지
    using(var bmp=ReportCard.Render(d,Analysis.Compute(d,today,now),today,now)){bool varied=false;var c0=bmp.GetPixel(10,10);for(int yy=200;yy<1300&&!varied;yy+=37)for(int xx=60;xx<1000;xx+=41)if(bmp.GetPixel(xx,yy)!=c0){varied=true;break;}
      Check(bmp.Width==1080&&bmp.Height==1350&&varied,"report card renders 1080x1350 with content");bmp.Save(Path.Combine(dir,"report-sample.png"));}
    // ── v1.2 날짜별 할 일 ──
    var pv=Extras.Fresh();var fut=pv.AddTodoOn("단원평가 준비",today.AddDays(3),today);var tod=pv.AddTodo("오늘 일",today);var pst=pv.AddTodoOn("지난 날짜",today.AddDays(-2),today);
    Check(fut.day==Logic.Key(today.AddDays(3))&&pst.day==Logic.Key(today)&&tod.day==Logic.Key(today),"add todo on a date (past date becomes today)");
    var vv=pv.Visible(today);Check(vv.Count==2&&!vv.Contains(fut),"future todo hidden from today's list");
    Check(pv.Visible(today.AddDays(2)).Count==2&&pv.Visible(today.AddDays(3)).Contains(fut),"future todo shows up exactly on its day");
    Check(pv.Visible(today.AddDays(5)).Contains(fut),"undone planned todo carries over after its day");
    Check(pv.On(today.AddDays(3)).Count==1&&pv.On(today.AddDays(3))[0]==fut&&pv.On(today.AddDays(4)).Count==0,"todos on a date");
    var ah=pv.AheadDays(today);Check(ah.Count==1&&ah.Contains(today.AddDays(3)),"ahead days with planned todos");
    pv.SetDone(fut,true,today);Check(pv.AheadDays(today).Count==0&&pv.Visible(today).Contains(fut),"planned todo done early: day unmarked, shows as done today");
    string f6=Path.Combine(dir,"s6");Directory.CreateDirectory(f6);var st6=new ExtrasStore(f6);var pv2=Extras.Fresh();pv2.AddTodoOn("미래",today.AddDays(10),today);st6.Save(pv2);
    Check(new ExtrasStore(f6).Load().todos[0].day==Logic.Key(today.AddDays(10)),"planned todo date survives save/load");
    // ── v1.2 달력 앞날 계획 ──
    var cd=StudyData.Fresh();var cx=Extras.Fresh();cx.ddays.Add(new Dday{name="기말",date=Logic.Key(today.AddDays(10)),targetHours=20,subject="",start=Logic.Key(today)});
    var cp=CalendarPlan.Build(cd,cx,today,now);
    Near(cp.NeedOn(today),0,0,"plan: today not counted as ahead");Near(cp.NeedOn(today.AddDays(1)),7200,0.01,"plan: 20h over 10 days = 2h/day");Near(cp.NeedOn(today.AddDays(9)),7200,0.01,"plan: day before exam");
    Near(cp.NeedOn(today.AddDays(10)),0,0,"plan: nothing on exam day");Check(cp.Need.Count==9,"plan: 9 future days before exam (got "+cp.Need.Count+")");
    Check(cp.ExamsOn(today.AddDays(10)).Count==1&&cp.ExamsOn(today.AddDays(10))[0].name=="기말","plan: exam marked on its date");
    cx.ddays.Add(new Dday{name="토익",date=Logic.Key(today.AddDays(5)),targetHours=8,subject="영어",start=Logic.Key(today)});cp=CalendarPlan.Build(cd,cx,today,now);
    Near(cp.NeedOn(today.AddDays(2)),7200+5760,0.01,"plan: overlapping exams add up");Near(cp.NeedOn(today.AddDays(6)),7200,0.01,"plan: after first exam only second remains");
    var parts=cp.PartsOn(today.AddDays(2));Check(parts.Count==2&&parts[0].Key=="기말"&&parts[1].Key=="토익 · 영어","plan: per-exam parts sorted, label has subject");
    var cd3=StudyData.Fresh();cd3.records.Add(Rec("수학",today.AddHours(6),240));var cx3=Extras.Fresh();cx3.ddays.Add(new Dday{name="기말",date=Logic.Key(today.AddDays(10)),targetHours=20,start=Logic.Key(today)});
    Near(CalendarPlan.Build(cd3,cx3,today,now).NeedOn(today.AddDays(1)),16*3600/10.0,0.01,"plan: studying today lowers future need");
    cx3.ddays[0].subject="영어";Near(CalendarPlan.Build(cd3,cx3,today,now).NeedOn(today.AddDays(1)),7200,0.01,"plan: other subjects don't count");
    var cx4=Extras.Fresh();cx4.ddays.Add(new Dday{name="쪽지",date=Logic.Key(today.AddDays(4)),targetHours=2,start=Logic.Key(today)});Check(CalendarPlan.Build(cd3,cx4,today,now).Need.Count==0,"plan: finished target adds no need");
    var cx5=Extras.Fresh();cx5.ddays.Add(new Dday{name="표시만",date=Logic.Key(today.AddDays(4))});cx5.ddays.Add(new Dday{name="지난",date=Logic.Key(today.AddDays(-3)),targetHours=10});cx5.ddays.Add(new Dday{name="오늘",date=Logic.Key(today),targetHours=10});
    var cp5=CalendarPlan.Build(cd,cx5,today,now);Check(cp5.Need.Count==0&&cp5.Exams.Count==3,"plan: no-target / past / today exams mark dates only");
    var cx6=Extras.Fresh();cx6.AddTodoOn("미리",today.AddDays(7),today);Check(CalendarPlan.Build(cd,cx6,today,now).TodoDays.Contains(today.AddDays(7)),"plan: todo days included");
    Check(CalendarPlan.Build(cd,null,today,now).Need.Count==0,"plan: null extras safe");
    var cx7=Extras.Fresh();cx7.ddays.Add(new Dday{name="A",date=Logic.Key(today.AddDays(7)),targetHours=1,start=Logic.Key(today)});cx7.ddays.Add(new Dday{name="B",date=Logic.Key(today.AddDays(3)),targetHours=1,start=Logic.Key(today)});
    var cp7=CalendarPlan.Build(cd,cx7,today,now);double n7=cp7.NeedOn(today.AddDays(1));
    Check(Math.Abs(n7-cp7.PartsOn(today.AddDays(1)).Sum(q=>q.Value))<1e-6&&n7%60==0&&cp7.PartsOn(today.AddDays(1)).All(q=>q.Value%60==0),"plan: parts are whole minutes and add up to the total ("+n7+")");
    Near(cp7.PartsOn(today.AddDays(1)).First(q=>q.Key=="A").Value,540,0,"plan: 1h over 7 days rounds up to 9 min");
    // ── v1.2 달력 컨트롤: 1년 뒤까지 고를 수 있고, 계획이 있어도 그려져요 ──
    using(var cal=new StudyCalendar{MaxDate=DateTime.Today.AddDays(StudyCalendar.AheadDays),Size=new System.Drawing.Size(300,292)}){
      cal.SetDate(DateTime.Today.AddDays(30));Check(cal.SelectionStart==DateTime.Today.AddDays(30),"calendar selects a future date");
      cal.SetDate(DateTime.Today.AddDays(800));Check(cal.SelectionStart==DateTime.Today.AddDays(StudyCalendar.AheadDays),"calendar clamps to one year ahead");
      var rx=Extras.Fresh();rx.ddays.Add(new Dday{name="기말",date=Logic.Key(DateTime.Today.AddDays(12)),targetHours=30,start=Logic.Key(DateTime.Today)});rx.AddTodoOn("미리",DateTime.Today.AddDays(3),DateTime.Today);
      cal.SetPlan(CalendarPlan.Build(StudyData.Fresh(),rx,DateTime.Today,Logic.Now()));cal.SetDate(DateTime.Today.AddDays(3));bool drew;
      try{using(var bmp=new System.Drawing.Bitmap(300,292)){cal.DrawToBitmap(bmp,new System.Drawing.Rectangle(0,0,300,292));bmp.Save(Path.Combine(dir,"calendar-sample.png"));drew=true;}}catch{drew=false;}
      Check(drew&&cal.AccessibilityObject!=null,"calendar paints with plan");
    }
    // ── v1.2 캘린더 파일(.ics) ──
    var ix=new List<Dday>{new Dday{name="기말, 고사;1",date=Logic.Key(today.AddDays(10)),targetHours=20,subject="수학"},new Dday{name="지난 시험",date=Logic.Key(today.AddDays(-1))},new Dday{name="오늘 시험",date=Logic.Key(today)}};
    string ics=Ics.Build(ix,today,new DateTime(2026,11,11,3,0,0,DateTimeKind.Utc));string unf=ics.Replace("\r\n ","");
    Check(ics.StartsWith("BEGIN:VCALENDAR\r\nVERSION:2.0\r\n")&&ics.EndsWith("END:VCALENDAR\r\n"),"ics wrapper");
    string noCrlf=ics.Replace("\r\n","");Check(noCrlf.IndexOf('\n')<0&&noCrlf.IndexOf('\r')<0,"ics uses CRLF only");
    Check(System.Text.RegularExpressions.Regex.Matches(ics,"BEGIN:VEVENT").Count==2&&!unf.Contains("지난 시험")&&unf.Contains("오늘 시험"),"ics: upcoming exams only (today kept, past dropped)");
    Check(unf.Contains("DTSTART;VALUE=DATE:20261121\r\n")&&unf.Contains("DTEND;VALUE=DATE:20261122\r\n")&&unf.Contains("DTSTAMP:20261111T030000Z"),"ics all-day dates and stamp");
    Check(unf.Contains("SUMMARY:기말\\, 고사\\;1 · 수학\r\n"),"ics escapes comma and semicolon");
    Check(unf.Contains("DESCRIPTION:목표 공부 20시간 (수학)\\n차곡에서 내보낸 시험 일정\r\n"),"ics description with escaped newline");
    Check(ics.Split(new[]{"\r\n"},StringSplitOptions.None).All(q=>Encoding.UTF8.GetByteCount(q)<=75),"ics lines folded to 75 bytes");
    Check(Ics.Uid(ix[0])==Ics.Uid(new Dday{name="기말, 고사;1",date=ix[0].date,subject="수학"})&&Ics.Uid(ix[0])!=Ics.Uid(ix[2])&&System.Text.RegularExpressions.Regex.IsMatch(Ics.Uid(ix[0]),"^chagok-\\d{8}-[0-9a-f]{12}@chagok$"),"ics uid stable and unique");
    var lsb=new StringBuilder();string longText="SUMMARY:"+string.Concat(Enumerable.Repeat("가나다라마바사😀",15));Ics.Line(lsb,longText);
    Check(lsb.ToString().Replace("\r\n ","")==longText+"\r\n"&&lsb.ToString().Split(new[]{"\r\n"},StringSplitOptions.RemoveEmptyEntries).All(q=>Encoding.UTF8.GetByteCount(q)<=75),"ics folding keeps Korean and emoji intact");
    Check(Ics.Build(new List<Dday>(),today,DateTime.UtcNow).IndexOf("VEVENT")<0,"ics with no exams has no events");
    // ── 기존 저장 형식 그대로 ──
    var store=new Store(Path.Combine(dir,"s2"));store.Save(d);var json=File.ReadAllText(store.FilePath);
    Check(!json.Contains("todos")&&!json.Contains("pomodoro")&&json.Contains("\"version\":1"),"study-data.json schema unchanged");
  }
}
